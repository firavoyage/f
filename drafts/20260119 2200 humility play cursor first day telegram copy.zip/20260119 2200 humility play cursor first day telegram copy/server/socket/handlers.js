const { v4: uuidv4 } = require('uuid');
const db = require('../db/database');

// Store connected users
const connectedUsers = new Map();

function setupSocketHandlers(io) {
  io.on('connection', (socket) => {
    const userId = socket.user.id;
    console.log(`User connected: ${socket.user.username}`);

    // Store socket connection
    connectedUsers.set(userId, socket.id);
    
    // Update user status
    db.prepare('UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?')
      .run('online', userId);

    // Join user's chat rooms
    const userChats = db.prepare(`
      SELECT chat_id FROM chat_members WHERE user_id = ?
    `).all(userId);
    
    userChats.forEach(chat => {
      socket.join(chat.chat_id);
    });

    // Broadcast online status to all contacts
    broadcastUserStatus(io, userId, 'online');

    // Handle new message
    socket.on('send_message', (data) => {
      try {
        const { chatId, content, type = 'text' } = data;
        
        // Verify user is member
        const isMember = db.prepare('SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ?')
          .get(chatId, userId);
        
        if (!isMember) {
          socket.emit('error', { message: 'Not a member of this chat' });
          return;
        }

        const messageId = uuidv4();
        const now = new Date().toISOString();
        
        db.prepare(`
          INSERT INTO messages (id, chat_id, sender_id, content, type, read_by, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `).run(messageId, chatId, userId, content, type, JSON.stringify([userId]), now);

        const message = {
          id: messageId,
          chat_id: chatId,
          sender_id: userId,
          content,
          type,
          read_by: [userId],
          created_at: now,
          username: socket.user.username,
          display_name: db.prepare('SELECT display_name FROM users WHERE id = ?').get(userId)?.display_name,
          avatar_color: db.prepare('SELECT avatar_color FROM users WHERE id = ?').get(userId)?.avatar_color
        };

        // Send to all users in the chat
        io.to(chatId).emit('new_message', message);
      } catch (error) {
        console.error('Send message error:', error);
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // Handle typing indicator
    socket.on('typing_start', (data) => {
      const { chatId } = data;
      socket.to(chatId).emit('user_typing', { 
        chatId, 
        userId, 
        username: socket.user.username 
      });
    });

    socket.on('typing_stop', (data) => {
      const { chatId } = data;
      socket.to(chatId).emit('user_stopped_typing', { chatId, userId });
    });

    // Handle message read
    socket.on('mark_read', (data) => {
      try {
        const { chatId, messageIds } = data;
        
        if (!messageIds || messageIds.length === 0) return;

        messageIds.forEach(messageId => {
          const message = db.prepare('SELECT read_by FROM messages WHERE id = ?').get(messageId);
          if (message) {
            const readBy = JSON.parse(message.read_by || '[]');
            if (!readBy.includes(userId)) {
              readBy.push(userId);
              db.prepare('UPDATE messages SET read_by = ? WHERE id = ?')
                .run(JSON.stringify(readBy), messageId);
            }
          }
        });

        socket.to(chatId).emit('messages_read', { chatId, userId, messageIds });
      } catch (error) {
        console.error('Mark read error:', error);
      }
    });

    // Handle joining a new chat
    socket.on('join_chat', (chatId) => {
      socket.join(chatId);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log(`User disconnected: ${socket.user.username}`);
      connectedUsers.delete(userId);
      
      db.prepare('UPDATE users SET status = ?, last_seen = CURRENT_TIMESTAMP WHERE id = ?')
        .run('offline', userId);
      
      broadcastUserStatus(io, userId, 'offline');
    });
  });
}

function broadcastUserStatus(io, userId, status) {
  // Get all chats the user is a member of
  const userChats = db.prepare(`
    SELECT DISTINCT cm2.user_id
    FROM chat_members cm1
    JOIN chat_members cm2 ON cm1.chat_id = cm2.chat_id
    WHERE cm1.user_id = ? AND cm2.user_id != ?
  `).all(userId, userId);

  // Notify each connected user who shares a chat
  userChats.forEach(({ user_id }) => {
    const socketId = connectedUsers.get(user_id);
    if (socketId) {
      io.to(socketId).emit('user_status_change', { 
        userId, 
        status,
        last_seen: new Date().toISOString()
      });
    }
  });
}

module.exports = { setupSocketHandlers };
