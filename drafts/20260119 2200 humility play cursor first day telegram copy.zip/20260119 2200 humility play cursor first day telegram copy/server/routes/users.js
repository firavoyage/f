const express = require('express');
const db = require('../db/database');

const router = express.Router();

// Search users
router.get('/search', (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) {
      return res.json([]);
    }

    const users = db.prepare(`
      SELECT id, username, display_name, avatar_color, status, last_seen
      FROM users
      WHERE (username LIKE ? OR display_name LIKE ?) AND id != ?
      LIMIT 20
    `).all(`%${q}%`, `%${q}%`, req.user.id);

    res.json(users);
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get user by ID
router.get('/:id', (req, res) => {
  try {
    const user = db.prepare(`
      SELECT id, username, display_name, avatar_color, status, last_seen
      FROM users WHERE id = ?
    `).get(req.params.id);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(user);
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update profile
router.put('/profile', (req, res) => {
  try {
    const { displayName, avatarColor } = req.body;
    
    const updates = [];
    const values = [];
    
    if (displayName) {
      updates.push('display_name = ?');
      values.push(displayName);
    }
    if (avatarColor) {
      updates.push('avatar_color = ?');
      values.push(avatarColor);
    }
    
    if (updates.length === 0) {
      return res.status(400).json({ error: 'No updates provided' });
    }
    
    values.push(req.user.id);
    
    db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...values);
    
    const user = db.prepare(`
      SELECT id, username, display_name, avatar_color, status, last_seen
      FROM users WHERE id = ?
    `).get(req.user.id);
    
    res.json(user);
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
