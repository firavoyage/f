const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/database');

const router = express.Router();

// Get all chats for current user
router.get('/', (req, res) => {
  try {
    const chats = db.prepare(`
      SELECT 
        c.id,
        c.type,
        c.name,
        c.created_at,
        (
          SELECT json_object(
            'id', m.id,
            'content', m.content,
            'sender_id', m.sender_id,
            'created_at', m.created_at
          )
          FROM messages m
          WHERE m.chat_id = c.id
          ORDER BY m.created_at DESC
          LIMIT 1
        ) as last_message,
        (
          SELECT COUNT(*)
          FROM messages m
          WHERE m.chat_id = c.id
          AND m.sender_id != ?
          AND NOT EXISTS (
            SELECT 1 FROM json_each(m.read_by) WHERE value = ?
          )
        ) as unread_count
      FROM chats c
      JOIN chat_members cm ON c.id = cm.chat_id
      WHERE cm.user_id = ?
      ORDER BY (
        SELECT MAX(created_at) FROM messages WHERE chat_id = c.id
      ) DESC NULLS LAST
    `).all(req.user.id, req.user.id, req.user.id);

    // Get members for each chat
    const chatsWithMembers = chats.map(chat => {
      const members = db.prepare(`
        SELECT u.id, u.username, u.display_name, u.avatar_color, u.status, u.last_seen
        FROM users u
        JOIN chat_members cm ON u.id = cm.user_id
        WHERE cm.chat_id = ?
      `).all(chat.id);

      return {
        ...chat,
        last_message: chat.last_message ? JSON.parse(chat.last_message) : null,
        members
      };
    });

    res.json(chatsWithMembers);
  } catch (error) {
    console.error('Get chats error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create or get private chat
router.post('/private', (req, res) => {
  try {
    const { userId } = req.body;
    
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }

    // Check if private chat already exists
    const existingChat = db.prepare(`
      SELECT c.id
      FROM chats c
      WHERE c.type = 'private'
      AND EXISTS (SELECT 1 FROM chat_members WHERE chat_id = c.id AND user_id = ?)
      AND EXISTS (SELECT 1 FROM chat_members WHERE chat_id = c.id AND user_id = ?)
    `).get(req.user.id, userId);

    if (existingChat) {
      const chat = getFullChat(existingChat.id);
      return res.json(chat);
    }

    // Create new private chat
    const chatId = uuidv4();
    
    db.prepare('INSERT INTO chats (id, type) VALUES (?, ?)').run(chatId, 'private');
    db.prepare('INSERT INTO chat_members (chat_id, user_id) VALUES (?, ?)').run(chatId, req.user.id);
    db.prepare('INSERT INTO chat_members (chat_id, user_id) VALUES (?, ?)').run(chatId, userId);

    const chat = getFullChat(chatId);
    res.status(201).json(chat);
  } catch (error) {
    console.error('Create private chat error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create group chat
router.post('/group', (req, res) => {
  try {
    const { name, memberIds } = req.body;
    
    if (!name || !memberIds || memberIds.length === 0) {
      return res.status(400).json({ error: 'Name and members are required' });
    }

    const chatId = uuidv4();
    
    db.prepare('INSERT INTO chats (id, type, name, created_by) VALUES (?, ?, ?, ?)')
      .run(chatId, 'group', name, req.user.id);
    
    // Add creator
    db.prepare('INSERT INTO chat_members (chat_id, user_id) VALUES (?, ?)').run(chatId, req.user.id);
    
    // Add members
    const insertMember = db.prepare('INSERT INTO chat_members (chat_id, user_id) VALUES (?, ?)');
    memberIds.forEach(memberId => {
      if (memberId !== req.user.id) {
        insertMember.run(chatId, memberId);
      }
    });

    const chat = getFullChat(chatId);
    res.status(201).json(chat);
  } catch (error) {
    console.error('Create group chat error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get chat messages
router.get('/:chatId/messages', (req, res) => {
  try {
    const { chatId } = req.params;
    const { before, limit = 50 } = req.query;

    // Verify user is member
    const isMember = db.prepare('SELECT 1 FROM chat_members WHERE chat_id = ? AND user_id = ?')
      .get(chatId, req.user.id);
    
    if (!isMember) {
      return res.status(403).json({ error: 'Not a member of this chat' });
    }

    let query = `
      SELECT m.*, u.username, u.display_name, u.avatar_color
      FROM messages m
      JOIN users u ON m.sender_id = u.id
      WHERE m.chat_id = ?
    `;
    const params = [chatId];

    if (before) {
      query += ' AND m.created_at < ?';
      params.push(before);
    }

    query += ' ORDER BY m.created_at DESC LIMIT ?';
    params.push(parseInt(limit));

    const messages = db.prepare(query).all(...params);
    
    // Parse read_by JSON
    const messagesWithReadBy = messages.map(m => ({
      ...m,
      read_by: JSON.parse(m.read_by || '[]')
    }));

    res.json(messagesWithReadBy.reverse());
  } catch (error) {
    console.error('Get messages error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Helper function to get full chat data
function getFullChat(chatId) {
  const chat = db.prepare('SELECT * FROM chats WHERE id = ?').get(chatId);
  const members = db.prepare(`
    SELECT u.id, u.username, u.display_name, u.avatar_color, u.status, u.last_seen
    FROM users u
    JOIN chat_members cm ON u.id = cm.user_id
    WHERE cm.chat_id = ?
  `).all(chatId);

  return {
    ...chat,
    members,
    last_message: null,
    unread_count: 0
  };
}

module.exports = router;
