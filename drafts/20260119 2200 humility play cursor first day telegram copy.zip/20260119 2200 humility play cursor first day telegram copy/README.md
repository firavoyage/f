# Telegram Clone

A full-featured Telegram messaging app clone built with React and Node.js.

## Features

- **Real-time messaging** with Socket.io
- **User authentication** (register/login)
- **Private chats** - 1-on-1 conversations
- **Group chats** support
- **Online status** indicators
- **Typing indicators** - see when someone is typing
- **Message read receipts**
- **User search** - find and start conversations
- **Responsive design** - works on desktop and mobile
- **Telegram-style UI** - dark theme with familiar look

## Tech Stack

**Backend:**
- Node.js + Express
- Socket.io for real-time communication
- SQLite with better-sqlite3
- JWT authentication
- bcrypt for password hashing

**Frontend:**
- React 18
- Socket.io-client
- date-fns for date formatting
- CSS (no framework, custom Telegram-like styling)

## Getting Started

### Prerequisites

- Node.js 16+ installed
- npm or yarn

### Installation

1. Install all dependencies:

```bash
npm run install-all
```

This will install both server and client dependencies.

### Running the App

Start both the server and client with one command:

```bash
npm start
```

Or run them separately:

```bash
# Terminal 1 - Start the server
npm run server

# Terminal 2 - Start the client
npm run client
```

The app will be available at:
- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:5000

## Usage

1. **Register** a new account with username, email, and password
2. **Search** for other users using the search bar or new chat button
3. **Start a conversation** by clicking on a user
4. **Send messages** in real-time
5. **See online status** of your contacts
6. **Typing indicators** show when someone is typing

## Project Structure

```
telegram/
├── server/                 # Backend
│   ├── index.js           # Express server setup
│   ├── db/
│   │   └── database.js    # SQLite database setup
│   ├── middleware/
│   │   └── auth.js        # JWT authentication
│   ├── routes/
│   │   ├── auth.js        # Authentication routes
│   │   ├── chats.js       # Chat management routes
│   │   └── users.js       # User routes
│   └── socket/
│       └── handlers.js    # Socket.io event handlers
├── client/                 # Frontend
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── App.js
│       ├── context/
│       │   └── SocketContext.js
│       └── components/
│           ├── Auth.js         # Login/Register
│           ├── ChatLayout.js   # Main layout
│           ├── Sidebar.js      # Chat list
│           ├── ChatWindow.js   # Message view
│           └── SearchUsers.js  # User search
└── package.json
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user

### Users
- `GET /api/users/search?q=query` - Search users
- `GET /api/users/:id` - Get user by ID
- `PUT /api/users/profile` - Update profile

### Chats
- `GET /api/chats` - Get all user's chats
- `POST /api/chats/private` - Create/get private chat
- `POST /api/chats/group` - Create group chat
- `GET /api/chats/:chatId/messages` - Get chat messages

## Socket Events

### Client to Server
- `send_message` - Send a new message
- `typing_start` - User started typing
- `typing_stop` - User stopped typing
- `mark_read` - Mark messages as read
- `join_chat` - Join a chat room

### Server to Client
- `new_message` - New message received
- `user_typing` - User is typing
- `user_stopped_typing` - User stopped typing
- `messages_read` - Messages marked as read
- `user_status_change` - User online/offline status change

## License

MIT
