import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './Sidebar';
import ChatWindow from './ChatWindow';
import { useSocket } from '../context/SocketContext';
import './ChatLayout.css';

function ChatLayout({ user, onLogout }) {
  const [chats, setChats] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [showSidebar, setShowSidebar] = useState(true);
  const { socket, isConnected } = useSocket();

  const fetchChats = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/chats', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setChats(data);
      }
    } catch (error) {
      console.error('Failed to fetch chats:', error);
    }
  }, []);

  useEffect(() => {
    fetchChats();
  }, [fetchChats]);

  useEffect(() => {
    if (!socket) return;

    const handleNewMessage = (message) => {
      setChats(prevChats => {
        return prevChats.map(chat => {
          if (chat.id === message.chat_id) {
            const isSelected = selectedChat?.id === chat.id;
            return {
              ...chat,
              last_message: message,
              unread_count: isSelected ? chat.unread_count : (chat.unread_count || 0) + 1
            };
          }
          return chat;
        }).sort((a, b) => {
          const aTime = a.last_message?.created_at || a.created_at;
          const bTime = b.last_message?.created_at || b.created_at;
          return new Date(bTime) - new Date(aTime);
        });
      });
    };

    const handleUserStatusChange = ({ userId, status, last_seen }) => {
      setChats(prevChats => {
        return prevChats.map(chat => ({
          ...chat,
          members: chat.members.map(member => 
            member.id === userId 
              ? { ...member, status, last_seen }
              : member
          )
        }));
      });
    };

    socket.on('new_message', handleNewMessage);
    socket.on('user_status_change', handleUserStatusChange);

    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('user_status_change', handleUserStatusChange);
    };
  }, [socket, selectedChat]);

  const handleSelectChat = (chat) => {
    setSelectedChat(chat);
    setShowSidebar(false);
    
    // Clear unread count
    setChats(prevChats => 
      prevChats.map(c => 
        c.id === chat.id ? { ...c, unread_count: 0 } : c
      )
    );
  };

  const handleChatCreated = (newChat) => {
    setChats(prevChats => {
      const exists = prevChats.find(c => c.id === newChat.id);
      if (exists) return prevChats;
      return [newChat, ...prevChats];
    });
    setSelectedChat(newChat);
    setShowSidebar(false);
    
    if (socket) {
      socket.emit('join_chat', newChat.id);
    }
  };

  const handleBack = () => {
    setShowSidebar(true);
  };

  const getChatDisplayInfo = (chat) => {
    if (chat.type === 'group') {
      return {
        name: chat.name,
        avatar: chat.name?.charAt(0).toUpperCase(),
        avatarColor: '#0088cc',
        status: `${chat.members?.length || 0} members`
      };
    }
    
    const otherMember = chat.members?.find(m => m.id !== user.id);
    return {
      name: otherMember?.display_name || otherMember?.username || 'Unknown',
      avatar: (otherMember?.display_name || otherMember?.username || 'U').charAt(0).toUpperCase(),
      avatarColor: otherMember?.avatar_color || '#0088cc',
      status: otherMember?.status === 'online' ? 'online' : 
        otherMember?.last_seen ? `last seen ${formatLastSeen(otherMember.last_seen)}` : 'offline'
    };
  };

  return (
    <div className="chat-layout">
      <Sidebar 
        chats={chats}
        selectedChat={selectedChat}
        onSelectChat={handleSelectChat}
        onChatCreated={handleChatCreated}
        user={user}
        onLogout={onLogout}
        isVisible={showSidebar}
        getChatDisplayInfo={getChatDisplayInfo}
        isConnected={isConnected}
      />
      
      {selectedChat ? (
        <ChatWindow 
          chat={selectedChat}
          user={user}
          onBack={handleBack}
          getChatDisplayInfo={getChatDisplayInfo}
        />
      ) : (
        <div className="no-chat-selected">
          <div className="no-chat-content">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
            </svg>
            <h2>Select a chat to start messaging</h2>
            <p>Choose from your existing conversations or start a new one</p>
          </div>
        </div>
      )}
    </div>
  );
}

function formatLastSeen(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diff = now - date;
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  if (days === 1) return 'yesterday';
  return date.toLocaleDateString();
}

export default ChatLayout;
