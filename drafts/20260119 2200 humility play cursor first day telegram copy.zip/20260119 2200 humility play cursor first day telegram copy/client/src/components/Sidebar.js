import React, { useState } from 'react';
import SearchUsers from './SearchUsers';
import './Sidebar.css';

function Sidebar({ 
  chats, 
  selectedChat, 
  onSelectChat, 
  onChatCreated, 
  user, 
  onLogout,
  isVisible,
  getChatDisplayInfo,
  isConnected
}) {
  const [showSearch, setShowSearch] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredChats = chats.filter(chat => {
    if (!searchQuery) return true;
    const info = getChatDisplayInfo(chat);
    return info.name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    }
    
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className={`sidebar ${isVisible ? 'visible' : ''}`}>
      <div className="sidebar-header">
        <button className="menu-button" onClick={() => setShowMenu(!showMenu)}>
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
          </svg>
        </button>
        
        <div className="search-bar">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
          </svg>
          <input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        {showMenu && (
          <div className="dropdown-menu">
            <div className="menu-user-info">
              <div 
                className="avatar"
                style={{ backgroundColor: user.avatar_color }}
              >
                {(user.display_name || user.username).charAt(0).toUpperCase()}
              </div>
              <div className="user-details">
                <span className="name">{user.display_name || user.username}</span>
                <span className="email">{user.email}</span>
              </div>
            </div>
            <div className="menu-divider"></div>
            <button onClick={() => { setShowSearch(true); setShowMenu(false); }}>
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
              </svg>
              New Chat
            </button>
            <button onClick={onLogout}>
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/>
              </svg>
              Log Out
            </button>
          </div>
        )}
      </div>

      <div className="connection-status">
        <span className={`status-dot ${isConnected ? 'online' : 'offline'}`}></span>
        {isConnected ? 'Connected' : 'Connecting...'}
      </div>

      <div className="chat-list">
        {filteredChats.length === 0 ? (
          <div className="no-chats">
            <p>{searchQuery ? 'No chats found' : 'No conversations yet'}</p>
            <button onClick={() => setShowSearch(true)}>Start a new chat</button>
          </div>
        ) : (
          filteredChats.map(chat => {
            const info = getChatDisplayInfo(chat);
            const isSelected = selectedChat?.id === chat.id;
            
            return (
              <div
                key={chat.id}
                className={`chat-item ${isSelected ? 'selected' : ''}`}
                onClick={() => onSelectChat(chat)}
              >
                <div 
                  className="chat-avatar"
                  style={{ backgroundColor: info.avatarColor }}
                >
                  {info.avatar}
                  {chat.type === 'private' && (
                    <span className={`online-indicator ${
                      chat.members?.find(m => m.id !== user.id)?.status === 'online' ? 'online' : ''
                    }`}></span>
                  )}
                </div>
                
                <div className="chat-info">
                  <div className="chat-header">
                    <span className="chat-name">{info.name}</span>
                    <span className="chat-time">
                      {formatTime(chat.last_message?.created_at)}
                    </span>
                  </div>
                  <div className="chat-preview">
                    <p className="last-message">
                      {chat.last_message 
                        ? (chat.last_message.sender_id === user.id ? 'You: ' : '') + chat.last_message.content
                        : 'No messages yet'}
                    </p>
                    {chat.unread_count > 0 && (
                      <span className="unread-badge">{chat.unread_count}</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <button className="new-chat-fab" onClick={() => setShowSearch(true)}>
        <svg viewBox="0 0 24 24" fill="currentColor">
          <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
        </svg>
      </button>

      {showSearch && (
        <SearchUsers 
          onClose={() => setShowSearch(false)}
          onChatCreated={onChatCreated}
          currentUser={user}
        />
      )}

      {showMenu && <div className="menu-overlay" onClick={() => setShowMenu(false)}></div>}
    </div>
  );
}

export default Sidebar;
