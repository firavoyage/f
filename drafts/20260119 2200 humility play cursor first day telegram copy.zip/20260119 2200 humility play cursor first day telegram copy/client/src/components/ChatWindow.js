import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useSocket } from '../context/SocketContext';
import { format, isToday, isYesterday } from 'date-fns';
import './ChatWindow.css';

function ChatWindow({ chat, user, onBack, getChatDisplayInfo }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [typingUsers, setTypingUsers] = useState([]);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const { socket } = useSocket();

  const chatInfo = getChatDisplayInfo(chat);

  const fetchMessages = useCallback(async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/chats/${chat.id}/messages`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setMessages(data);
      }
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
    setLoading(false);
  }, [chat.id]);

  useEffect(() => {
    fetchMessages();
    setTypingUsers([]);
  }, [fetchMessages]);

  useEffect(() => {
    if (!socket) return;

    const handleNewMessage = (message) => {
      if (message.chat_id === chat.id) {
        setMessages(prev => [...prev, message]);
        
        // Mark as read
        if (message.sender_id !== user.id) {
          socket.emit('mark_read', { chatId: chat.id, messageIds: [message.id] });
        }
      }
    };

    const handleUserTyping = ({ chatId, userId, username }) => {
      if (chatId === chat.id && userId !== user.id) {
        setTypingUsers(prev => {
          if (!prev.find(u => u.userId === userId)) {
            return [...prev, { userId, username }];
          }
          return prev;
        });
      }
    };

    const handleUserStoppedTyping = ({ chatId, userId }) => {
      if (chatId === chat.id) {
        setTypingUsers(prev => prev.filter(u => u.userId !== userId));
      }
    };

    socket.on('new_message', handleNewMessage);
    socket.on('user_typing', handleUserTyping);
    socket.on('user_stopped_typing', handleUserStoppedTyping);

    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('user_typing', handleUserTyping);
      socket.off('user_stopped_typing', handleUserStoppedTyping);
    };
  }, [socket, chat.id, user.id]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleTyping = () => {
    if (!socket) return;

    socket.emit('typing_start', { chatId: chat.id });
    
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    typingTimeoutRef.current = setTimeout(() => {
      socket.emit('typing_stop', { chatId: chat.id });
    }, 2000);
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !socket) return;

    socket.emit('send_message', {
      chatId: chat.id,
      content: newMessage.trim()
    });

    socket.emit('typing_stop', { chatId: chat.id });
    setNewMessage('');
    inputRef.current?.focus();
  };

  const formatMessageTime = (dateString) => {
    const date = new Date(dateString);
    return format(date, 'HH:mm');
  };

  const formatDateSeparator = (dateString) => {
    const date = new Date(dateString);
    if (isToday(date)) return 'Today';
    if (isYesterday(date)) return 'Yesterday';
    return format(date, 'MMMM d, yyyy');
  };

  const shouldShowDateSeparator = (message, index) => {
    if (index === 0) return true;
    const prevDate = new Date(messages[index - 1].created_at).toDateString();
    const currDate = new Date(message.created_at).toDateString();
    return prevDate !== currDate;
  };

  const shouldGroupMessage = (message, index) => {
    if (index === 0) return false;
    const prevMessage = messages[index - 1];
    const timeDiff = new Date(message.created_at) - new Date(prevMessage.created_at);
    return prevMessage.sender_id === message.sender_id && timeDiff < 60000;
  };

  return (
    <div className="chat-window">
      <div className="chat-header">
        <button className="back-button mobile-only" onClick={onBack}>
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>
          </svg>
        </button>
        
        <div 
          className="chat-header-avatar"
          style={{ backgroundColor: chatInfo.avatarColor }}
        >
          {chatInfo.avatar}
        </div>
        
        <div className="chat-header-info">
          <h2>{chatInfo.name}</h2>
          <p>
            {typingUsers.length > 0 
              ? `${typingUsers.map(u => u.username).join(', ')} typing...`
              : chatInfo.status}
          </p>
        </div>

        <div className="chat-header-actions">
          <button className="icon-button">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
            </svg>
          </button>
          <button className="icon-button">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/>
            </svg>
          </button>
        </div>
      </div>

      <div className="messages-container">
        {loading ? (
          <div className="messages-loading">
            <div className="spinner"></div>
          </div>
        ) : messages.length === 0 ? (
          <div className="no-messages">
            <p>No messages yet</p>
            <span>Send a message to start the conversation</span>
          </div>
        ) : (
          <div className="messages-list">
            {messages.map((message, index) => {
              const isOwn = message.sender_id === user.id;
              const isGrouped = shouldGroupMessage(message, index);
              const showDate = shouldShowDateSeparator(message, index);

              return (
                <React.Fragment key={message.id}>
                  {showDate && (
                    <div className="date-separator">
                      <span>{formatDateSeparator(message.created_at)}</span>
                    </div>
                  )}
                  <div 
                    className={`message ${isOwn ? 'own' : ''} ${isGrouped ? 'grouped' : ''}`}
                  >
                    {!isOwn && !isGrouped && chat.type === 'group' && (
                      <div 
                        className="message-avatar"
                        style={{ backgroundColor: message.avatar_color }}
                      >
                        {(message.display_name || message.username || 'U').charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="message-bubble">
                      {!isOwn && !isGrouped && chat.type === 'group' && (
                        <span 
                          className="message-sender"
                          style={{ color: message.avatar_color }}
                        >
                          {message.display_name || message.username}
                        </span>
                      )}
                      <p className="message-content">{message.content}</p>
                      <span className="message-time">
                        {formatMessageTime(message.created_at)}
                        {isOwn && (
                          <svg className="message-status" viewBox="0 0 16 15" fill="currentColor">
                            <path d="M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.88a.32.32 0 0 1-.484.032l-.358-.325a.32.32 0 0 0-.484.032l-.378.48a.418.418 0 0 0 .036.54l1.32 1.267a.32.32 0 0 0 .484-.034l6.272-8.048a.366.366 0 0 0-.064-.512zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.88a.32.32 0 0 1-.484.032L1.892 7.77a.366.366 0 0 0-.516.005l-.423.433a.364.364 0 0 0 .006.514l3.255 3.185a.32.32 0 0 0 .484-.034l6.272-8.048a.365.365 0 0 0-.063-.51z"/>
                          </svg>
                        )}
                      </span>
                    </div>
                  </div>
                </React.Fragment>
              );
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <form className="message-input-container" onSubmit={handleSendMessage}>
        <button type="button" className="icon-button attach-button">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M16.5 6v11.5c0 2.21-1.79 4-4 4s-4-1.79-4-4V5c0-1.38 1.12-2.5 2.5-2.5s2.5 1.12 2.5 2.5v10.5c0 .55-.45 1-1 1s-1-.45-1-1V6H10v9.5c0 1.38 1.12 2.5 2.5 2.5s2.5-1.12 2.5-2.5V5c0-2.21-1.79-4-4-4S7 2.79 7 5v12.5c0 3.04 2.46 5.5 5.5 5.5s5.5-2.46 5.5-5.5V6h-1.5z"/>
          </svg>
        </button>
        
        <input
          ref={inputRef}
          type="text"
          placeholder="Write a message..."
          value={newMessage}
          onChange={(e) => {
            setNewMessage(e.target.value);
            handleTyping();
          }}
        />
        
        <button type="button" className="icon-button emoji-button">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"/>
          </svg>
        </button>
        
        {newMessage.trim() ? (
          <button type="submit" className="send-button">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
            </svg>
          </button>
        ) : (
          <button type="button" className="icon-button mic-button">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"/>
            </svg>
          </button>
        )}
      </form>
    </div>
  );
}

export default ChatWindow;
