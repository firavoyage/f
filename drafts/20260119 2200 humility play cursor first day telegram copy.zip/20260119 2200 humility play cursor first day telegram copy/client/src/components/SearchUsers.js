import React, { useState, useEffect, useCallback } from 'react';
import './SearchUsers.css';

function SearchUsers({ onClose, onChatCreated, currentUser }) {
  const [query, setQuery] = useState('');
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);

  const searchUsers = useCallback(async () => {
    if (query.length < 2) {
      setUsers([]);
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Search failed:', error);
    }
    setLoading(false);
  }, [query]);

  useEffect(() => {
    const debounce = setTimeout(searchUsers, 300);
    return () => clearTimeout(debounce);
  }, [searchUsers]);

  const startChat = async (userId) => {
    setCreating(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/chats/private', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ userId })
      });
      
      if (res.ok) {
        const chat = await res.json();
        onChatCreated(chat);
        onClose();
      }
    } catch (error) {
      console.error('Failed to create chat:', error);
    }
    setCreating(false);
  };

  return (
    <div className="search-users-overlay">
      <div className="search-users-modal">
        <div className="search-users-header">
          <button className="back-button" onClick={onClose}>
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/>
            </svg>
          </button>
          <input
            type="text"
            placeholder="Search users by name..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
          />
        </div>

        <div className="search-users-content">
          {loading && (
            <div className="search-loading">
              <div className="spinner"></div>
              <p>Searching...</p>
            </div>
          )}

          {!loading && query.length >= 2 && users.length === 0 && (
            <div className="no-results">
              <p>No users found</p>
            </div>
          )}

          {!loading && query.length < 2 && (
            <div className="search-hint">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
              </svg>
              <p>Type at least 2 characters to search</p>
            </div>
          )}

          <div className="users-list">
            {users.map(user => (
              <div
                key={user.id}
                className="user-item"
                onClick={() => !creating && startChat(user.id)}
              >
                <div 
                  className="user-avatar"
                  style={{ backgroundColor: user.avatar_color }}
                >
                  {(user.display_name || user.username).charAt(0).toUpperCase()}
                  <span className={`status-indicator ${user.status === 'online' ? 'online' : ''}`}></span>
                </div>
                <div className="user-info">
                  <span className="user-name">{user.display_name || user.username}</span>
                  <span className="user-username">@{user.username}</span>
                </div>
                {creating && (
                  <div className="creating-spinner"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SearchUsers;
