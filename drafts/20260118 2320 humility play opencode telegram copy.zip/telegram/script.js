class TelegramClone {
    constructor() {
        this.currentChat = null;
        this.messages = this.loadMessages();
        this.chats = this.loadChats();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.renderChats();
        this.selectChat(0);
    }

    setupEventListeners() {
        // Chat item clicks
        document.addEventListener('click', (e) => {
            const chatItem = e.target.closest('.chat-item');
            if (chatItem) {
                const index = Array.from(chatItem.parentNode.children).indexOf(chatItem);
                this.selectChat(index);
            }
        });

        // Send message
        const sendBtn = document.querySelector('.send-btn');
        const messageInput = document.querySelector('.message-input input');
        
        sendBtn.addEventListener('click', () => this.sendMessage());
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });

        // Search functionality
        const searchInput = document.querySelector('.search-box input');
        searchInput.addEventListener('input', (e) => {
            this.filterChats(e.target.value);
        });

        // Sidebar action buttons
        document.querySelectorAll('.sidebar-actions .icon-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.handleSidebarAction(e.target.closest('.icon-btn'));
            });
        });

        // Chat action buttons
        document.querySelectorAll('.chat-actions .icon-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.handleChatAction(e.target.closest('.icon-btn'));
            });
        });

        // Attachment button
        document.querySelector('.fa-paperclip').parentElement.addEventListener('click', () => {
            this.showNotification('File attachment feature coming soon!');
        });

        // Emoji button
        document.querySelector('.emoji-btn').addEventListener('click', () => {
            this.showNotification('Emoji picker coming soon!');
        });
    }

    selectChat(index) {
        // Update active chat in sidebar
        document.querySelectorAll('.chat-item').forEach((item, i) => {
            item.classList.toggle('active', i === index);
        });

        // Update current chat
        this.currentChat = this.chats[index];
        
        // Update chat header
        document.querySelector('.chat-header .chat-name').textContent = this.currentChat.name;
        document.querySelector('.chat-header .chat-status').textContent = this.currentChat.status;

        // Load messages for current chat
        this.loadMessagesForChat(this.currentChat.id);
    }

    sendMessage() {
        const input = document.querySelector('.message-input input');
        const messageText = input.value.trim();
        
        if (!messageText || !this.currentChat) return;

        const message = {
            id: Date.now(),
            text: messageText,
            sender: 'me',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            chatId: this.currentChat.id
        };

        this.addMessage(message);
        input.value = '';

        // Update last message in chat list
        this.updateChatLastMessage(this.currentChat.id, messageText);

        // Simulate response
        setTimeout(() => this.simulateResponse(), 1000 + Math.random() * 2000);
    }

    addMessage(message) {
        // Store message
        if (!this.messages[message.chatId]) {
            this.messages[message.chatId] = [];
        }
        this.messages[message.chatId].push(message);
        this.saveMessages();

        // Add to UI if it's the current chat
        if (this.currentChat && message.chatId === this.currentChat.id) {
            this.renderMessage(message);
            this.scrollToBottom();
        }
    }

    renderMessage(message) {
        const messagesContainer = document.querySelector('.messages-container');
        const messageEl = document.createElement('div');
        messageEl.className = `message ${message.sender === 'me' ? 'sent' : 'received'}`;
        
        messageEl.innerHTML = `
            <div class="message-content">${this.escapeHtml(message.text)}</div>
            <div class="message-time">${message.timestamp}</div>
        `;
        
        messagesContainer.appendChild(messageEl);
    }

    loadMessagesForChat(chatId) {
        const messagesContainer = document.querySelector('.messages-container');
        messagesContainer.innerHTML = '';
        
        const chatMessages = this.messages[chatId] || [];
        chatMessages.forEach(message => this.renderMessage(message));
        
        this.scrollToBottom();
    }

    simulateResponse() {
        if (!this.currentChat) return;

        const responses = [
            "That's interesting!",
            "I agree with you.",
            "Tell me more about that.",
            "How was your day?",
            "Sounds good to me!",
            "That's great!",
            "I'm doing well, thanks!",
            "What are you up to?",
            "That's cool!",
            "I understand what you mean."
        ];

        const responseText = responses[Math.floor(Math.random() * responses.length)];
        
        const response = {
            id: Date.now(),
            text: responseText,
            sender: 'other',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            chatId: this.currentChat.id
        };

        this.addMessage(response);
        this.updateChatLastMessage(this.currentChat.id, responseText);
    }

    updateChatLastMessage(chatId, messageText) {
        const chat = this.chats.find(c => c.id === chatId);
        if (chat) {
            chat.lastMessage = messageText;
            chat.lastTime = 'Just now';
            this.renderChats();
        }
    }

    filterChats(searchTerm) {
        const chatItems = document.querySelectorAll('.chat-item');
        const term = searchTerm.toLowerCase();
        
        chatItems.forEach((item, index) => {
            const chat = this.chats[index];
            const matches = chat.name.toLowerCase().includes(term) || 
                           (chat.lastMessage && chat.lastMessage.toLowerCase().includes(term));
            item.style.display = matches ? 'flex' : 'none';
        });
    }

    handleSidebarAction(button) {
        const icon = button.querySelector('i');
        if (icon.classList.contains('fa-edit')) {
            this.showNotification('New message feature coming soon!');
        } else if (icon.classList.contains('fa-ellipsis-v')) {
            this.showNotification('More options coming soon!');
        }
    }

    handleChatAction(button) {
        const icon = button.querySelector('i');
        if (icon.classList.contains('fa-phone')) {
            this.showNotification('Voice call feature coming soon!');
        } else if (icon.classList.contains('fa-video')) {
            this.showNotification('Video call feature coming soon!');
        } else if (icon.classList.contains('fa-search')) {
            this.showNotification('Chat search feature coming soon!');
        } else if (icon.classList.contains('fa-ellipsis-v')) {
            this.showNotification('Chat options coming soon!');
        }
    }

    showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #374151;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    scrollToBottom() {
        const messagesContainer = document.querySelector('.messages-container');
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    renderChats() {
        const chatList = document.querySelector('.chat-list');
        chatList.innerHTML = '';
        
        this.chats.forEach((chat, index) => {
            const chatItem = document.createElement('div');
            chatItem.className = `chat-item ${index === 0 ? 'active' : ''}`;
            
            const avatarIcon = chat.type === 'group' ? 'fa-users' : 'fa-user-circle';
            const unreadBadge = chat.unreadCount > 0 ? `<span class="unread-count">${chat.unreadCount}</span>` : '';
            
            chatItem.innerHTML = `
                <div class="chat-avatar">
                    <i class="fas ${avatarIcon}"></i>
                </div>
                <div class="chat-content">
                    <div class="chat-header">
                        <span class="chat-name">${chat.name}</span>
                        <span class="chat-time">${chat.lastTime}</span>
                    </div>
                    <div class="chat-message">
                        <span class="last-message">${chat.lastMessage}</span>
                        ${unreadBadge}
                    </div>
                </div>
            `;
            
            chatList.appendChild(chatItem);
        });
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    saveMessages() {
        localStorage.setItem('telegramMessages', JSON.stringify(this.messages));
    }

    loadMessages() {
        const saved = localStorage.getItem('telegramMessages');
        return saved ? JSON.parse(saved) : this.getDefaultMessages();
    }

    saveChats() {
        localStorage.setItem('telegramChats', JSON.stringify(this.chats));
    }

    loadChats() {
        const saved = localStorage.getItem('telegramChats');
        return saved ? JSON.parse(saved) : this.getDefaultChats();
    }

    getDefaultMessages() {
        return {
            1: [
                { id: 1, text: "Hey, how are you?", sender: "other", timestamp: "10:30 AM", chatId: 1 },
                { id: 2, text: "I'm doing great! How about you?", sender: "me", timestamp: "10:32 AM", chatId: 1 },
                { id: 3, text: "Pretty good! Want to grab coffee later?", sender: "other", timestamp: "10:35 AM", chatId: 1 }
            ],
            2: [
                { id: 4, text: "See you tomorrow!", sender: "other", timestamp: "Yesterday", chatId: 2 }
            ],
            3: [
                { id: 5, text: "Meeting at 3 PM", sender: "other", timestamp: "Monday", chatId: 3 }
            ]
        };
    }

    getDefaultChats() {
        return [
            {
                id: 1,
                name: "John Doe",
                status: "Online",
                lastMessage: "Pretty good! Want to grab coffee later?",
                lastTime: "10:35 AM",
                unreadCount: 2,
                type: "private"
            },
            {
                id: 2,
                name: "Jane Smith",
                status: "Offline",
                lastMessage: "See you tomorrow!",
                lastTime: "Yesterday",
                unreadCount: 0,
                type: "private"
            },
            {
                id: 3,
                name: "Work Group",
                status: "5 members",
                lastMessage: "Meeting at 3 PM",
                lastTime: "Monday",
                unreadCount: 0,
                type: "group"
            }
        ];
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
    new TelegramClone();
});