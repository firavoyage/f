package com.example.minimalapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Creating a simple TextView programmatically to avoid layout XML dependency if preferred,
        // but I will also provide a layout XML for completeness.
        TextView textView = new TextView(this);
        textView.setText("Hello, Dependency-Free World!");
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(24);
        
        setContentView(textView);
    }
}
