// Sample data for contacts
const contacts = [
    { id: 1, name: 'John Doe', lastMessage: 'Hey! How are you?', time: '14:30', unread: 2, avatar: 'JD' },
    { id: 2, name: 'Alice Smith', lastMessage: 'See you tomorrow!', time: '12:15', unread: 0, avatar: 'AS' },
    { id: 3, name: 'Bob Johnson', lastMessage: 'Thanks for the help', time: '10:45', unread: 1, avatar: 'BJ' },
    { id: 4, name: 'Emma Wilson', lastMessage: '😊', time: '09:20', unread: 0, avatar: 'EW' },
    { id: 5, name: 'Mike Davis', lastMessage: 'Can we meet later?', time: 'Yesterday', unread: 0, avatar: 'MD' },
    { id: 6, name: 'Sarah Brown', lastMessage: 'Great idea!', time: 'Yesterday', unread: 0, avatar: 'SB' },
    { id: 7, name: 'Tech Group', lastMessage: 'John: Updated the docs', time: '2 days ago', unread: 5, avatar: 'TG' },
    { id: 8, name: 'Mom', lastMessage: 'Call me when you get home', time: '3 days ago', unread: 0, avatar: 'M' }
];

// Sample messages for each contact
const messages = {
    1: [
        { text: 'Hey! How are you?', time: '14:30', sender: 'other' },
        { text: 'I\'m doing great! How about you?', time: '14:31', sender: 'me' },
        { text: 'Not bad at all! Got any plans for the weekend?', time: '14:32', sender: 'other' },
        { text: 'Was thinking of going hiking. Want to join?', time: '14:33', sender: 'me' }
    ],
    2: [
        { text: 'See you tomorrow!', time: '12:15', sender: 'other' },
        { text: 'Looking forward to it!', time: '12:16', sender: 'me' }
    ],
    3: [
        { text: 'Thanks for the help', time: '10:45', sender: 'other' }
    ],
    4: [
        { text: '😊', time: '09:20', sender: 'other' }
    ]
};

// DOM elements
const chatList = document.getElementById('chatList');
const messagesContainer = document.getElementById('messagesContainer');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const currentChatName = document.getElementById('currentChatName');
const currentChatStatus = document.getElementById('currentChatStatus');
const currentChatAvatar = document.getElementById('currentChatAvatar');
const searchInput = document.getElementById('searchInput');

let currentContact = null;

// Initialize the application
function initializeApp() {
    renderContacts();
    setupEventListeners();

    // Show first contact by default
    if (contacts.length > 0) {
        selectContact(contacts[0]);
    }
}

// Render contacts in sidebar
function renderContacts(searchQuery = '') {
    chatList.innerHTML = '';

    const filteredContacts = contacts.filter(contact =>
        contact.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    filteredContacts.forEach(contact => {
        const chatItem = createContactElement(contact);
        chatList.appendChild(chatItem);
    });
}

// Create contact element
function createContactElement(contact) {
    const chatItem = document.createElement('div');
    chatItem.className = 'chat-item';
    chatItem.onclick = () => selectContact(contact);

    const unreadBadge = contact.unread > 0 ? `<span class="chat-time" style="color: #3390ec; font-weight: bold;">${contact.unread}</span>` : `<span class="chat-time">${contact.time}</span>`;

    chatItem.innerHTML = `
        <div class="chat-avatar">${contact.avatar}</div>
        <div class="chat-info">
            <div class="chat-name">${contact.name}</div>
            <div class="chat-last-message">${contact.lastMessage}</div>
        </div>
        ${unreadBadge}
    `;

    if (currentContact && contact.id === currentContact.id) {
        chatItem.classList.add('active');
    }

    return chatItem;
}

// Select a contact to chat with
function selectContact(contact) {
    // Remove active class from previous contact
    const activeItems = document.querySelectorAll('.chat-item.active');
    activeItems.forEach(item => item.classList.remove('active'));

    // Add active class to new contact
    event.target.closest('.chat-item')?.classList.add('active');

    currentContact = contact;

    // Update header
    currentChatName.textContent = contact.name;
    currentChatStatus.textContent = 'Online';
    currentChatAvatar.src = `https://via.placeholder.com/40/3390ec/ffffff?text=${contact.avatar}`;

    // Load messages
    loadMessages(contact.id);

    // Mark as read
    contact.unread = 0;
    renderContacts();
}

// Load messages for the selected contact
function loadMessages(contactId) {
    messagesContainer.innerHTML = '';

    const contactMessages = messages[contactId] || [];

    contactMessages.forEach(message => {
        addMessage(message.text, message.sender === 'me', message.time);
    });

    scrollToBottom();
}

// Add a new message to the chat
function addMessage(text, isSent = true, time = null) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isSent ? 'sent' : 'received'}`;

    const messageTime = time || getCurrentTime();

    messageDiv.innerHTML = `
        <div class="message-bubble">
            ${text}
            <div class="message-time">${messageTime}</div>
        </div>
    `;

    messagesContainer.appendChild(messageDiv);

    // Store the message if it's a real contact
    if (currentContact && !time) {
        if (!messages[currentContact.id]) {
            messages[currentContact.id] = [];
        }
        messages[currentContact.id].push({
            text: text,
            time: messageTime,
            sender: isSent ? 'me' : 'other'
        });

        // Update last message in contact
        currentContact.lastMessage = text;
        renderContacts();
    }

    scrollToBottom();
}

// Send a message
function sendMessage() {
    const text = messageInput.value.trim();
    if (text === '' || !currentContact) return;

    addMessage(text, true);
    messageInput.value = '';
    sendButton.disabled = true;

    // Simulate automatic reply after 1-2 seconds
    setTimeout(() => {
        if (currentContact) {
            const replies = [
                'Sounds good!',
                'Interesting...',
                'Tell me more!',
                'I agree',
                'Thanks for sharing',
                'Got it 👍',
                '😊',
                'Hmm... let me think about that',
                'Great idea!',
                'I\'m on it'
            ];
            const randomReply = replies[Math.floor(Math.random() * replies.length)];
            addMessage(randomReply, false);
        }
    }, Math.random() * 1500 + 1000);
}

// Get current time in HH:MM format
function getCurrentTime() {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
}

// Scroll to bottom of messages
function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Setup event listeners
function setupEventListeners() {
    // Send message on button click
    sendButton.addEventListener('click', sendMessage);

    // Send message on Enter key
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Enable/disable send button based on message content
    messageInput.addEventListener('input', (e) => {
        sendButton.disabled = e.target.value.trim() === '';
    });

    // Search contacts
    searchInput.addEventListener('input', (e) => {
        renderContacts(e.target.value);
    });

    // Emoji button click (placeholder)
    document.querySelector('.message-input-wrapper .fa-smile').addEventListener('click', () => {
        // In a real app, this would open an emoji picker
        alert('Emoji picker would open here!');
    });

    // Microphone button click (placeholder)
    document.querySelector('.message-input-wrapper .fa-microphone').addEventListener('click', () => {
        // In a real app, this would start voice recording
        alert('Voice recording would start here!');
    });
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeApp);