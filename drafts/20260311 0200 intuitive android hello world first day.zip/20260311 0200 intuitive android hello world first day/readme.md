hello world

---

build

```sh
JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64 ./gradlew clean assembleDebug
```
