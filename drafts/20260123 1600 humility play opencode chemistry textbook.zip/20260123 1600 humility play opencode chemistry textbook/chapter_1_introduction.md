# Chapter 1: Introduction to Chemistry

## Learning Objectives
By the end of this chapter, you will be able to:
- Define chemistry and explain its importance in everyday life
- Apply the scientific method to solve problems
- Identify the main branches of chemistry
- Recognize chemistry applications in real-world contexts
- Follow basic laboratory safety procedures

## 1.1 What is Chemistry?

**Chemistry** is the scientific study of matter and the changes it undergoes. It is often called the "central science" because it connects physics, biology, and other natural sciences.

**Key Concepts:**
- **Matter**: Anything that has mass and occupies space
- **Substance**: A particular kind of matter with uniform properties
- **Property**: A characteristic that can be used to identify a substance

### Why Study Chemistry?
Understanding chemistry helps us:
- Make informed decisions about health and environment
- Develop new materials and technologies
- Understand natural processes in our bodies and environment
- Solve problems related to energy, food, and medicine

## 1.2 The Scientific Method

The scientific method is a systematic approach to investigating questions and solving problems. While it's often presented as a linear process, scientists frequently move back and forth between steps.

### Steps of the Scientific Method:

1. **Observation**: Noticing and describing phenomena
   - Example: "When I add baking soda to vinegar, bubbles form"

2. **Question**: Formulating a testable question
   - Example: "What gas is produced when baking soda reacts with vinegar?"

3. **Hypothesis**: An educated guess that can be tested
   - Example: "The reaction between baking soda and vinegar produces carbon dioxide gas"

4. **Experiment**: Designing and conducting controlled tests
   - Example: Capture the gas and test its properties

5. **Analysis**: Interpreting data and results
   - Example: The gas extinguishes a flame, indicating it's carbon dioxide

6. **Conclusion**: Accepting or rejecting the hypothesis
   - Example: The hypothesis is supported by evidence

7. **Communication**: Sharing results with others
   - Example: Publishing findings or presenting at a science fair

### Example Experiment:

**Question:** Does temperature affect how quickly sugar dissolves in water?

**Hypothesis:** Sugar will dissolve faster in hot water than in cold water.

**Procedure:**
1. Measure 100 mL of cold water (20°C) and 100 mL of hot water (80°C)
2. Add 5 grams of sugar to each
3. Time how long it takes for all sugar to dissolve
4. Repeat three times for accuracy

**Expected Results:** Sugar dissolves much faster in hot water, supporting the hypothesis.

## 1.3 Branches of Chemistry

Chemistry is divided into several specialized branches, each focusing on different aspects of matter and its interactions.

### Main Branches:

1. **Organic Chemistry**: Study of carbon-containing compounds
   - Applications: Medicines, plastics, fuels
   - Example compounds: Methane (CH₄), glucose (C₆H₁₂O₆)

2. **Inorganic Chemistry**: Study of non-organic compounds
   - Applications: Catalysts, electronic materials
   - Example compounds: Sodium chloride (NaCl), sulfuric acid (H₂SO₄)

3. **Physical Chemistry**: Study of physical properties and behavior of matter
   - Applications: Energy storage, reaction rates
   - Focus: Thermodynamics, kinetics, quantum mechanics

4. **Analytical Chemistry**: Identification and quantification of chemical substances
   - Applications: Quality control, environmental testing
   - Techniques: Spectroscopy, chromatography

5. **Biochemistry**: Study of chemical processes in living organisms
   - Applications: Medicine, genetics, nutrition
   - Focus: Enzymes, DNA, proteins

6. **Environmental Chemistry**: Study of chemical processes in the environment
   - Applications: Pollution control, climate change
   - Focus: Air quality, water treatment, soil chemistry

7. **Nuclear Chemistry**: Study of radioactive elements and nuclear reactions
   - Applications: Medical imaging, energy production
   - Focus: Radioactive decay, nuclear fission/fusion

## 1.4 Chemistry in Everyday Life

Chemistry is all around us! Here are some examples:

### In the Kitchen:
- **Cooking**: Chemical reactions change food properties (egg coagulation, Maillard browning)
- **Baking**: Chemical leavening agents produce carbon dioxide gas
- **Food preservation**: Salt and sugar prevent bacterial growth

### Personal Care:
- **Soap**: Fatty acids react with sodium hydroxide to form soap
- **Toothpaste**: Contains fluoride compounds that strengthen tooth enamel
- **Deodorant**: Contains compounds that neutralize odor-causing bacteria

### Transportation:
- **Fuel combustion**: Gasoline reacts with oxygen to produce energy
- **Battery operation**: Chemical reactions produce electrical energy
- **Tire materials**: Rubber polymers provide flexibility and durability

### Health:
- **Medicines**: Chemical compounds treat diseases and symptoms
- **Vitamins**: Essential organic compounds for body function
- **Anesthesia**: Chemicals that temporarily block nerve signals

### Environment:
- **Photosynthesis**: Plants convert carbon dioxide and water into glucose and oxygen
- **Water treatment**: Chemicals remove impurities from drinking water
- **Air quality monitoring**: Detection and measurement of pollutants

## 1.5 Laboratory Safety and Equipment

### Laboratory Safety Rules:

**Personal Protection:**
- Always wear safety goggles when working with chemicals
- Wear lab coats or aprons to protect clothing
- Use gloves when handling hazardous materials
- Tie back long hair and avoid loose clothing

**General Safety:**
- Never eat or drink in the laboratory
- Know the location of safety equipment (eyewash station, fire extinguisher, first aid kit)
- Work in a well-ventilated area or use a fume hood
- Never smell chemicals directly; use your hand to waft fumes toward your nose
- Always add acid to water, never water to acid
- Dispose of waste properly according to instructions

### Common Laboratory Equipment:

**Measuring Tools:**
- **Graduated cylinder**: Measures liquid volume
- **Volumetric flask**: Precise volume measurement
- **Balance**: Measures mass
- **Thermometer**: Measures temperature

**Holding and Heating:**
- **Beaker**: Holds liquids for mixing
- **Erlenmeyer flask**: Holds liquids for mixing and heating
- **Test tube**: Holds small amounts of substances
- **Bunsen burner**: Provides heat for experiments

**Safety Equipment:**
- **Safety shower**: For chemical spills on body
- **Eyewash station**: For eye contamination
- **Fire blanket**: For smothering fires
- **Fire extinguisher**: For different types of fires

### Basic Laboratory Techniques:

**Measuring Liquids:**
- Place the measuring container on a flat surface
- Read the volume at eye level
- Read the bottom of the meniscus (curved surface of liquid)

**Heating Liquids:**
- Use a Bunsen burner or hot plate
- Never heat a closed container
- Use appropriate glassware that can withstand heat

**Mixing Solutions:**
- Use a glass stirring rod or magnetic stirrer
- Add substances slowly to avoid splashing
- Clean equipment thoroughly between uses

## Chapter Summary

- Chemistry is the study of matter and its changes
- The scientific method provides a systematic approach to problem-solving
- Chemistry has many branches, each focusing on different aspects of matter
- Chemistry is present in virtually every aspect of daily life
- Laboratory safety is essential when conducting chemical experiments

## Key Terms

- Chemistry
- Matter
- Scientific method
- Hypothesis
- Organic chemistry
- Inorganic chemistry
- Physical chemistry
- Analytical chemistry
- Biochemistry
- Meniscus

## Review Questions

### Multiple Choice
1. Which of the following best defines chemistry?
   a) The study of living organisms
   b) The study of matter and its changes
   c) The study of Earth and its processes
   d) The study of numbers and calculations

2. What is the first step in the scientific method?
   a) Forming a hypothesis
   b) Conducting an experiment
   c) Making an observation
   d) Drawing a conclusion

3. Which branch of chemistry studies carbon-containing compounds?
   a) Inorganic chemistry
   b) Organic chemistry
   c) Physical chemistry
   d) Analytical chemistry

### True/False
4. Chemistry is only important for scientists and researchers.
5. The scientific method always proceeds in a straight line from observation to conclusion.

### Short Answer
6. Explain why chemistry is called the "central science."
7. Describe three examples of chemistry in your daily life.
8. What safety precautions should you take when working with chemicals?

### Critical Thinking
9. Design a simple experiment to test whether sugar dissolves faster in hot or cold water. Include your hypothesis, procedure, and expected results.

10. Why is it important to communicate scientific results to others?

## Practice Problems

1. **Observation Skills**: Observe the room you're in and list 5 different materials. For each material, suggest one chemical property you could test.

2. **Scientific Method Application**: You notice that plants near a street grow slower than plants farther from the street. Apply the scientific method to investigate this observation.

3. **Safety Scenario**: What would you do if you accidentally spilled a small amount of acid on your lab bench?

4. **Branches of Chemistry**: Classify the following studies into the appropriate branch of chemistry:
   a) Determining the amount of lead in drinking water
   b) Developing a new plastic material
   c) Studying how enzymes break down food
   d) Understanding why metals rust

## Laboratory Activity: The Baking Soda and Volcano

**Objective:** To observe a chemical reaction and practice laboratory safety.

**Materials:**
- Small plastic bottle
- 2 tablespoons baking soda
- 1/4 cup vinegar
- Red food coloring (optional)
- Dish soap (optional)
- Safety goggles
- Tray or dish to catch overflow

**Procedure:**
1. Put on safety goggles
2. Place the bottle on the tray
3. Add baking soda to the bottle
4. Add a few drops of food coloring and dish soap if desired
5. Quickly pour vinegar into the bottle
6. Observe the reaction
7. Record your observations
8. Clean up according to teacher instructions

**Questions:**
1. What did you observe when you mixed the ingredients?
2. What gas do you think was produced?
3. How could you test your hypothesis about the gas produced?
4. What safety precautions did you follow during this experiment?

---

**Note to Teachers:** This chapter provides foundational knowledge for the entire chemistry course. Consider demonstrating the baking soda volcano reaction at the beginning of class to generate student interest and provide a concrete example of chemical change.