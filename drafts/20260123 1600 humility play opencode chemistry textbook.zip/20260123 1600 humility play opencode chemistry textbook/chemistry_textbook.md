# COMPREHENSIVE HIGH SCHOOL CHEMISTRY TEXTBOOK

## Table of Contents

### Chapter 1: Introduction to Chemistry and Matter
1.1 What is Chemistry?
1.2 The Scientific Method
1.3 Matter and Its Properties
1.4 Classification of Matter
1.5 Measurement and Units
1.6 Significant Figures and Scientific Notation
1.7 Dimensional Analysis
1.8 Laboratory Safety and Equipment

### Chapter 2: Atomic Structure and Periodic Table
2.1 Early Atomic Theory
2.2 Structure of the Atom
2.3 Subatomic Particles
2.4 Isotopes and Atomic Mass
2.5 Electron Configuration
2.6 The Periodic Table: Organization
2.7 Periodic Trends
2.8 Groups and Families of Elements

### Chapter 3: Chemical Bonding and Molecular Structure
3.1 Types of Chemical Bonds
3.2 Ionic Bonding
3.3 Covalent Bonding
3.4 Lewis Structures
3.5 VSEPR Theory and Molecular Geometry
3.6 Polarity of Molecules
3.7 Intermolecular Forces
3.8 Metallic Bonding

### Chapter 4: Chemical Reactions and Equations
4.1 Evidence of Chemical Reactions
4.2 Writing Chemical Equations
4.3 Balancing Chemical Equations
4.4 Types of Chemical Reactions
4.5 Predicting Products of Reactions
4.6 Net Ionic Equations
4.7 Redox Reactions

### Chapter 5: Stoichiometry and the Mole
5.1 The Mole Concept
5.2 Molar Mass
5.3 Percent Composition
5.4 Empirical and Molecular Formulas
5.5 Stoichiometric Calculations
5.6 Limiting Reactants
5.7 Percent Yield
5.8 Solution Stoichiometry

### Chapter 6: States of Matter and Gas Laws
6.1 The Kinetic Molecular Theory
6.2 Properties of Gases
6.3 Gas Laws: Boyle's, Charles's, and Avogadro's
6.4 The Ideal Gas Law
6.5 Real Gases
6.6 Properties of Liquids
6.7 Properties of Solids
6.8 Phase Changes

### Chapter 7: Solutions and Concentrations
7.1 Solutions: Types and Properties
7.2 Solubility
7.3 Concentration Units
7.4 Dilution Calculations
7.5 Colligative Properties
7.6 Colloids and Suspensions

### Chapter 8: Acids, Bases, and pH
8.1 Properties of Acids and Bases
8.2 Theories of Acids and Bases
8.3 Strong and Weak Acids/Bases
8.4 pH and pOH Calculations
8.5 Acid-Base Titrations
8.6 Buffers
8.7 Hydrolysis of Salts

### Chapter 9: Thermochemistry
9.1 Energy and Chemical Reactions
9.2 Heat and Temperature
9.3 Calorimetry
9.4 Enthalpy Changes
9.5 Hess's Law
9.6 Enthalpy of Formation
9.7 Bond Energies

### Chapter 10: Chemical Kinetics and Equilibrium
10.1 Reaction Rates
10.2 Factors Affecting Reaction Rates
10.3 Rate Laws
10.4 Reaction Mechanisms
10.5 Chemical Equilibrium
10.6 Le Chatelier's Principle
10.7 Equilibrium Calculations
10.8 Solubility Equilibrium

### Chapter 11: Electrochemistry
11.1 Oxidation-Reduction Reactions
11.2 Balancing Redox Equations
11.3 Electrochemical Cells
11.4 Cell Potential
11.5 Electrolysis
11.6 Applications of Electrochemistry

### Chapter 12: Nuclear Chemistry
12.1 Radioactivity
12.2 Types of Nuclear Decay
12.3 Nuclear Reactions
12.4 Half-Life and Radioactive Dating
12.5 Nuclear Fission and Fusion
12.6 Applications of Nuclear Chemistry

### Chapter 13: Organic Chemistry Basics
13.1 Introduction to Organic Chemistry
13.2 Hydrocarbons
13.3 Functional Groups
13.4 Isomerism
13.5 Basic Organic Reactions
13.6 Polymers

### Appendices
A. Periodic Table of Elements
B. Common Ion Charges
C. Solubility Rules
D. Important Constants and Conversions
E. Laboratory Techniques
F. Mathematical Review
G. Glossary of Terms

---

## Chapter 1: Introduction to Chemistry and Matter

### 1.1 What is Chemistry?

Chemistry is the scientific study of matter and the changes it undergoes. It is often called the "central science" because it connects physics, biology, geology, and other sciences. Chemistry seeks to understand:

- What matter is made of
- How matter is organized
- How matter interacts and changes
- The energy changes that accompany these changes

**Branches of Chemistry:**
- **Organic Chemistry**: Study of carbon-containing compounds
- **Inorganic Chemistry**: Study of non-organic compounds
- **Physical Chemistry**: Study of the physical properties of molecules
- **Analytical Chemistry**: Study of the composition of matter
- **Biochemistry**: Study of chemical processes in living organisms
- **Environmental Chemistry**: Study of chemical phenomena in the environment

### 1.2 The Scientific Method

The scientific method is a systematic approach to investigating phenomena and acquiring knowledge:

1. **Observation**: Noticing a phenomenon or asking a question
2. **Hypothesis**: Formulating a testable explanation
3. **Experiment**: Designing and conducting controlled tests
4. **Data Collection**: Gathering quantitative and qualitative information
5. **Analysis**: Interpreting the data and drawing conclusions
6. **Conclusion**: Accepting, modifying, or rejecting the hypothesis
7. **Publication**: Sharing results with the scientific community

**Key Concepts:**
- A **theory** is a well-substantiated explanation backed by extensive evidence
- A **law** describes what happens in nature without explaining why
- **Models** are simplified representations that help us understand complex systems

### 1.3 Matter and Its Properties

**Matter** is anything that has mass and occupies space. Matter can be described by its properties:

**Physical Properties:** Can be observed without changing the substance's identity
- Color, odor, taste
- Density, melting point, boiling point
- Hardness, conductivity, solubility

**Chemical Properties:** Describe how a substance changes into new substances
- Reactivity with acids, bases, oxygen
- Flammability, toxicity
- Stability under various conditions

**Intensive Properties:** Do not depend on the amount of matter
- Temperature, pressure
- Density, boiling point
- Color

**Extensive Properties:** Depend on the amount of matter
- Mass, volume
- Length, weight

### 1.4 Classification of Matter

Matter can be classified in several ways:

**By State:**
- **Solid**: Definite shape and volume
- **Liquid**: Definite volume, indefinite shape
- **Gas**: Indefinite shape and volume
- **Plasma**: Ionized gas with free electrons

**By Composition:**
- **Pure Substances**: Fixed composition, definite properties
  - **Elements**: Cannot be broken down by chemical means (e.g., O₂, Fe)
  - **Compounds**: Can be broken down into simpler substances (e.g., H₂O, NaCl)
- **Mixtures**: Variable composition, can be separated by physical means
  - **Homogeneous**: Uniform composition throughout (solutions, alloys)
  - **Heterogeneous**: Non-uniform composition (salad, sand and water)

### 1.5 Measurement and Units

**SI Base Units:**
- Length: meter (m)
- Mass: kilogram (kg)
- Time: second (s)
- Temperature: Kelvin (K)
- Amount of substance: mole (mol)
- Electric current: ampere (A)
- Luminous intensity: candela (cd)

**Common Derived Units:**
- Volume: cubic meter (m³) or liter (L)
- Density: kilograms per cubic meter (kg/m³) or grams per milliliter (g/mL)
- Concentration: moles per liter (mol/L) or molarity (M)
- Energy: joule (J)
- Pressure: pascal (Pa) or atmosphere (atm)

**Temperature Scales:**
- **Celsius (°C)**: Water freezes at 0°C, boils at 100°C
- **Kelvin (K)**: Absolute scale, 0 K = -273.15°C
- **Fahrenheit (°F)**: Water freezes at 32°F, boils at 212°F

**Conversion:**
K = °C + 273.15
°F = (9/5)°C + 32

### 1.6 Significant Figures and Scientific Notation

**Significant Figures:** Digits that carry meaning in a measurement

**Rules for Significant Figures:**
1. All non-zero digits are significant
2. Zeros between non-zero digits are significant
3. Leading zeros are not significant
4. Trailing zeros after decimal are significant
5. Trailing zeros without decimal may or may not be significant

**Examples:**
- 45.67 → 4 significant figures
- 0.0032 → 2 significant figures
- 1000 → ambiguous, use scientific notation
- 1.00 × 10³ → 3 significant figures

**Scientific Notation:** Expresses numbers as a × 10^n, where 1 ≤ a < 10

**Arithmetic with Significant Figures:**
- **Addition/Subtraction**: Round to the least precise decimal place
- **Multiplication/Division**: Round to the fewest significant figures

### 1.7 Dimensional Analysis

Dimensional analysis is a problem-solving method that uses conversion factors to change units.

**Method:**
1. Identify the given quantity and desired quantity
2. Write conversion factors as fractions equal to 1
3. Arrange so unwanted units cancel
4. Multiply numerators and denominators
5. Simplify and express answer with appropriate units

**Example:** Convert 5.2 ft to meters
Given: 1 m = 3.281 ft

5.2 ft × (1 m / 3.281 ft) = 1.585 m = 1.59 m (3 sig figs)

**Common Conversion Factors:**
- Length: 1 inch = 2.54 cm, 1 mile = 1.609 km
- Mass: 1 lb = 453.6 g, 1 kg = 2.205 lb
- Volume: 1 L = 1000 mL, 1 gal = 3.785 L
- Energy: 1 cal = 4.184 J

### 1.8 Laboratory Safety and Equipment

**Laboratory Safety Rules:**
1. Always wear appropriate personal protective equipment (PPE)
2. Never eat, drink, or chew gum in the laboratory
3. Know the location of safety equipment
4. Follow instructions carefully
5. Report all accidents immediately
6. Dispose of waste properly
7. Never work alone without supervision

**Personal Protective Equipment:**
- Safety goggles
- Lab coat or apron
- Closed-toe shoes
- Gloves (when required)

**Safety Equipment:**
- Fire extinguisher
- Safety shower
- Eyewash station
- Fume hood
- First aid kit

**Common Laboratory Equipment:**
- **Glassware:** Beakers, flasks, graduated cylinders, test tubes
- **Measuring devices:** Balances, rulers, thermometers
- **Heating devices:** Bunsen burners, hot plates
- **Mixing tools:** Stirring rods, magnetic stirrers
- **Separation tools:** Funnels, filter paper, separatory funnels

**Proper Glassware Handling:**
- Inspect for cracks or chips before use
- Use appropriate clamps and holders
- Heat glassware gradually
- Cool glassware slowly
- Clean thoroughly after use

**Emergency Procedures:**
- **Fire:** Stop, drop, and roll if clothing catches fire; use fire extinguisher for other fires
- **Chemical spills:** Neutralize if possible, then clean up with appropriate materials
- **Eye exposure:** Flush with water for at least 15 minutes
- **Inhalation:** Move to fresh air immediately

---

**Chapter Summary:**
Chemistry is the study of matter and its changes. Matter can be classified by its physical and chemical properties, and organized as elements, compounds, or mixtures. Scientific measurements require understanding of units, significant figures, and dimensional analysis. Laboratory work demands strict adherence to safety protocols and proper use of equipment. This foundation prepares us for deeper exploration of atomic structure, chemical bonding, and reactions in subsequent chapters.

**Key Terms to Remember:**
- Matter, element, compound, mixture
- Physical property, chemical property
- Intensive property, extensive property
- Significant figure, scientific notation
- Dimensional analysis
- PPE, safety protocols

**Review Questions:**
1. What distinguishes an element from a compound?
2. How would you separate a homogeneous mixture from a heterogeneous mixture?
3. Why are significant figures important in scientific measurements?
4. List five essential laboratory safety rules and explain their importance.

---

## Chapter 2: Atomic Structure and Periodic Table

### 2.1 Early Atomic Theory

**Democritus (460-370 BC)**
- First to propose that matter is composed of indivisible particles called "atomos"
- Believed atoms were solid, indestructible, and differed in shape and size

**John Dalton (1766-1844) - Dalton's Atomic Theory**
1. All matter is composed of atoms
2. Atoms of the same element are identical
3. Atoms of different elements have different properties
4. Atoms cannot be created, destroyed, or subdivided in chemical reactions
5. Atoms combine in simple whole-number ratios to form compounds
6. In chemical reactions, atoms are combined, separated, or rearranged

**J.J. Thomson (1856-1940)**
- Discovered the electron in 1897 using cathode ray tubes
- Proposed the "plum pudding" model: atoms consist of positively charged matter with embedded electrons

**Ernest Rutherford (1871-1937)**
- Gold foil experiment (1911) showed that atoms have a small, dense, positively charged nucleus
- Most of the atom is empty space
- Electrons orbit around the nucleus

**Niels Bohr (1885-1962)**
- Bohr model (1913): electrons orbit nucleus in fixed energy levels
- Electrons can jump between levels by absorbing or emitting energy
- Explained hydrogen spectrum but failed for multi-electron atoms

### 2.2 Structure of the Atom

**Atomic Structure Components:**

**Nucleus:**
- Protons: positively charged, mass = 1.0073 amu
- Neutrons: neutral, mass = 1.0087 amu
- Contains nearly all of the atom's mass
- Diameter approximately 1/10,000 of the entire atom

**Electron Cloud:**
- Electrons: negatively charged, mass = 0.0005486 amu
- Move in probability clouds called orbitals
- Define the chemical behavior of the atom
- Number of electrons equals number of protons in neutral atoms

**Atomic Number (Z):** Number of protons in the nucleus
- Defines the element
- Same for all atoms of an element

**Mass Number (A):** Total number of protons and neutrons
- Can vary for the same element (isotopes)

**Notation:** ᴬZX where X = element symbol, A = mass number, Z = atomic number

### 2.3 Subatomic Particles

**Fundamental Properties:**

| Particle | Charge | Mass (amu) | Location |
|----------|--------|------------|----------|
| Proton | +1 | 1.0073 | Nucleus |
| Neutron | 0 | 1.0087 | Nucleus |
| Electron | -1 | 0.0005486 | Electron Cloud |

**Quarks:** Fundamental particles that make up protons and neutrons
- Protons: 2 up quarks (+2/3) + 1 down quark (-1/3) = +1
- Neutrons: 1 up quark (+2/3) + 2 down quarks (-1/3) = 0

**Fundamental Forces:**
- **Strong nuclear force:** Holds nucleus together
- **Weak nuclear force:** Responsible for radioactive decay
- **Electromagnetic force:** Attracts electrons to nucleus
- **Gravitational force:** Negligible at atomic scale

### 2.4 Isotopes and Atomic Mass

**Isotopes:** Atoms of the same element with different numbers of neutrons
- Same atomic number (Z)
- Different mass numbers (A)
- Similar chemical properties
- Different physical properties

**Examples:**
- Hydrogen isotopes: ¹H (protium), ²H (deuterium), ³H (tritium)
- Carbon isotopes: ¹²C (98.9%), ¹³C (1.1%), ¹⁴C (trace, radioactive)

**Atomic Mass:** Weighted average of naturally occurring isotopes
- Atomic mass = Σ(isotope mass × fractional abundance)

**Example:** Carbon
- ¹²C: 12.000 amu × 0.989 = 11.868 amu
- ¹³C: 13.003 amu × 0.011 = 0.143 amu
- Average atomic mass = 11.868 + 0.143 = 12.011 amu

### 2.5 Electron Configuration

**Quantum Numbers:** Describe electron properties

1. **Principal Quantum Number (n):** Energy level, n = 1, 2, 3...
2. **Angular Momentum Quantum Number (l):** Subshell shape, l = 0 to n-1
   - s (l=0), p (l=1), d (l=2), f (l=3)
3. **Magnetic Quantum Number (ml):** Orbital orientation, ml = -l to +l
4. **Spin Quantum Number (ms):** Electron spin, ms = +½ or -½

**Electron Configuration Rules:**

**Aufbau Principle:** Electrons fill lowest energy orbitals first
- Order: 1s → 2s → 2p → 3s → 3p → 4s → 3d → 4p → 5s → 4d → 5p → 6s...

**Pauli Exclusion Principle:** No two electrons in an atom can have identical quantum numbers
- Maximum 2 electrons per orbital with opposite spins

**Hund's Rule:** Electrons occupy orbitals of same energy singly before pairing

**Examples:**
- Hydrogen (1 electron): 1s¹
- Carbon (6 electrons): 1s² 2s² 2p²
- Oxygen (8 electrons): 1s² 2s² 2p⁴
- Sodium (11 electrons): 1s² 2s² 2p⁶ 3s¹

**Noble Gas Notation:**
- Carbon: [He] 2s² 2p²
- Sodium: [Ne] 3s¹
- Iron: [Ar] 4s² 3d⁶

### 2.6 The Periodic Table: Organization

**Historical Development:**
- **Dmitri Mendeleev (1869):** Arranged elements by atomic mass and properties
- **Henry Moseley (1913):** Discovered atomic number as organizing principle
- **Glenn Seaborg (1940s):** Arranged actinides below lanthanides

**Periodic Table Structure:**
- **Periods:** Horizontal rows (1-7), indicate principal energy level
- **Groups:** Vertical columns (1-18), indicate similar chemical properties
- **Blocks:** s-block (Groups 1-2, helium), p-block (Groups 13-18), d-block (transition metals), f-block (lanthanides and actinides)

**Major Groups:**
- **Group 1:** Alkali metals (1 valence electron)
- **Group 2:** Alkaline earth metals (2 valence electrons)
- **Group 17:** Halogens (7 valence electrons)
- **Group 18:** Noble gases (full valence shell)
- **Transition metals:** d-block, variable oxidation states

**Classification by Properties:**
- **Metals:** Shiny, good conductors, malleable, ductile
- **Nonmetals:** Dull, poor conductors, brittle
- **Metalloids:** Properties of both metals and nonmetals

### 2.7 Periodic Trends

**Atomic Radius:** Distance from nucleus to outermost electron
- **Trend:** Decreases across period, increases down group
- **Reason:** Increasing nuclear charge across period pulls electrons closer; additional electron shells down group increase size

**Ionization Energy:** Energy required to remove an electron from gas phase atom
- **Trend:** Increases across period, decreases down group
- **Reason:** Higher nuclear charge across period holds electrons tighter; electrons further from nucleus down group are easier to remove

**Electron Affinity:** Energy change when electron added to gas phase atom
- **Trend:** Generally becomes more negative across period, less negative down group
- **Reason:** Higher nuclear charge across period attracts electrons more strongly

**Electronegativity:** Tendency of atom to attract electrons in chemical bond
- **Trend:** Increases across period, decreases down group
- **Pauling scale values:** F (3.98) highest, Cs (0.79) lowest

**Metallic Character:** Tendency to lose electrons
- **Trend:** Decreases across period, increases down group
- **Reason:** Opposite of electronegativity trend

### 2.8 Groups and Families of Elements

**Alkali Metals (Group 1):**
- Properties: Soft, silvery, low density, highly reactive
- Reactivity: Increases down group
- Uses: Batteries, soaps, medicine
- Reactions: Form +1 ions, react vigorously with water

**Alkaline Earth Metals (Group 2):**
- Properties: Harder, higher melting points than alkali metals
- Reactivity: Less reactive than alkali metals
- Uses: Construction, medicine, fireworks
- Reactions: Form +2 ions

**Transition Metals (Groups 3-12):**
- Properties: High melting points, multiple oxidation states, colored compounds
- Uses: Catalysts, construction, electronics
- Special properties: Formation of complex ions, variable valence

**Halogens (Group 17):**
- Properties: Diatomic molecules, highly reactive nonmetals
- Reactivity: Decreases down group
- Uses: Disinfectants, lighting, pharmaceuticals
- Reactions: Form -1 ions, react with metals to form salts

**Noble Gases (Group 18):**
- Properties: Colorless, odorless, very low reactivity
- Uses: Lighting, welding, atmosphere control
- Special: Complete valence electron shells

**Lanthanides and Actinides:**
- **Lanthanides:** "Rare earth elements," similar properties
- **Actinides:** All radioactive, most are synthetic

**Metalloids:** B, Si, Ge, As, Sb, Te, Po
- Properties between metals and nonmetals
- Important in semiconductors and electronics

---

**Chapter Summary:**
Atoms consist of protons, neutrons, and electrons arranged in a specific structure. Electrons occupy energy levels following quantum rules. The periodic table organizes elements by atomic number and recurring chemical properties. Periodic trends such as atomic radius, ionization energy, and electronegativity help predict element behavior. Understanding atomic structure is fundamental to explaining chemical bonding and reactions.

**Key Formulas:**
- Mass Number = Protons + Neutrons
- Atomic number = Protons = Electrons (in neutral atoms)
- Charge = Protons - Electrons

**Key Concepts:**
- Isotopes and atomic mass calculations
- Electron configuration rules
- Periodic trends and their explanations
- Group properties and characteristics

**Practice Problems:**
1. Write the electron configuration for phosphorus (P, Z=15).
2. Calculate the average atomic mass of an element with two isotopes: 80X (75% abundance, 79.92 amu) and 82X (25% abundance, 81.92 amu).
3. Arrange these elements in order of increasing electronegativity: Na, Cl, Mg, Ar.
4. Identify the group and period for the element with electron configuration [Kr] 5s² 4d¹⁰ 5p⁴.

---

## Chapter 3: Chemical Bonding and Molecular Structure

### 3.1 Types of Chemical Bonds

**Chemical Bond:** Attractive force that holds atoms or ions together

**Types of Bonds:**
1. **Ionic Bonds:** Electrostatic attraction between oppositely charged ions
2. **Covalent Bonds:** Sharing of electron pairs between atoms
3. **Metallic Bonds:** Delocalized electrons shared among metal atoms
4. **Hydrogen Bonds:** Special type of dipole-dipole attraction
5. **Van der Waals Forces:** Weak intermolecular attractions

**Bond Formation Principles:**
- Atoms bond to achieve stable electron configurations (often noble gas configuration)
- Electronegativity differences determine bond type
- Bond energy is released when bonds form
- Energy is required to break bonds

### 3.2 Ionic Bonding

**Ionic Bond Formation:**
- Transfer of electrons from metal to nonmetal
- Metal loses electrons (becomes cation, positive charge)
- Nonmetal gains electrons (becomes anion, negative charge)
- Electrostatic attraction holds ions together

**Characteristics of Ionic Compounds:**
- High melting and boiling points
- Crystalline solid structure
- Conduct electricity when melted or dissolved
- Soluble in polar solvents (like water)
- Usually formed between metals (low electronegativity) and nonmetals (high electronegativity)

**Electronegativity Difference:**
- ΔEN > 1.7: Generally ionic
- ΔEN < 1.7: Generally covalent

**Examples:**
- NaCl: Na (0.93) + Cl (3.16) = ΔEN = 2.23 (ionic)
- MgO: Mg (1.31) + O (3.44) = ΔEN = 2.13 (ionic)

**Lattice Energy:** Energy released when gaseous ions form solid ionic lattice
- Depends on ion charges and sizes
- Higher charges and smaller ions → higher lattice energy
- Example: MgO has higher lattice energy than NaCl

### 3.3 Covalent Bonding

**Covalent Bond Formation:**
- Sharing of electron pairs between atoms
- Usually between nonmetals with similar electronegativities
- Can be single, double, or triple bonds

**Types of Covalent Bonds:**

**Single Bond (σ bond):**
- One pair of shared electrons
- Head-on overlap of orbitals
- Free rotation around bond axis

**Double Bond (σ + π bond):**
- Two pairs of shared electrons
- One σ bond and one π bond
- Restricted rotation

**Triple Bond (σ + 2π bonds):**
- Three pairs of shared electrons
- One σ bond and two π bonds
- Linear geometry, very strong

**Bond Polarity:**
- **Nonpolar covalent:** Equal sharing (ΔEN < 0.5)
  - Examples: H₂, O₂, N₂, CH₄
- **Polar covalent:** Unequal sharing (0.5 ≤ ΔEN ≤ 1.7)
  - Examples: HCl, H₂O, NH₃
  - Creates partial charges (δ+, δ-)

**Coordinate Covalent Bond:**
- Both electrons in shared pair come from same atom
- Also called dative bond
- Example: NH₃ + H⁺ → NH₄⁺

### 3.4 Lewis Structures

**Lewis Structure:** Diagram showing valence electrons and bonding

**Steps for Drawing Lewis Structures:**

1. **Count total valence electrons:**
   - Add valence electrons for all atoms
   - Add electrons for negative charges, subtract for positive charges

2. **Identify central atom:**
   - Usually least electronegative (except hydrogen)
   - Never hydrogen in center position

3. **Draw skeleton structure:**
   - Connect atoms with single bonds
   - Each bond uses 2 electrons

4. **Distribute remaining electrons:**
   - Complete octets of outer atoms first
   - Place remaining electrons on central atom

5. **Check octet rule:**
   - If central atom lacks octet, form double/triple bonds
   - Move electron pairs from outer atoms to form multiple bonds

**Example: CO₂**
1. Valence electrons: C (4) + 2 × O (6) = 16
2. Central atom: C
3. Skeleton: O-C-O
4. Distribute: O=C=O with double bonds
5. Final structure: O=C=O (all octets satisfied)

**Common Exceptions to Octet Rule:**
- **Odd number of electrons:** NO, NO₂, ClO₂
- **Electron-deficient:** BF₃, BeCl₂
- **Expanded octet:** SF₆, PCl₅ (elements in period 3+)

**Formal Charge:** Bookkeeping method to assess Lewis structures
- Formal charge = Valence electrons - (Nonbonding electrons + Bonding electrons/2)
- Best structure minimizes formal charges
- Negative formal charges on more electronegative atoms

### 3.5 VSEPR Theory and Molecular Geometry

**VSEPR Theory:** Valence Shell Electron Pair Repulsion
- Electron pairs repel each other
- Arrange to minimize repulsion
- Molecular shape determined by arrangement of electron pairs

**Electron Pair Geometry vs Molecular Geometry:**

| Electron Pairs | Geometry | Bond Angles | Example |
|----------------|----------|-------------|---------|
| 2 | Linear | 180° | CO₂ |
| 3 | Trigonal planar | 120° | BF₃ |
| 4 | Tetrahedral | 109.5° | CH₄ |
| 5 | Trigonal bipyramidal | 90°, 120° | PCl₅ |
| 6 | Octahedral | 90° | SF₆ |

**Effect of Lone Pairs:**
- Lone pairs occupy more space than bonding pairs
- Order of repulsion: LP-LP > LP-BP > BP-BP
- Lone pairs decrease bond angles

**Common Molecular Geometries:**

**2 Electron Domains:**
- Linear: CO₂ (no lone pairs)

**3 Electron Domains:**
- Trigonal planar: BF₃ (no lone pairs)
- Bent: SO₂ (1 lone pair)

**4 Electron Domains:**
- Tetrahedral: CH₄ (no lone pairs)
- Trigonal pyramidal: NH₃ (1 lone pair)
- Bent: H₂O (2 lone pairs)

**5 Electron Domains:**
- Trigonal bipyramidal: PCl₅ (no lone pairs)
- Seesaw: SF₄ (1 lone pair)
- T-shaped: ClF₃ (2 lone pairs)
- Linear: XeF₂ (3 lone pairs)

### 3.6 Polarity of Molecules

**Molecular Polarity:** Depends on two factors:
1. **Bond polarity:** Unequal sharing of electrons
2. **Molecular geometry:** Arrangement of polar bonds

**Determining Molecular Polarity:**

**Nonpolar Molecules:**
- No polar bonds OR
- Polar bonds that cancel due to symmetry
- Examples: CO₂, CCl₄, CH₄

**Polar Molecules:**
- Polar bonds that don't cancel
- Net dipole moment
- Examples: H₂O, NH₃, HCl

**Dipole Moment (μ):** Measure of molecular polarity
- μ = q × d (charge × distance)
- Units: Debye (D)
- Larger dipole moment = more polar

**Examples:**
- H₂O: μ = 1.85 D (bent shape, polar bonds don't cancel)
- CO₂: μ = 0 D (linear, polar bonds cancel)
- NH₃: μ = 1.47 D (trigonal pyramidal, net dipole)

**Physical Properties Related to Polarity:**
- **Solubility:** "Like dissolves like"
- **Boiling points:** Polar molecules have higher boiling points
- **Intermolecular forces:** Stronger in polar molecules

### 3.7 Intermolecular Forces

**Intermolecular Forces (IMFs):** Attractive forces between molecules
- Much weaker than intramolecular (covalent) bonds
- Determine physical properties of substances

**Types of Intermolecular Forces:**

**1. London Dispersion Forces:**
- Present in all molecules
- Caused by temporary dipoles
- Strength increases with molecular size and surface area
- Example: Noble gases, nonpolar molecules

**2. Dipole-Dipole Forces:**
- Between polar molecules
- Positive end of one molecule attracted to negative end of another
- Stronger than London forces
- Example: HCl, CO

**3. Hydrogen Bonding:**
- Special strong dipole-dipole interaction
- H bonded to N, O, or F interacts with another N, O, or F
- Much stronger than regular dipole-dipole
- Examples: H₂O, NH₃, HF

**4. Ion-Dipole Forces:**
- Between ions and polar molecules
- Important in solutions
- Example: Na⁺ with water molecules

**Relative Strengths:**
Ion-dipole > Hydrogen bonding > Dipole-dipole > London

**Effect on Physical Properties:**
- **Boiling points:** Higher with stronger IMFs
- **Melting points:** Higher with stronger IMFs
- **Solubility:** Similar IMFs lead to good solubility
- **Viscosity:** Higher with stronger IMFs

### 3.8 Metallic Bonding

**Metallic Bond:** Electrostatic attraction between metal cations and delocalized electrons

**Characteristics of Metals:**
- **Electron sea model:** Valence electrons are delocalized
- **High conductivity:** Free electrons carry charge
- **Malleability and ductility:** Cations can slide without breaking bonds
- **Luster:** Free electrons reflect light
- **High melting/boiling points:** Strong metallic bonds

**Factors Affecting Metallic Bond Strength:**
- **Number of valence electrons:** More electrons = stronger bonds
- **Nuclear charge:** Higher charge = stronger attraction
- **Atomic radius:** Smaller atoms = stronger bonds

**Metallic Structures:**
- **Body-centered cubic (bcc):** Alkali and alkaline earth metals
- **Hexagonal close-packed (hcp):** Many transition metals
- **Face-centered cubic (fcc):** Cu, Ag, Au, Al

**Alloys:** Mixtures of metals or metals with nonmetals
- **Substitutional alloys:** Atoms of similar size replace each other
- **Interstitial alloys:** Small atoms fit into gaps of larger metal lattice

**Examples:**
- Brass (Cu + Zn): Substitutional alloy
- Steel (Fe + C): Interstitial alloy
- Bronze (Cu + Sn): Substitutional alloy

---

**Chapter Summary:**
Chemical bonds form when atoms interact to achieve more stable electron configurations. Ionic bonds involve electron transfer between metals and nonmetals, while covalent bonds involve electron sharing between nonmetals. Lewis structures help visualize electron distribution, and VSEPR theory predicts molecular geometry. Molecular polarity depends on both bond polarity and molecular shape. Intermolecular forces, though weaker than chemical bonds, significantly affect physical properties. Metallic bonding explains the unique properties of metals.

**Key Formulas:**
- Formal charge = Valence electrons - (Nonbonding electrons + Bonding electrons/2)
- Dipole moment (μ) = q × d

**Important Trends:**
- Bond strength: Covalent > Ionic > Metallic > Hydrogen bonding > Dipole-dipole > London
- Boiling point trends reflect intermolecular force strengths
- Electronegativity differences determine bond type

**Practice Problems:**
1. Draw the Lewis structure for the nitrate ion (NO₃⁻).
2. Predict the molecular geometry and polarity of PF₃.
3. Arrange these compounds in order of increasing boiling point: CH₄, NH₃, H₂O, CO₂.
4. Explain why aluminum metal is a good conductor of electricity.

---

## Chapter 4: Chemical Reactions and Equations

### 4.1 Evidence of Chemical Reactions

**Chemical Reaction:** Process that rearranges atoms to form new substances

**Evidence of Chemical Reactions:**
1. **Color change:** Formation of new colored substances
2. **Temperature change:** Exothermic (heat released) or endothermic (heat absorbed)
3. **Gas formation:** Bubbles, fizzing, odor
4. **Precipitate formation:** Solid forms from solution
5. **Light emission:** Glow or flame
6. **Electrical conductivity change**

**Chemical vs. Physical Changes:**
- **Physical change:** No new substances formed, composition unchanged
- **Chemical change:** New substances formed, composition changed

**Conservation Laws:**
- **Law of Conservation of Mass:** Matter cannot be created or destroyed
- **Law of Conservation of Atoms:** Atoms are rearranged, not created or destroyed

### 4.2 Writing Chemical Equations

**Chemical Equation:** Symbolic representation of chemical reaction

**Components:**
- **Reactants:** Starting materials (left side)
- **Products:** Substances formed (right side)
- **Arrow (→):** Shows direction of reaction
- **Coefficients:** Numbers preceding formulas, indicate relative amounts
- **States of matter:** (s) solid, (l) liquid, (g) gas, (aq) aqueous

**Example:** 2H₂(g) + O₂(g) → 2H₂O(l)

**Parts of Chemical Equations:**
- **Reactants:** 2H₂ and O₂
- **Products:** 2H₂O
- **Coefficients:** 2, 1, 2
- **States:** (g) and (l)

**Additional Notation:**
- **Δ above arrow:** Heat added
- **Catalyst below arrow:** Substance that speeds reaction
- **Reversible arrow (⇌):** Equilibrium reaction
- **Precipitate (↓):** Solid formation
- **Gas (↑):** Gas evolution

### 4.3 Balancing Chemical Equations

**Balancing Requirements:**
- Same number of each type of atom on both sides
- Follow conservation of mass
- Never change subscripts (only coefficients)

**Balancing Strategies:**

**1. Inspection Method:**
- Count atoms of each element
- Adjust coefficients to balance
- Start with most complex compound
- End with elements that appear in multiple compounds

**2. Algebraic Method:**
- Assign variables to unknown coefficients
- Set up equations for each element
- Solve system of equations
- Convert to smallest whole numbers

**Example:** Balance CH₄ + O₂ → CO₂ + H₂O

**Step 1:** Count atoms
- Reactants: C=1, H=4, O=2
- Products: C=1, H=2, O=3

**Step 2:** Balance C (already balanced)
**Step 3:** Balance H: 2H₂O gives H=4
CH₄ + O₂ → CO₂ + 2H₂O

**Step 4:** Balance O: 2CO₂ + 2H₂O gives O=6
CH₄ + 3O₂ → CO₂ + 2H₂O

**Step 5:** Verify: C=1, H=4, O=6 on both sides

**Common Balancing Patterns:**
- **Combustion:** Hydrocarbon + O₂ → CO₂ + H₂O
- **Acid-base reactions:** Acid + Base → Salt + Water
- **Redox reactions:** Often require separate balancing of atoms and charge

### 4.4 Types of Chemical Reactions

**1. Synthesis (Combination) Reactions:**
- Two or more reactants form one product
- General form: A + B → AB
- Examples: 2Na + Cl₂ → 2NaCl
- CO₂ + H₂O → H₂CO₃

**2. Decomposition Reactions:**
- One reactant forms two or more products
- General form: AB → A + B
- Examples: 2H₂O → 2H₂ + O₂ (electrolysis)
- CaCO₃ → CaO + CO₂ (calcination)

**3. Single Displacement (Replacement) Reactions:**
- Element replaces another in a compound
- General form: A + BC → AC + B
- Activity series determines feasibility
- Examples: Zn + CuSO₄ → ZnSO₄ + Cu
- 2Na + 2H₂O → 2NaOH + H₂

**4. Double Displacement (Metathesis) Reactions:**
- Exchange of parts between two compounds
- General form: AB + CD → AD + CB
- Often forms precipitate, gas, or water
- Examples: AgNO₃ + NaCl → AgCl↓ + NaNO₃
- HCl + NaOH → NaCl + H₂O

**5. Combustion Reactions:**
- Rapid reaction with oxygen, usually producing heat and light
- Hydrocarbon + O₂ → CO₂ + H₂O
- Examples: CH₄ + 2O₂ → CO₂ + 2H₂O
- C₂H₅OH + 3O₂ → 2CO₂ + 3H₂O

### 4.5 Predicting Products of Reactions

**Activity Series:** Predicts single displacement reactions
**Metals (most active to least):**
Li > K > Ca > Na > Mg > Al > Zn > Fe > Ni > Sn > Pb > H > Cu > Ag > Au

**Halogen Activity Series:**
F > Cl > Br > I

**Solubility Rules:** Predict double displacement products
- **Always soluble:** Group 1 compounds, NH₄⁺ compounds, NO₃⁻ compounds
- **Mostly soluble:** Cl⁻, Br⁻, I⁻ (except Ag⁺, Pb²⁺, Hg₂²⁺)
- **Mostly soluble:** SO₄²⁻ (except Ba²⁺, Pb²⁺, Ca²⁺, Sr²⁺, Ag⁺)
- **Mostly insoluble:** CO₃²⁻, PO₄³⁻, OH⁻, S²⁻

**Predicting Strategy:**
1. Identify reaction type from reactants
2. Apply relevant rules (activity series, solubility)
3. Write formulas for predicted products
4. Balance the equation
5. Check for special cases (acid-base, redox)

**Examples:**
- **Fe + CuSO₄:** Fe is more active than Cu → FeSO₄ + Cu
- **Pb(NO₃)₂ + KI:** KI is soluble, PbI₂ is insoluble → PbI₂↓ + 2KNO₃
- **C₃H₈ + O₂:** Hydrocarbon combustion → 3CO₂ + 4H₂O

### 4.6 Net Ionic Equations

**Complete Ionic Equation:** Shows all dissolved ions as separate entities
**Net Ionic Equation:** Shows only species that actually participate in reaction

**Writing Net Ionic Equations:**

**Step 1:** Write balanced molecular equation
AgNO₃(aq) + NaCl(aq) → AgCl(s) + NaNO₃(aq)

**Step 2:** Write complete ionic equation
Ag⁺(aq) + NO₃⁻(aq) + Na⁺(aq) + Cl⁻(aq) → AgCl(s) + Na⁺(aq) + NO₃⁻(aq)

**Step 3:** Identify spectator ions (appear on both sides)
Na⁺ and NO₃⁻ are spectator ions

**Step 4:** Write net ionic equation
Ag⁺(aq) + Cl⁻(aq) → AgCl(s)

**Types of Spectators:**
- **Spectator ions:** Don't participate directly
- **Spectator molecules:** Don't react directly

**Importance of Net Ionic Equations:**
- Show actual chemical changes
- Useful for understanding reaction mechanisms
- Essential for titration calculations

### 4.7 Redox Reactions

**Redox Reaction:** Chemical reaction involving electron transfer
- **Oxidation:** Loss of electrons (increase in oxidation number)
- **Reduction:** Gain of electrons (decrease in oxidation number)
- **OIL RIG:** Oxidation Is Loss, Reduction Is Gain

**Oxidation Numbers:** Assign electrons to atoms in compounds
**Rules:**
1. Elements: 0 (O₂, N₂, metals)
2. Monatomic ions: equal to ionic charge (Na⁺ = +1, Cl⁻ = -1)
3. Hydrogen: +1 (except metal hydrides: -1)
4. Oxygen: -2 (except peroxides: -1, OF₂: +2)
5. Halogens: -1 (except with oxygen or other halogens)
6. Sum of oxidation numbers = overall charge

**Example:** Determine oxidation numbers in H₂SO₄
- H: +1 each, total +2
- S: unknown
- O: -2 each, total -8
- Sum = 0: +2 + S - 8 = 0 → S = +6

**Identifying Redox Reactions:**
1. Assign oxidation numbers to all atoms
2. Look for changes in oxidation numbers
3. Identify oxidizing agent (gets reduced) and reducing agent (gets oxidized)

**Example:** Zn + Cu²⁺ → Zn²⁺ + Cu
- Zn: 0 → +2 (oxidation, reducing agent)
- Cu²⁺: +2 → 0 (reduction, oxidizing agent)

**Balancing Redox Reactions (Half-Reaction Method):**

**Acidic Solution:**
1. Separate into oxidation and reduction half-reactions
2. Balance all elements except H and O
3. Balance O by adding H₂O
4. Balance H by adding H⁺
5. Balance charge by adding electrons
6. Multiply half-reactions to equalize electrons
7. Add half-reactions and cancel
8. Verify balance of atoms and charge

**Basic Solution:**
- Follow acidic solution steps
- Add OH⁻ to neutralize H⁺
- Cancel water molecules that appear on both sides

**Example:** Balance MnO₄⁻ + Fe²⁺ → Mn²⁺ + Fe³⁺ (acidic)

**Oxidation:** Fe²⁺ → Fe³⁺ + e⁻
**Reduction:** MnO₄⁻ + 8H⁺ + 5e⁻ → Mn²⁺ + 4H₂O
**Multiply oxidation by 5:** 5Fe²⁺ → 5Fe³⁺ + 5e⁻
**Add:** MnO₄⁻ + 8H⁺ + 5Fe²⁺ → Mn²⁺ + 4H₂O + 5Fe³⁺

---

**Chapter Summary:**
Chemical reactions involve the rearrangement of atoms to form new substances. Evidence includes color changes, temperature changes, gas formation, and precipitate formation. Chemical equations symbolically represent reactions and must be balanced to satisfy the law of conservation of mass. Reactions can be classified as synthesis, decomposition, single displacement, double displacement, or combustion. Net ionic equations show only participating species, while redox reactions involve electron transfer between oxidizing and reducing agents.

**Key Skills:**
- Writing and balancing chemical equations
- Predicting reaction products
- Writing net ionic equations
- Balancing redox reactions
- Identifying reaction types

**Practice Problems:**
1. Balance: C₃H₈ + O₂ → CO₂ + H₂O
2. Predict products and write balanced equation: Mg + HCl → ?
3. Write net ionic equation for: BaCl₂(aq) + Na₂SO₄(aq) → ?
4. Balance redox: Cr₂O₇²⁻ + Fe²⁺ → Cr³⁺ + Fe³⁺ (acidic)

---

## Chapter 5: Stoichiometry and the Mole

### 5.1 The Mole Concept

**Mole (mol):** SI unit for amount of substance
- One mole contains 6.022 × 10²³ particles (Avogadro's number)
- Particles can be atoms, molecules, ions, electrons, etc.

**Avogadro's Number (Nₐ):** 6.022 × 10²³
- Number of carbon-12 atoms in exactly 12 grams of carbon-12
- Bridge between atomic scale and macroscopic scale

**Molar Relationships:**
- 1 mole of atoms = 6.022 × 10²³ atoms
- 1 mole of molecules = 6.022 × 10²³ molecules
- 1 mole of ions = 6.022 × 10²³ ions

**Perspective:**
- 1 mole of tennis balls would cover Earth to depth of 40 miles
- 1 mole of water molecules fills a container about 18 mL
- 1 mole of rice grains would feed world's population for 68 years

### 5.2 Molar Mass

**Molar Mass (M):** Mass of one mole of substance
- Units: grams per mole (g/mol)
- Numerically equal to atomic/molecular/formula mass
- Sum of atomic masses of all atoms in formula

**Calculating Molar Mass:**
- Elements: Use atomic weight from periodic table
- Compounds: Sum of atomic masses × number of each atom

**Examples:**
- H₂O: 2(1.008) + 16.00 = 18.016 g/mol
- CO₂: 12.01 + 2(16.00) = 44.01 g/mol
- C₆H₁₂O₆: 6(12.01) + 12(1.008) + 6(16.00) = 180.156 g/mol

**Mole-Mass Conversions:**
- Mass → Moles: moles = mass ÷ molar mass
- Moles → Mass: mass = moles × molar mass

**Example Problems:**
1. Mass of 2.5 moles of NaCl:
   M(NaCl) = 22.99 + 35.45 = 58.44 g/mol
   mass = 2.5 mol × 58.44 g/mol = 146.1 g

2. Moles in 50.0 g of CaCO₃:
   M(CaCO₃) = 40.08 + 12.01 + 3(16.00) = 100.09 g/mol
   moles = 50.0 g ÷ 100.09 g/mol = 0.500 mol

### 5.3 Percent Composition

**Percent Composition:** Mass percentage of each element in compound
- % element = (mass of element in formula ÷ molar mass) × 100%

**Calculating Percent Composition:**

**Step 1:** Calculate molar mass of compound
**Step 2:** Calculate total mass of each element
**Step 3:** Calculate percentage for each element

**Example:** Percent composition of Na₂CO₃
- Molar mass: 2(22.99) + 12.01 + 3(16.00) = 105.99 g/mol
- Na: 2(22.99) = 45.98 g → (45.98 ÷ 105.99) × 100% = 43.38%
- C: 12.01 g → (12.01 ÷ 105.99) × 100% = 11.33%
- O: 3(16.00) = 48.00 g → (48.00 ÷ 105.99) × 100% = 45.29%
- Check: 43.38% + 11.33% + 45.29% = 100%

**Applications:**
- Quality control in manufacturing
- Determining formula of unknown compounds
- Analyzing composition of mixtures

### 5.4 Empirical and Molecular Formulas

**Empirical Formula:** Simplest whole-number ratio of atoms
- May or may not be the actual molecular formula
- Reduced form of molecular formula

**Molecular Formula:** Actual number of atoms in molecule
- Whole-number multiple of empirical formula

**Determining Empirical Formula from Composition:**

**Step 1:** Assume 100 g sample (convert % to grams)
**Step 2:** Convert grams to moles for each element
**Step 3:** Divide by smallest number of moles
**Step 4:** Multiply to get whole numbers if necessary

**Example:** Compound with 40.0% C, 6.7% H, 53.3% O

1. Assume 100 g: C=40.0 g, H=6.7 g, O=53.3 g
2. Convert to moles:
   - C: 40.0 g ÷ 12.01 g/mol = 3.33 mol
   - H: 6.7 g ÷ 1.008 g/mol = 6.64 mol  
   - O: 53.3 g ÷ 16.00 g/mol = 3.33 mol
3. Divide by smallest (3.33):
   - C: 3.33 ÷ 3.33 = 1
   - H: 6.64 ÷ 3.33 = 2
   - O: 3.33 ÷ 3.33 = 1
4. Empirical formula: CH₂O

**Molecular Formula from Empirical Formula:**
- Need molecular mass of compound
- Molecular formula = (empirical formula)ₙ where n = molecular mass ÷ empirical mass

**Example:** Empirical formula CH₂O, molecular mass = 180 g/mol
- Empirical mass = 12.01 + 2(1.008) + 16.00 = 30.03 g/mol
- n = 180 ÷ 30.03 = 6
- Molecular formula: (CH₂O)₆ = C₆H₁₂O₆ (glucose)

### 5.5 Stoichiometric Calculations

**Stoichiometry:** Quantitative relationships in chemical reactions
- Based on balanced chemical equations
- Uses mole ratios from balanced equations

**Mole Ratios:** Ratio of moles of reactants and products
- From coefficients in balanced equation
- Used to convert between different substances

**Example:** 2H₂ + O₂ → 2H₂O
- 2 moles H₂ : 1 mole O₂ : 2 moles H₂O
- Moles H₂O = 2 × moles O₂
- Moles H₂ = 2 × moles O₂

**Stoichiometric Calculations Steps:**

1. **Write balanced equation**
2. **Identify given and unknown quantities**
3. **Convert given quantity to moles**
4. **Use mole ratios to find moles of unknown**
5. **Convert to desired units**

**Example Problem:**
How many grams of H₂O are produced when 8.0 g of H₂ react with excess O₂?

1. Balanced equation: 2H₂ + O₂ → 2H₂O
2. Given: 8.0 g H₂, Unknown: grams H₂O
3. Convert to moles: 8.0 g ÷ 2.016 g/mol = 3.97 mol H₂
4. Mole ratio: 2H₂O/2H₂ = 1, so 3.97 mol H₂O
5. Convert to grams: 3.97 mol × 18.016 g/mol = 71.5 g H₂O

### 5.6 Limiting Reactants

**Limiting Reactant:** Reactant that is completely consumed
- Determines maximum amount of product formed
- Other reactants are in excess

**Excess Reactant:** Reactant not completely consumed
- Some remains after reaction completion

**Identifying Limiting Reactant:**

**Method 1: Compare Required to Available**
1. Calculate moles of each reactant
2. Calculate moles of product each could form
3. Smaller amount indicates limiting reactant

**Method 2: Compare Ratios**
1. Calculate actual mole ratio of reactants
2. Compare to required mole ratio from equation
3. Determine which is limiting

**Example:** 10.0 g Fe reacts with 5.0 g O₂: 4Fe + 3O₂ → 2Fe₂O₃

1. Convert to moles:
   - Fe: 10.0 g ÷ 55.85 g/mol = 0.179 mol
   - O₂: 5.0 g ÷ 32.00 g/mol = 0.156 mol

2. Required ratio: Fe/O₂ = 4/3 = 1.33
   Available ratio: 0.179/0.156 = 1.15

3. Since available ratio (1.15) < required ratio (1.15), Fe is limiting

**Calculating Amount of Product:**
- Use limiting reactant amount
- Apply stoichiometric calculations

**Calculating Excess Reactant Remaining:**
- Calculate amount used based on limiting reactant
- Subtract from initial amount

### 5.7 Percent Yield

**Theoretical Yield:** Maximum amount of product possible
- Based on limiting reactant
- Calculated from stoichiometry

**Actual Yield:** Amount of product actually obtained
- Determined experimentally
- Usually less than theoretical yield

**Percent Yield:** (Actual Yield ÷ Theoretical Yield) × 100%
- Measure of reaction efficiency
- Affected by side reactions, incomplete reactions, losses

**Factors Affecting Yield:**
- Incomplete reactions
- Side reactions
- Product loss during separation
- Impurities in reactants
- Reversible reactions

**Example:** Theoretical yield = 25.0 g, Actual yield = 18.5 g
Percent yield = (18.5 g ÷ 25.0 g) × 100% = 74.0%

**Industrial Importance:**
- Economic considerations
- Process optimization
- Quality control

### 5.8 Solution Stoichiometry

**Molarity (M):** Moles of solute per liter of solution
- M = moles solute ÷ liters solution
- Most common concentration unit in chemistry

**Calculating Molarity:**
- M = n/V where n = moles, V = volume in liters
- n = M × V
- V = n/M

**Example:** 5.85 g NaCl in 250 mL solution
- Moles NaCl = 5.85 g ÷ 58.44 g/mol = 0.100 mol
- Volume = 250 mL = 0.250 L
- Molarity = 0.100 mol ÷ 0.250 L = 0.400 M

**Solution Stoichiometry Problems:**

**Dilution:**
- M₁V₁ = M₂V₂
- Adding solvent changes concentration but not moles

**Example:** Prepare 250 mL of 0.100 M HCl from 1.0 M stock
- M₁V₁ = M₂V₂: 1.0 M × V₁ = 0.100 M × 0.250 L
- V₁ = 0.0250 L = 25.0 mL stock acid
- Add to 225 mL water (never add water to acid!)

**Reactions in Solution:**
- Convert volumes to moles using molarity
- Apply regular stoichiometric calculations
- Convert back to desired units

**Example:** 50.0 mL of 0.200 M AgNO₃ reacts with excess NaCl
- Moles AgNO₃ = 0.200 M × 0.0500 L = 0.0100 mol
- Reaction: AgNO₃ + NaCl → AgCl + NaNO₃
- Moles AgCl formed = 0.0100 mol
- Mass AgCl = 0.0100 mol × 143.32 g/mol = 1.43 g

**Titration Calculations:**
- Use stoichiometry at equivalence point
- Critical for acid-base and redox titrations

---

**Chapter Summary:**
Stoichiometry involves quantitative relationships in chemical reactions using the mole concept. One mole contains Avogadro's number of particles. Molar mass connects mass to moles, enabling calculations between mass, moles, and particles. Percent composition determines elemental makeup of compounds, while empirical and molecular formulas relate composition to structure. Stoichiometric calculations use mole ratios from balanced equations to predict reaction amounts. Limiting reactants determine maximum yields, while percent yield measures reaction efficiency. Solution stoichiometry applies these concepts to reactions in solution using molarity.

**Key Formulas:**
- M = n/V (molarity)
- Percent yield = (actual ÷ theoretical) × 100%
- M₁V₁ = M₂V₂ (dilution)
- Mass = moles × molar mass

**Essential Skills:**
- Converting between mass, moles, and particles
- Determining empirical and molecular formulas
- Identifying limiting reactants
- Calculating theoretical and percent yields
- Performing solution stoichiometry calculations

**Practice Problems:**
1. Calculate the mass of 3.50 × 10²⁴ molecules of CO₂.
2. A compound is 54.5% C, 9.1% H, 36.4% O by mass. Find its empirical formula.
3. If 25.0 g of Al reacts with excess HCl, how many grams of H₂ gas are produced?
4. What is the percent yield if 15.0 g of CaO is obtained from heating 20.0 g of CaCO₃?

---

## Chapter 6: States of Matter and Gas Laws

### 6.1 The Kinetic Molecular Theory

**Kinetic Molecular Theory (KMT):** Explains behavior of particles in different states

**Postulates:**
1. Matter is composed of tiny particles in constant motion
2. Particle collisions are elastic (no net energy loss)
3. No attractive/repulsive forces between particles
4. Average kinetic energy proportional to absolute temperature

**Applications to States:**
- **Gases:** Particles far apart, random motion, high kinetic energy
- **Liquids:** Particles closer, slide past each other, moderate kinetic energy
- **Solids:** Particles fixed in positions, vibrate, low kinetic energy

**Temperature and Kinetic Energy:**
- KE_avg = (3/2)kT where k = Boltzmann constant, T = Kelvin temperature
- Higher temperature = higher average kinetic energy
- Temperature measure of average kinetic energy

### 6.2 Properties of Gases

**Gas Characteristics:**
- Expand to fill container completely
- Compressible (can be squeezed into smaller volume)
- Low density compared to liquids and solids
- Mix completely with other gases
- Exert pressure on container walls

**Gas Pressure:** Force per unit area
- Caused by particle collisions with container walls
- Measured in various units: atm, torr, mmHg, Pa, kPa
- Standard atmospheric pressure = 1 atm = 760 torr = 101.3 kPa

**Manometers:** Devices to measure gas pressure
- **Open-end:** Measures gas pressure relative to atmosphere
- **Closed-end:** Measures absolute pressure

**Gas Expansion:**
- Gases expand when heated (temperature increase)
- Gases expand when pressure decreases
- Volume changes are much larger than for liquids/solids

### 6.3 Gas Laws: Boyle's, Charles's, and Avogadro's

**Boyle's Law (Pressure-Volume Relationship):**
- At constant temperature, pressure and volume are inversely proportional
- P₁V₁ = P₂V₂
- Doubling pressure halves volume
- Explains how breathing works

**Charles's Law (Temperature-Volume Relationship):**
- At constant pressure, volume and temperature are directly proportional
- V₁/T₁ = V₂/T₂ (temperature in Kelvin)
- Doubling temperature doubles volume
- Basis for hot air balloons

**Gay-Lussac's Law (Temperature-Pressure Relationship):**
- At constant volume, pressure and temperature are directly proportional
- P₁/T₁ = P₂/T₂ (temperature in Kelvin)
- Temperature increase causes pressure increase
- Important in pressure cooker safety

**Avogadro's Law (Volume-Amount Relationship):**
- At constant temperature and pressure, volume and amount of gas are directly proportional
- V₁/n₁ = V₂/n₂
- Equal volumes contain equal numbers of molecules
- Basis for mole concept

### 6.4 The Ideal Gas Law

**Ideal Gas Law:** Combines all gas laws
- PV = nRT
- P = pressure (atm)
- V = volume (L)
- n = moles
- R = ideal gas constant (0.08206 L·atm/mol·K)
- T = temperature (K)

**Ideal Gas Constant (R):** Various units
- 0.08206 L·atm/mol·K
- 8.314 J/mol·K
- 62.36 L·torr/mol·K
- 8.314 L·kPa/mol·K

**Using the Ideal Gas Law:**
- Can solve for any variable if other three are known
- Units must be consistent
- Temperature must be in Kelvin

**Example Problems:**

1. **Calculate pressure:** 2.00 moles of gas in 5.00 L container at 298 K
   P = nRT/V = (2.00 × 0.08206 × 298) ÷ 5.00 = 9.76 atm

2. **Calculate volume:** 0.500 mol gas at 1.50 atm and 273 K
   V = nRT/P = (0.500 × 0.08206 × 273) ÷ 1.50 = 7.48 L

**Gas Density Calculations:**
- Density (ρ) = mass/volume = (n × M)/V
- From ideal gas law: ρ = PM/RT
- Gas density increases with pressure, decreases with temperature

### 6.5 Real Gases

**Real Gases vs. Ideal Gases:**
- Ideal gases follow gas laws exactly
- Real gases deviate, especially at high pressure and low temperature
- Deviations due to intermolecular forces and particle volume

**Van der Waals Equation:**
- (P + an²/V²)(V - nb) = nRT
- **a** accounts for intermolecular attractions
- **b** accounts for molecular volume
- More accurate for real gases

**Conditions for Deviations:**
- **High pressure:** Particle volume becomes significant
- **Low temperature:** Intermolecular forces become significant
- **Polar molecules:** Stronger intermolecular forces

**Compressibility Factor (Z):**
- Z = PV/nRT
- Z = 1 for ideal gas
- Z < 1: attractive forces dominate
- Z > 1: molecular volume dominates

### 6.6 Properties of Liquids

**Liquid Characteristics:**
- Fixed volume, takes shape of container
- Particles close together but can move past each other
- Much less compressible than gases
- Higher density than gases (usually)
- Surface tension and viscosity important properties

**Surface Tension:**
- Energy required to increase surface area
- Caused by cohesive forces between surface molecules
- Explains why water droplets are spherical
- Affected by temperature and surfactants

**Viscosity:**
- Resistance to flow
- Related to intermolecular forces and molecular shape
- Higher in liquids with strong hydrogen bonding
- Decreases with temperature

**Capillary Action:**
- Combination of cohesion and adhesion forces
- Causes liquid to rise or fall in narrow tubes
- Important in plants and paper towels

### 6.7 Properties of Solids

**Solid Characteristics:**
- Fixed shape and volume
- Particles in fixed positions, vibrate around fixed points
- Generally incompressible
- High density
- Two types: crystalline and amorphous

**Crystalline Solids:**
- Regular, repeating arrangement of particles
- Definite melting point
- Three main types:
  - **Ionic:** Regular arrangement of ions (NaCl)
  - **Molecular:** Individual molecules held together (dry ice)
  - **Network:** Covalent bonds throughout (diamond)

**Amorphous Solids:**
- No long-range order
- No definite melting point (soften over range)
- Examples: glass, rubber, wax
- Form when cooled rapidly

**Crystal Structures:**
- **Unit cell:** Smallest repeating unit
- **Coordination number:** Number of nearest neighbors
- **Close-packed structures:** Hexagonal and cubic

### 6.8 Phase Changes

**Phase Changes:** Transitions between states of matter
- Require energy input or release
- Occur at characteristic temperatures and pressures

**Phase Change Types:**
- **Melting (Fusion):** Solid → liquid, requires heat (endothermic)
- **Freezing:** Liquid → solid, releases heat (exothermic)
- **Vaporization:** Liquid → gas, requires heat
- **Condensation:** Gas → liquid, releases heat
- **Sublimation:** Solid → gas, requires heat
- **Deposition:** Gas → solid, releases heat

**Heat of Fusion (ΔH_fus):**
- Energy required to melt 1 gram of solid at melting point
- For water: 6.01 kJ/mol or 334 J/g

**Heat of Vaporization (ΔH_vap):**
- Energy required to vaporize 1 gram of liquid at boiling point
- For water: 40.7 kJ/mol or 2260 J/g

**Phase Diagrams:**
- Graph showing phases at various temperatures and pressures
- **Triple point:** All three phases coexist
- **Critical point:** Beyond which liquid-gas distinction disappears
- **Normal melting/boiling points:** At 1 atm pressure

**Clausius-Clapeyron Equation:**
- ln(P₂/P₁) = (-ΔH_vap/R)(1/T₂ - 1/T₁)
- Relates vapor pressure to temperature

---

**Chapter Summary:**
The Kinetic Molecular Theory explains particle behavior in different states of matter. Gases follow predictable relationships described by Boyle's, Charles's, Gay-Lussac's, and Avogadro's laws, which combine into the Ideal Gas Law PV = nRT. Real gases deviate from ideal behavior at high pressures and low temperatures. Liquids have unique properties like surface tension and viscosity, while solids can be crystalline or amorphous. Phase changes involve energy transfer and are visualized on phase diagrams.

**Key Formulas:**
- PV = nRT (Ideal Gas Law)
- P₁V₁ = P₂V₂ (Boyle's Law)
- V₁/T₁ = V₂/T₂ (Charles's Law)
- ρ = PM/RT (Gas Density)
- ln(P₂/P₁) = (-ΔH_vap/R)(1/T₂ - 1/T₁) (Clausius-Clapeyron)

**Important Concepts:**
- Kinetic Molecular Theory postulates
- Standard temperature and pressure (STP)
- Factors affecting gas behavior
- Types of solids and their properties
- Phase change energetics

**Practice Problems:**
1. Calculate the pressure exerted by 2.50 moles of gas in a 10.0 L container at 298 K.
2. A gas occupies 25.0 mL at 1.20 atm. What volume will it occupy at 0.800 atm (constant temperature)?
3. How many moles of gas are present in a 5.00 L container at 2.00 atm and 273 K?
4. Explain why real gases deviate from ideal behavior at high pressures.

---

## Chapter 7: Solutions and Concentrations

### 7.1 Solutions: Types and Properties

**Solution:** Homogeneous mixture of two or more substances
- **Solute:** Substance being dissolved (usually present in smaller amount)
- **Solvent:** Substance doing the dissolving (usually present in larger amount)
- **Aqueous solution:** Water is the solvent

**Types of Solutions:**
- **Gas in gas:** Air (oxygen dissolved in nitrogen)
- **Gas in liquid:** Carbonated water (CO₂ in water)
- **Liquid in liquid:** Vinegar (acetic acid in water)
- **Solid in liquid:** Salt water (NaCl in water)
- **Solid in solid:** Alloys (brass: zinc in copper)

**Solution Properties:**
- **Homogeneous:** Uniform composition throughout
- **Transparent:** Light passes through (may be colored)
- **Stable:** No settling over time
- **Cannot be separated by filtration**

**Solubility:** Maximum amount of solute that can dissolve in given amount of solvent at specific temperature

**Saturated, Unsaturated, Supersaturated:**
- **Saturated:** Contains maximum dissolved solute
- **Unsaturated:** Can dissolve more solute
- **Supersaturated:** Contains more solute than normally possible (unstable)

### 7.2 Solubility

**Factors Affecting Solubility:**

**1. Nature of Solute and Solvent:**
- **"Like dissolves like":** Polar solutes dissolve in polar solvents
- **Polar in polar:** Salt in water, sugar in water
- **Nonpolar in nonpolar:** Oil in hexane, wax in benzene
- **Polar in nonpolar:** Generally insoluble

**2. Temperature:**
- **Most solids:** Solubility increases with temperature
- **Most gases:** Solubility decreases with temperature
- **Exceptions:** Some salts show decreasing solubility

**3. Pressure:**
- **Solids and liquids:** Little effect
- **Gases:** Solubility increases with pressure (Henry's Law)
- **Henry's Law:** C = kP where C = concentration, k = Henry's constant, P = pressure

**4. Particle Size:**
- **Smaller particles:** Higher solubility, dissolve faster
- **Surface area:** More surface area increases dissolution rate

**Solubility Curves:**
- Graphs showing solubility vs. temperature
- Used to determine if solutions are saturated
- Help calculate crystallization amounts

### 7.3 Concentration Units

**Molarity (M):**
- Moles of solute per liter of solution
- M = n/V where n = moles, V = volume in liters
- Temperature dependent (volume changes with temperature)

**Molality (m):**
- Moles of solute per kilogram of solvent
- m = n/mass of solvent (kg)
- Temperature independent

**Mass Percent (% w/w):**
- Mass of solute ÷ total mass × 100%
- Temperature independent

**Volume Percent (% v/v):**
- Volume of solute ÷ total volume × 100%
- Used for liquid-liquid solutions

**Mole Fraction (χ):**
- Moles of component ÷ total moles of all components
- χ₁ = n₁/(n₁ + n₂ + ...)
- Important for gas mixtures

**Parts Per Million (ppm) and Parts Per Billion (ppb):**
- ppm = (mass of solute ÷ total mass) × 10⁶
- ppb = (mass of solute ÷ total mass) × 10⁹
- Used for very dilute solutions

**Example Calculations:**

1. **Molarity:** 5.85 g NaCl in 250 mL solution
   - Moles NaCl = 5.85 g ÷ 58.44 g/mol = 0.100 mol
   - Volume = 0.250 L
   - Molarity = 0.100 mol ÷ 0.250 L = 0.400 M

2. **Mass Percent:** 10 g NaCl in 90 g water
   - Total mass = 10 g + 90 g = 100 g
   - Mass percent = (10 g ÷ 100 g) × 100% = 10%

### 7.4 Dilution Calculations

**Dilution:** Adding solvent to decrease concentration
- Amount of solute remains constant
- Only volume changes

**Dilution Formula:**
- M₁V₁ = M₂V₂
- M₁ = initial concentration
- V₁ = initial volume
- M₂ = final concentration
- V₂ = final volume

**Dilution Steps:**
1. Calculate volume of concentrated solution needed
2. Add calculated volume to volumetric flask
3. Add solvent to reach final volume
4. Mix thoroughly

**Example:** Prepare 500 mL of 0.100 M HCl from 2.00 M stock
- M₁V₁ = M₂V₂: 2.00 M × V₁ = 0.100 M × 0.500 L
- V₁ = 0.0250 L = 25.0 mL stock acid
- Add 25.0 mL stock to flask, dilute to 500 mL

**Serial Dilutions:**
- Stepwise dilution series
- Common in microbiology and analytical chemistry
- Each step uses diluted solution as stock for next dilution

### 7.5 Colligative Properties

**Colligative Properties:** Depend only on number of solute particles, not their identity

**1. Boiling Point Elevation:**
- Solution boils at higher temperature than pure solvent
- ΔTb = i × Kb × m
- i = van't Hoff factor (number of particles per formula unit)
- Kb = boiling point elevation constant
- m = molality

**2. Freezing Point Depression:**
- Solution freezes at lower temperature than pure solvent
- ΔTf = i × Kf × m
- Kf = freezing point depression constant
- Applications: road salt, antifreeze

**3. Vapor Pressure Lowering:**
- Solution has lower vapor pressure than pure solvent
- Raoult's Law: Psolution = Xsolvent × P°solvent
- Important for understanding distillation

**4. Osmotic Pressure:**
- Pressure required to prevent osmosis
- π = iMRT where π = osmotic pressure
- Important in biological systems

**Van't Hoff Factor (i):**
- Number of particles formed per formula unit in solution
- **Nonelectrolytes:** i = 1 (glucose, ethanol)
- **Electrolytes:** i ≈ number of ions (NaCl: i ≈ 2, CaCl₂: i ≈ 3)
- Actual i may be less due to ion pairing

**Example:** Calculate freezing point of 0.100 m NaCl solution
- i = 2 (Na⁺ and Cl⁻)
- Kf (water) = 1.86 °C·kg/mol
- ΔTf = 2 × 1.86 × 0.100 = 0.372°C
- Freezing point = 0°C - 0.372°C = -0.372°C

### 7.6 Colloids and Suspensions

**Suspensions:**
- Heterogeneous mixtures with particles > 1000 nm
- Particles settle out over time
- Can be separated by filtration
- Examples: sand in water, flour in water

**Colloids (Colloidal Dispersions):**
- Particles between 1 nm and 1000 nm
- Appear homogeneous but are actually heterogeneous
- **Tyndall effect:** Scattering of light by colloidal particles
- Cannot be separated by filtration

**Types of Colloids:**
- **Sol:** Solid particles in liquid (paint, blood plasma)
- **Gel:** Liquid in solid network (jelly, gelatin)
- **Emulsion:** Liquid droplets in liquid (milk, mayonnaise)
- **Foam:** Gas bubbles in liquid (whipped cream, shaving cream)
- **Aerosol:** Liquid or solid particles in gas (fog, smoke)

**Colloidal Properties:**
- **Brownian motion:** Random movement of particles
- **Electrical charge:** Particles usually have surface charge
- **Stability:** Can be stable or unstable
- **Coagulation:** Clumping together of particles

**Distinguishing Solutions, Colloids, and Suspensions:**
| Property | Solution | Colloid | Suspension |
|----------|----------|---------|------------|
| Particle size | < 1 nm | 1-1000 nm | > 1000 nm |
| Appearance | Clear | Often cloudy | Cloudy/opaque |
| Tyndall effect | No | Yes | Variable |
| Filtration | Passes through | Passes through | Retained |
| Settling | No | No | Yes |

**Applications of Colloids:**
- Food industry (emulsifiers, thickeners)
- Medicine (drug delivery)
- Environmental (water treatment)
- Industrial (paints, inks, cosmetics)

---

**Chapter Summary:**
Solutions are homogeneous mixtures where solutes dissolve in solvents. Solubility depends on the nature of substances, temperature, and pressure. Various concentration units include molarity, molality, mass percent, and parts per million. Dilution calculations use the relationship M₁V₁ = M₂V₂. Colligative properties depend only on the number of dissolved particles and include boiling point elevation, freezing point depression, vapor pressure lowering, and osmotic pressure. Colloids are intermediate between solutions and suspensions, with particles between 1-1000 nm that exhibit the Tyndall effect.

**Key Formulas:**
- M₁V₁ = M₂V₂ (Dilution)
- ΔTb = i × Kb × m (Boiling point elevation)
- ΔTf = i × Kf × m (Freezing point depression)
- C = kP (Henry's Law)
- π = iMRT (Osmotic pressure)

**Important Concepts:**
- "Like dissolves like" principle
- Factors affecting solubility
- Temperature vs. pressure effects
- Van't Hoff factor
- Tyndall effect in colloids

**Practice Problems:**
1. Calculate the molarity of a solution containing 29.2 g of NaCl in enough water to make 500 mL of solution.
2. How many mL of 6.00 M HCl are needed to prepare 250 mL of 0.300 M HCl?
3. Calculate the freezing point of a solution containing 54.0 g of glucose (C₆H₁₂O₆) in 250 g of water.
4. Explain the difference between a solution, colloid, and suspension.

---

## Chapter 8: Acids, Bases, and pH

### 8.1 Properties of Acids and Bases

**Acids:** Substances that increase H⁺ concentration in water
- **Taste:** Sour (lemons, vinegar)
- **Touch:** Feel burning or stinging
- **Reactions:** React with metals to produce H₂ gas
- **Indicators:** Turn blue litmus red
- **Electrical:** Conduct electricity in solution
- **pH:** Less than 7

**Bases:** Substances that increase OH⁻ concentration in water
- **Taste:** Bitter (unsweetened chocolate, baking soda)
- **Touch:** Feel slippery or soapy
- **Reactions:** Neutralize acids
- **Indicators:** Turn red litmus blue
- **Electrical:** Conduct electricity in solution
- **pH:** Greater than 7

**Common Examples:**
- **Acids:** HCl, H₂SO₄, HNO₃, CH₃COOH (vinegar)
- **Bases:** NaOH, KOH, NH₃, Ca(OH)₂, NaHCO₃ (baking soda)

**Neutral Substances:**
- **Water:** pH = 7
- **Pure salts:** Generally neutral (some are acidic or basic)

### 8.2 Theories of Acids and Bases

**Arrhenius Theory (1887):**
- **Acid:** Substance that produces H⁺ ions in water
- **Base:** Substance that produces OH⁻ ions in water
- **Examples:** HCl → H⁺ + Cl⁻, NaOH → Na⁺ + OH⁻
- **Limitations:** Only applies to aqueous solutions

**Brønsted-Lowry Theory (1923):**
- **Acid:** Proton (H⁺) donor
- **Base:** Proton (H⁺) acceptor
- **Broader than Arrhenius:** Includes non-hydroxide bases
- **Conjugate acid-base pairs:** HA + B⁻ ⇌ A⁻ + HB

**Lewis Theory (1923):**
- **Acid:** Electron pair acceptor
- **Base:** Electron pair donor
- **Broadest theory:** Includes all acid-base reactions
- **Examples:** AlCl₃ + Cl⁻ → AlCl₄⁻ (Lewis acid-base)

**Comparison of Theories:**
| Theory | Acid Definition | Base Definition | Scope |
|--------|----------------|------------------|-------|
| Arrhenius | H⁺ producer | OH⁻ producer | Aqueous only |
| Brønsted-Lowry | H⁺ donor | H⁺ acceptor | Proton transfers |
| Lewis | e⁻ pair acceptor | e⁻ pair donor | All electron transfers |

### 8.3 Strong and Weak Acids/Bases

**Strong Acids:** Completely dissociate in water
- **Examples:** HCl, HBr, HI, HNO₃, HClO₄, H₂SO₄
- **Dissociation:** HA → H⁺ + A⁻ (complete)
- **Equilibrium:** Lies far to right
- **pH:** Can be calculated directly from concentration

**Weak Acids:** Partially dissociate in water
- **Examples:** CH₃COOH, HF, H₂CO₃, H₃PO₄
- **Dissociation:** HA ⇌ H⁺ + A⁻ (partial)
- **Equilibrium:** Lies to left
- **pH:** Requires equilibrium calculations

**Strong Bases:** Completely dissociate in water
- **Examples:** Group 1 hydroxides, heavy Group 2 hydroxides
- **Dissociation:** MOH → M⁺ + OH⁻ (complete)
- **Examples:** NaOH, KOH, Ca(OH)₂, Ba(OH)₂

**Weak Bases:** Partially react with water
- **Examples:** NH₃, organic amines
- **Reaction:** B + H₂O ⇌ BH⁺ + OH⁻
- **Examples:** NH₃ + H₂O ⇌ NH₄⁺ + OH⁻

**Acid/Base Strength Factors:**
- **Bond strength:** Weaker H-X bonds → stronger acids
- **Electronegativity:** Higher electronegativity → stronger acids
- **Resonance stabilization:** More resonance → stronger acids
- **Inductive effects:** Electron-withdrawing groups → stronger acids

### 8.4 pH and pOH Calculations

**pH:** Negative logarithm of hydrogen ion concentration
- pH = -log[H⁺]
- Range: 0-14 for most aqueous solutions
- **Acidic:** pH < 7
- **Neutral:** pH = 7
- **Basic:** pH > 7

**pOH:** Negative logarithm of hydroxide ion concentration
- pOH = -log[OH⁺]
- pH + pOH = 14 (at 25°C)

**Ion Product of Water (Kw):**
- Kw = [H⁺][OH⁻] = 1.0 × 10⁻¹⁴ (at 25°C)
- Temperature dependent
- Basis for pH + pOH = 14

**Calculations:**

**1. pH from [H⁺]:**
- [H⁺] = 2.5 × 10⁻³ M
- pH = -log(2.5 × 10⁻³) = 2.60

**2. [H⁺] from pH:**
- pH = 3.40
- [H⁺] = 10⁻³·⁴⁰ = 3.98 × 10⁻⁴ M

**3. Strong acid/base calculations:**
- 0.050 M HCl: [H⁺] = 0.050 M, pH = 1.30
- 0.020 M NaOH: [OH⁻] = 0.020 M, pOH = 1.70, pH = 12.30

**4. Dilution calculations:**
- Dilute 10.0 mL of 0.100 M HCl to 100 mL
- New [H⁺] = (0.100 × 0.010) ÷ 0.100 = 0.0100 M
- pH = 2.00

### 8.5 Acid-Base Titrations

**Titration:** Technique for determining unknown concentration
- **Titrant:** Solution of known concentration
- **Analyte:** Solution of unknown concentration
- **Endpoint:** Point where reaction is complete
- **Equivalence point:** Point where stoichiometrically equivalent amounts have reacted

**Types of Titrations:**

**1. Strong Acid-Strong Base:**
- pH curve is steep near equivalence point
- Equivalence point at pH = 7
- Example: HCl + NaOH

**2. Weak Acid-Strong Base:**
- pH curve less steep
- Equivalence point pH > 7
- Example: CH₃COOH + NaOH

**3. Strong Acid-Weak Base:**
- pH curve less steep
- Equivalence point pH < 7
- Example: HCl + NH₃

**Titration Calculations:**
- M₁V₁ = M₂V₂ (for 1:1 reactions)
- Consider stoichiometry for other ratios
- Use indicators that change color near equivalence point pH

**Example:** 25.0 mL of unknown HCl titrated with 0.100 M NaOH
- Endpoint at 35.2 mL NaOH
- M(HCl) = (0.100 × 0.0352) ÷ 0.0250 = 0.141 M

**Common Indicators:**
- **Phenolphthalein:** pH 8.2-10.0 (colorless to pink)
- **Methyl orange:** pH 3.1-4.4 (red to yellow)
- **Bromothymol blue:** pH 6.0-7.6 (yellow to blue)

### 8.6 Buffers

**Buffer:** Solution that resists changes in pH
- Contains weak acid and its conjugate base OR weak base and its conjugate acid
- Effective within ±1 pH unit of pKa

**Buffer Mechanism:**
- **Add acid:** Base component neutralizes added H⁺
- **Add base:** Acid component neutralizes added OH⁻

**Henderson-Hasselbalch Equation:**
- pH = pKa + log([A⁻]/[HA])
- pKa = -log Ka (acid dissociation constant)
- Used to calculate buffer pH and composition

**Buffer Capacity:**
- Amount of acid or base buffer can neutralize
- Increases with higher concentrations
- Maximum when [HA] = [A⁻] (pH = pKa)

**Example Buffer:** Acetic acid/acetate
- Ka = 1.8 × 10⁻⁵, pKa = 4.74
- With [CH₃COOH] = [CH₃COO⁻]: pH = 4.74
- Add HCl: CH₃COO⁻ + H⁺ → CH₃COOH (minimal pH change)

**Buffer Applications:**
- **Biological systems:** Blood pH ~7.4 (bicarbonate buffer)
- **Industrial processes:** Control reaction pH
- **Analytical chemistry:** Maintain consistent conditions

**Preparing Buffers:**
1. Choose appropriate acid-base pair
2. Calculate desired ratio using Henderson-Hasselbalch
3. Mix components in calculated amounts
4. Verify pH with meter

### 8.7 Hydrolysis of Salts

**Hydrolysis:** Reaction of ions with water
- Can produce acidic, basic, or neutral solutions
- Depends on conjugate acid/base strength

**Types of Salt Hydrolysis:**

**1. Salt of Strong Acid + Weak Base → Acidic Solution**
- Example: NH₄Cl → NH₄⁺ + Cl⁻
- NH₄⁺ + H₂O ⇌ NH₃ + H₃O⁺ (acidic)

**2. Salt of Weak Acid + Strong Base → Basic Solution**
- Example: NaCH₃COO → Na⁺ + CH₃COO⁻
- CH₃COO⁻ + H₂O ⇌ CH₃COOH + OH⁻ (basic)

**3. Salt of Strong Acid + Strong Base → Neutral Solution**
- Example: NaCl → Na⁺ + Cl⁻
- Neither ion hydrolyzes significantly

**4. Salt of Weak Acid + Weak Base → pH Depends on Relative Strength**
- Example: NH₄CH₃COO
- Both NH₄⁺ and CH₃COO⁻ hydrolyze
- Final pH depends on Ka vs Kb values

**Calculating pH of Salt Solutions:**
- Use equilibrium expressions for hydrolysis
- Consider both cation and anion contributions
- Use Ka and Kb relationships: Ka × Kb = Kw

**Example:** Calculate pH of 0.100 M NH₄Cl solution
- NH₄⁺ + H₂O ⇌ NH₃ + H₃O⁺
- Ka(NH₄⁺) = Kw/Kb(NH₃) = 1.0×10⁻¹⁴/1.8×10⁻⁵ = 5.6×10⁻¹⁰
- Use ICE table to find [H⁺] and pH

---

**Chapter Summary:**
Acids increase H⁺ concentration while bases increase OH⁻ concentration. Three theories explain acid-base behavior: Arrhenius (aqueous ions), Brønsted-Lowry (proton transfer), and Lewis (electron pairs). Strong acids/bases completely dissociate while weak ones partially dissociate. pH and pOH measure acidity/basicity using logarithmic scales. Titrations determine unknown concentrations through controlled neutralization reactions. Buffers resist pH changes and are crucial in biological systems. Salt hydrolysis explains why some salt solutions are acidic or basic.

**Key Formulas:**
- pH = -log[H⁺]
- pOH = -log[OH⁻]
- pH + pOH = 14
- pH = pKa + log([A⁻]/[HA]) (Henderson-Hasselbalch)
- Ka × Kb = Kw

**Important Concepts:**
- Acid-base theories and their scopes
- Strong vs. weak acids/bases
- Buffer systems and capacity
- Titration curves and endpoints
- Salt hydrolysis patterns

**Practice Problems:**
1. Calculate the pH of a 0.0025 M HCl solution.
2. What is the pOH of a solution with [OH⁻] = 3.2 × 10⁻³ M?
3. Calculate the pH of a buffer containing 0.100 M acetic acid and 0.150 M acetate ion (pKa = 4.74).
4. Predict whether a solution of NaF will be acidic, basic, or neutral, and explain why.

---

## Chapter 10: Chemical Kinetics and Equilibrium

### 10.1 Reaction Rates

**Reaction Rate:** Change in concentration of reactants or products per unit time
- **Units:** typically M/s or mol/(L·s)
- **Average rate:** Over a time interval
- **Instantaneous rate:** At a specific moment (slope of concentration vs. time curve)

**Rate Expression:**
- Rate = -Δ[reactant]/Δt = Δ[product]/Δt
- Negative sign for reactants (concentration decreases)
- Positive sign for products (concentration increases)

**Example Reaction:** A → B
- Rate = -d[A]/dt = d[B]/dt

**Measuring Reaction Rates:**
- **Spectrophotometry:** Monitor absorbance changes
- **Gas evolution:** Measure volume or pressure changes
- **Conductivity:** Track ion concentration changes
- **Titration:** Periodic sampling and analysis

**Factors Affecting Reaction Rates:**
1. **Concentration:** Higher concentration → faster reaction (more collisions)
2. **Temperature:** Higher temperature → faster reaction (more kinetic energy)
3. **Catalysts:** Lower activation energy → faster reaction
4. **Surface area:** Greater surface area → faster reaction (heterogeneous)
5. **Nature of reactants:** Chemical properties affect reactivity

### 10.2 Factors Affecting Reaction Rates

**1. Concentration Effects:**
- **Collision theory:** More particles → more frequent collisions
- **Effective collisions:** Proper orientation and sufficient energy
- **Rate law:** Mathematical relationship between rate and concentrations

**2. Temperature Effects:**
- **Arrhenius equation:** k = Ae^(-Ea/RT)
- **Activation energy (Ea):** Minimum energy for reaction
- **Frequency factor (A):** Collision frequency and orientation
- **Rule of thumb:** Rate doubles for every 10°C increase (approximate)

**3. Catalyst Effects:**
- **Catalyst:** Substance that speeds reaction without being consumed
- **Mechanism:** Provides alternative reaction pathway
- **Lower Ea:** Reduces activation energy required
- **Types:** Homogeneous (same phase) and heterogeneous (different phase)

**4. Surface Area Effects:**
- **Heterogeneous reactions:** Different phases react
- **Powdered vs. solid:** Powdered materials react faster
- **Examples:** Coal dust explosion, metal powders in synthesis

**Collision Theory Summary:**
- **Collision frequency:** How often particles collide
- **Collision energy:** Whether collisions have sufficient energy
- **Collision orientation:** Whether particles are properly aligned
- **Effective collisions:** Meet all three criteria

### 10.3 Rate Laws

**Rate Law:** Mathematical expression relating reaction rate to reactant concentrations
- **Form:** Rate = k[A]^m[B]^n
- **k:** Rate constant (temperature dependent)
- **m, n:** Reaction orders (determined experimentally)
- **Overall order:** Sum of individual orders

**Elementary Reactions:**
- **Single step:** Reactants → Products directly
- **Molecularity:** Number of particles colliding
- **Rate law:** Can be written from stoichiometry

**Complex Reactions:**
- **Multiple steps:** Series of elementary reactions
- **Rate-determining step:** Slowest step controls overall rate
- **Rate law:** Must be determined experimentally

**Examples of Rate Laws:**

**1. First-order reaction:**
- 2N₂O₅ → 4NO₂ + O₂
- Rate = k[N₂O₅]
- [A] vs. time: exponential decay

**2. Second-order reaction:**
- 2NO₂ → 2NO + O₂
- Rate = k[NO₂]²
- 1/[A] vs. time: linear relationship

**3. Mixed-order reaction:**
- 2NO + O₂ → 2NO₂
- Rate = k[NO]²[O₂]
- Overall order = 3

**Determining Rate Laws:**
- **Method of initial rates:** Compare initial rates at different concentrations
- **Integrated rate laws:** Fit concentration vs. time data
- **Graphical methods:** Linear plots for different orders

### 10.4 Reaction Mechanisms

**Reaction Mechanism:** Step-by-step pathway of reaction
- **Elementary steps:** Individual molecular collisions
- **Intermediates:** Species formed and consumed during reaction
- **Catalysts:** Appear in mechanism but not overall equation

**Characteristics of Valid Mechanisms:**
1. Sum of elementary steps gives overall reaction
2. Rate law from mechanism matches experimental rate law
3. Reasonable molecular-level steps
4. Consistent with thermodynamic data

**Example Mechanism:**
**Overall:** 2NO + O₂ → 2NO₂

**Proposed mechanism:**
Step 1: NO + O₂ ⇌ NO₃ (fast equilibrium)
Step 2: NO₃ + NO → 2NO₂ (slow, rate-determining)

**Rate law from mechanism:**
Rate = k₂[NO₃][NO]
From Step 1: K = [NO₃]/([NO][O₂]) → [NO₃] = K[NO][O₂]
Substitute: Rate = k₂K[NO][O₂][NO] = k[NO]²[O₂]

**Catalysis Mechanisms:**

**Homogeneous catalysis:**
- Catalyst in same phase as reactants
- Forms intermediate complexes
- Regenerated at end of cycle

**Heterogeneous catalysis:**
- Catalyst in different phase (usually solid)
- Adsorption, reaction, desorption steps
- Surface area critical

### 10.5 Chemical Equilibrium

**Chemical Equilibrium:** State where forward and reverse reaction rates are equal
- **Dynamic:** Reactions continue but concentrations remain constant
- **Reversible:** Most reactions are reversible to some extent
- **No net change:** Concentrations remain constant over time

**Characteristics of Equilibrium:**
- **Forward rate = Reverse rate**
- **Concentrations constant** (but not necessarily equal)
- **Macroscopic properties constant**
- **Can be reached from either direction**

**Equilibrium Constant (K):**
- **Ratio of product to reactant concentrations** at equilibrium
- **Temperature dependent**
- **Independent of initial concentrations**
- **Form:** K = [products]^coefficients / [reactants]^coefficients

**Types of Equilibrium Constants:**
- **Kc:** Based on concentrations (solutions, gases)
- **Kp:** Based on partial pressures (gases)
- **Ksp:** Solubility product (slightly soluble salts)
- **Ka/Kb:** Acid/base equilibrium constants

**Example:**
**N₂ + 3H₂ ⇌ 2NH₃**
**Kc = [NH₃]² / ([N₂][H₂]³)**

### 10.6 Le Chatelier's Principle

**Le Chatelier's Principle:** If stress is applied to system at equilibrium, system shifts to relieve stress

**Types of Stresses:**

**1. Concentration Changes:**
- **Add reactant:** Shift right (toward products)
- **Add product:** Shift left (toward reactants)
- **Remove reactant:** Shift left
- **Remove product:** Shift right

**2. Temperature Changes:**
- **Exothermic reaction:** Heat is product
- **Endothermic reaction:** Heat is reactant
- **Increase temperature:** Shift away from added heat
- **Decrease temperature:** Shift toward heat

**3. Pressure Changes (gases):**
- **Increase pressure:** Shift toward fewer gas moles
- **Decrease pressure:** Shift toward more gas moles
- **Inert gas addition:** No effect (if volume constant)

**4. Catalyst Addition:**
- **Catalyst:** Lowers activation energy for both directions
- **No shift:** Both forward and reverse rates increased equally
- **Faster equilibrium:** Same equilibrium reached faster

**Examples:**

**N₂ + 3H₂ ⇌ 2NH₃ (exothermic)**
- **Increase [N₂]:** Shift right → more NH₃
- **Increase temperature:** Shift left → less NH₃
- **Increase pressure:** Shift right → fewer gas molecules (2 vs 4)
- **Add catalyst:** No shift, faster equilibrium

### 10.7 Equilibrium Calculations

**ICE Tables:** Initial, Change, Equilibrium
- **Systematic method** for equilibrium calculations
- **Steps:**
  1. Write balanced equation
  2. Set up ICE table
  3. Express concentrations in terms of x
  4. Write equilibrium expression
  5. Solve for x
  6. Calculate equilibrium concentrations

**Example Problem:**
**N₂ + 3H₂ ⇌ 2NH₃**
**Kc = 6.0 × 10⁻²**
**Initial: [N₂] = 1.0 M, [H₂] = 2.0 M, [NH₃] = 0**

**ICE Table:**
| | N₂ | H₂ | NH₃ |
|---|---|---|---|
| Initial | 1.0 | 2.0 | 0 |
| Change | -x | -3x | +2x |
| Equilibrium | 1.0-x | 2.0-3x | 2x |

**Equilibrium expression:**
Kc = [NH₃]²/([N₂][H₂]³) = (2x)²/((1.0-x)(2.0-3x)³) = 6.0×10⁻²
**Solve for x** (often requires approximation or iterative methods)

### 10.8 Solubility Equilibrium

**Solubility Equilibrium:** Dissolved ions ↔ solid precipitate
- **Saturated solution:** Maximum dissolved concentration
- **Dynamic equilibrium:** Dissolution and precipitation occur simultaneously

**Solubility Product (Ksp):**
- **Equilibrium constant for dissolution**
- **Ksp = [cations]^m[anions]^n**
- **Temperature dependent**
- **Measure of solubility** for slightly soluble salts

**Example:** AgCl ⇌ Ag⁺ + Cl⁻
- **Ksp = [Ag⁺][Cl⁻]**
- **If [Ag⁺] = [Cl⁻] = s at saturation:**
- **Ksp = s² → s = √Ksp**

**Common Ion Effect:**
- **Solubility decreases** when common ion is present
- **Le Chatelier's principle:** Add product shifts equilibrium left
- **Example:** AgCl solubility lower in AgNO₃ solution than in pure water

**Calculations:**

**1. Calculate solubility from Ksp:**
- Ag₂CrO₄ ⇌ 2Ag⁺ + CrO₄²⁻
- Ksp = [Ag⁺]²[CrO₄²⁻] = (2s)²(s) = 4s³
- s = ∛(Ksp/4)

**2. Calculate Ksp from solubility:**
- PbCl₂ solubility = 1.6×10⁻² M
- PbCl₂ ⇌ Pb²⁺ + 2Cl⁻
- Ksp = [Pb²⁺][Cl⁻]² = (1.6×10⁻²)(2×1.6×10⁻²)² = 1.6×10⁻⁵

**Precipitation Criteria:**
- **Q > Ksp:** Precipitation occurs (supersaturated)
- **Q = Ksp:** Equilibrium (saturated)
- **Q < Ksp:** No precipitation (unsaturated)
- **Q:** Reaction quotient (calculated with initial concentrations)

---

**Chapter Summary:**
Chemical kinetics studies reaction rates and factors affecting them. Reaction rates depend on concentration, temperature, catalysts, surface area, and reactant nature. Rate laws mathematically describe the relationship between rate and concentrations, and must be determined experimentally. Reaction mechanisms detail stepwise processes with rate-determining steps controlling overall rates. Chemical equilibrium occurs when forward and reverse reaction rates equal, characterized by equilibrium constants. Le Chatelier's principle predicts how systems respond to stresses like concentration, temperature, and pressure changes. Solubility equilibrium governs precipitation and dissolution processes through the solubility product constant.

**Key Formulas:**
- Arrhenius equation: k = Ae^(-Ea/RT)
- Rate law: Rate = k[A]^m[B]^n
- Equilibrium expression: K = [products]^coefficients / [reactants]^coefficients
- Relationship: Q = reaction quotient, Ksp = solubility product

**Important Concepts:**
- Collision theory and effective collisions
- Rate-determining step in mechanisms
- ICE tables for equilibrium calculations
- Le Chatelier's principle applications
- Common ion effect on solubility

**Practice Problems:**
1. For the reaction A + B → C, the rate law is Rate = k[A][B]². What is the overall order?
2. At equilibrium, [N₂] = 0.50 M, [H₂] = 0.10 M, and [NH₃] = 0.20 M for N₂ + 3H₂ ⇌ 2NH₃. Calculate Kc.
3. Will precipitation occur when 100 mL of 0.010 M AgNO₃ is mixed with 100 mL of 0.010 M NaCl? (Ksp(AgCl) = 1.8×10⁻¹⁰)
4. How does increasing temperature affect an exothermic reaction at equilibrium? Explain using Le Chatelier's principle.

---

## Chapter 13: Organic Chemistry Basics

### 13.1 Introduction to Organic Chemistry

**Organic Chemistry:** Study of carbon-containing compounds
- **Carbon's unique properties:** Forms 4 bonds, chains, rings, complex structures
- **Abundance:** Over 10 million known organic compounds
- **Importance:** Basis of life, pharmaceuticals, plastics, fuels

**Carbon Bonding Characteristics:**
- **Tetravalent:** Forms 4 covalent bonds
- **Hybridization:** sp³, sp², sp orbitals
- **Chain formation:** Straight, branched, cyclic structures
- **Multiple bonding:** Single, double, triple bonds

**Hydrocarbons:** Organic compounds containing only carbon and hydrogen
- **Alkanes:** Single bonds only (saturated)
- **Alkenes:** One or more double bonds (unsaturated)
- **Alkynes:** One or more triple bonds (unsaturated)
- **Aromatic:** Ring structures with delocalized electrons

**Functional Groups:** Specific atom groups that determine chemical properties
- **Reactivity centers:** Most organic reactions occur at functional groups
- **Classification:** Compounds grouped by functional groups
- **Predictions:** Functional groups predict physical and chemical properties

### 13.2 Hydrocarbons

**Alkanes (CₙH₂ₙ₊₂):** Saturated hydrocarbons with single bonds only
- **Naming:** Based on carbon chain length (methane, ethane, propane...)
- **Properties:** Nonpolar, low boiling points, flammable
- **Isomerism:** Structural isomers with same formula
- **Conformations:** Different spatial arrangements

**Examples:**
- **Methane (CH₄):** Natural gas
- **Ethane (C₂H₆):** Component of natural gas
- **Propane (C₃H₈):** Fuel for heating and cooking
- **Butane (C₄H₁₀):** Lighter fuel, aerosol propellant

**Alkenes (CₙH₂ₙ):** Unsaturated hydrocarbons with double bonds
- **Naming:** -ene suffix, position indicated (1-butene, 2-butene)
- **Properties:** More reactive than alkanes
- **Geometric isomerism:** Cis-trans isomerism around double bonds
- **Reactions:** Addition reactions across double bond

**Examples:**
- **Ethene (C₂H₄):** Plant hormone, polymer precursor
- **Propene (C₃H₆):** Polypropylene precursor
- **Butene (C₄H₈):** Two isomers: 1-butene, 2-butene

**Alkynes (CₙH₂ₙ₋₂):** Unsaturated hydrocarbons with triple bonds
- **Naming:** -yne suffix (acetylene, propyne)
- **Properties:** Highly reactive, linear geometry around triple bond
- **Industrial uses:** Welding (acetylene), organic synthesis

**Cycloalkanes:** Saturated ring structures
- **Formula:** CₙH₂ₙ
- **Strain:** Ring strain affects stability
- **Examples:** Cyclohexane (C₆H₁₂), cyclopentane (C₅H₁₀)

### 13.3 Functional Groups

**Alcohols (-OH):** Hydroxyl group bonded to carbon
- **General formula:** R-OH
- **Classification:** Primary, secondary, tertiary based on carbon attachment
- **Properties:** Polar, hydrogen bonding, higher boiling points than alkanes
- **Naming:** -ol suffix (methanol, ethanol, propanol)
- **Reactions:** Oxidation to aldehydes/ketones, substitution, esterification

**Aldehydes (-CHO):** Carbonyl group at end of carbon chain
- **General formula:** R-CHO
- **Properties:** Polar, reactive carbonyl carbon
- **Naming:** -al suffix (methanal, ethanal)
- **Reactions:** Oxidation to acids, reduction to alcohols

**Ketones (>C=O):** Carbonyl group within carbon chain
- **General formula:** R-CO-R'
- **Properties:** Polar, less reactive than aldehydes
- **Naming:** -one suffix (propanone, butanone)
- **Examples:** Acetone (propanone), nail polish remover

**Carboxylic Acids (-COOH):** Terminal carbonyl with hydroxyl
- **General formula:** R-COOH
- **Properties:** Acidic (donate H⁺), hydrogen bonding
- **Naming:** -oic acid suffix (ethanoic acid)
- **Reactions:** Esterification, neutralization, reduction

**Esters (-COOR):** Carbonyl bonded to alkoxy group
- **General formula:** R-COOR'
- **Properties:** Often pleasant odors (fruits, flowers)
- **Naming:** Alkyl alkanoate (ethyl ethanoate)
- **Formation:** Esterification of carboxylic acids and alcohols

**Amines (-NH₂):** Nitrogen-based functional group
- **General formula:** R-NH₂
- **Properties:** Basic, polar, fishy odors
- **Classification:** Primary, secondary, tertiary
- **Importance:** Amino acids, pharmaceuticals

### 13.4 Isomerism

**Isomers:** Compounds with same molecular formula but different structures
- **Structural isomers:** Different connectivity
- **Stereoisomers:** Same connectivity, different spatial arrangement

**Types of Structural Isomerism:**

**1. Chain Isomerism:**
- Different carbon chain arrangements
- **Example:** C₅H₁₂: n-pentane, isopentane, neopentane

**2. Position Isomerism:**
- Functional group in different positions
- **Example:** C₃H₇Cl: 1-chloropropane, 2-chloropropane

**3. Functional Group Isomerism:**
- Different functional groups with same formula
- **Example:** C₃H₆O: propanal (aldehyde), propanone (ketone)

**Types of Stereoisomerism:**

**1. Geometric Isomerism:**
- Restricted rotation around double bonds
- **Cis isomer:** Same side
- **Trans isomer:** Opposite sides
- **Example:** 2-butene: cis-2-butene, trans-2-butene

**2. Optical Isomerism:**
- Chiral centers (four different groups)
- **Enantiomers:** Non-superimposable mirror images
- **Properties:** Same physical properties except optical rotation
- **Importance:** Biological activity differs between enantiomers

### 13.5 Basic Organic Reactions

**Substitution Reactions:** One atom/group replaces another
- **SN1:** Two-step mechanism, carbocation intermediate
- **SN2:** One-step mechanism, backside attack
- **Factors:** Substrate structure, nucleophile strength, solvent

**Elimination Reactions:** Remove atoms to form multiple bonds
- **E1:** Two-step, carbocation intermediate
- **E2:** One-step, base removes hydrogen
- **Products:** Alkenes, alkynes

**Addition Reactions:** Add atoms across multiple bonds
- **Hydrogenation:** Add H₂ across double/triple bonds
- **Halogenation:** Add halogens (Br₂, Cl₂)
- **Hydrohalogenation:** Add HX (HCl, HBr)
- **Hydration:** Add H₂O

**Oxidation-Reduction Reactions:**
- **Oxidation:** Increase in oxidation state, loss of H, gain of O
- **Reduction:** Decrease in oxidation state, gain of H, loss of O
- **Common oxidizing agents:** KMnO₄, K₂Cr₂O₇, O₃
- **Common reducing agents:** NaBH₄, LiAlH₄, H₂, Na

**Polymerization:**
- **Addition polymerization:** Monomers add to growing chain
- **Condensation polymerization:** Small molecules eliminated
- **Natural polymers:** Proteins, DNA, cellulose
- **Synthetic polymers:** Plastics, synthetic fibers

### 13.6 Polymers

**Polymers:** Large molecules made of repeating monomer units
- **Molecular weight:** Ranges from thousands to millions
- **Properties:** Depend on monomer type and polymer structure
- **Applications:** Plastics, fibers, rubber, coatings

**Types of Polymerization:**

**1. Addition (Chain-Growth) Polymerization:**
- **Mechanism:** Free radical, cationic, or anionic
- **Monomers:** Typically contain double bonds
- **Examples:**
  - Polyethylene from ethene
  - Polypropylene from propene
  - PVC from chloroethene

**2. Condensation (Step-Growth) Polymerization:**
- **Mechanism:** Monomers react eliminating small molecules
- **Eliminated molecules:** H₂O, HCl, alcohol
- **Examples:**
  - Nylon from diamines and dicarboxylic acids
  - Polyester from diols and dicarboxylic acids
  - Polycarbonate from bisphenol A and phosgene

**Polymer Properties:**
- **Crystallinity:** Affects strength, melting point
- **Cross-linking:** Increases rigidity, thermal stability
- **Molecular weight distribution:** Affects processing properties
- **Additives:** Plasticizers, stabilizers, fillers

**Biopolymers:**
- **Proteins:** Amino acid polymers
- **DNA/RNA:** Nucleotide polymers
- **Polysaccharides:** Sugar polymers (cellulose, starch)
- **Applications:** Biodegradable plastics, medical materials

---

**Chapter Summary:**
Organic chemistry studies carbon-containing compounds, which form the basis of life and many industrial materials. Hydrocarbons include alkanes (saturated), alkenes (unsaturated), and alkynes, with properties determined by bonding patterns. Functional groups such as alcohols, aldehydes, ketones, carboxylic acids, esters, and amines confer specific reactivity patterns. Isomerism creates compounds with identical formulas but different structures or arrangements. Basic organic reactions include substitution, elimination, addition, and oxidation-reduction processes. Polymers, both synthetic and natural, are important macromolecules formed through addition or condensation polymerization.

**Key Concepts:**
- Carbon's unique bonding capabilities
- Hydrocarbon classification and properties
- Functional group identification and reactivity
- Types of isomerism and their effects
- Major organic reaction types
- Polymerization mechanisms and applications

**Practice Problems:**
1. Name and draw the structure for C₅H₁₂ with the following: a) straight chain, b) one branch, c) two branches.
2. Identify the functional groups in: a) CH₃CH₂OH, b) CH₃COCH₃, c) CH₃COOH.
3. Draw cis- and trans-2-butene and explain why they're different compounds.
4. Write reaction equation for polymerization of ethene to form polyethylene.

---

## Appendices

### A. Periodic Table of Elements

**Periodic Trends Summary:**
- **Atomic radius:** Increases down groups, decreases across periods
- **Ionization energy:** Decreases down groups, increases across periods  
- **Electronegativity:** Decreases down groups, increases across periods
- **Metallic character:** Increases down groups, decreases across periods

**Element Categories:**
- **Metals:** Left side and center of periodic table
- **Nonmetals:** Upper right side (plus hydrogen)
- **Metalloids:** Staircase line between metals and nonmetals

### B. Common Ion Charges

**Cations (Positive Ions):**
- **Group 1:** +1 (Li⁺, Na⁺, K⁺, Rb⁺, Cs⁺)
- **Group 2:** +2 (Be²⁺, Mg²⁺, Ca²⁺, Sr²⁺, Ba²⁺)
- **Group 13:** +3 (Al³⁺, Ga³⁺, In³⁺, Tl³⁺)
- **Transition metals:** Variable (Fe²⁺/Fe³⁺, Cu⁺/Cu²⁺, Zn²⁺)
- **Silver:** Ag⁺, **Lead:** Pb²⁺/Pb⁴⁺, **Tin:** Sn²⁺/Sn⁴⁺

**Anions (Negative Ions):**
- **Group 15:** -3 (N³⁻, P³⁻, As³⁻)
- **Group 16:** -2 (O²⁻, S²⁻, Se²⁻)
- **Group 17:** -1 (F⁻, Cl⁻, Br⁻, I⁻)
- **Polyatomic ions:** NO₃⁻, SO₄²⁻, PO₄³⁻, CO₃²⁻, OH⁻, NH₄⁺

### C. Solubility Rules

**Generally Soluble Compounds:**
1. All compounds of Group 1 elements and NH₄⁺
2. All nitrates (NO₃⁻), acetates (CH₃COO⁻), and perchlorates (ClO₄⁻)
3. Most chlorides, bromides, and iodides (exceptions: Ag⁺, Pb²⁺, Hg₂²⁺)
4. Most sulfates (exceptions: Ba²⁺, Pb²⁺, Ca²⁺, Sr²⁺, Ag⁺)

**Generally Insoluble Compounds:**
1. Most carbonates (CO₃²⁻), phosphates (PO₄³⁻), chromates (CrO₄²⁻), sulfides (S²⁻)
2. Most hydroxides (exceptions: Group 1, Ba²⁺, Ca²⁺, Sr²⁺)
3. Most oxides (exceptions: Group 1, Group 2)

**Special Cases:**
- **Slightly soluble:** CaCO₃, AgCl, BaSO₄
- **Temperature dependent:** Many salts more soluble at higher temperatures

### D. Important Constants and Conversions

**Fundamental Constants:**
- **Avogadro's number:** 6.022 × 10²³ particles/mol
- **Gas constant (R):** 0.08206 L·atm/mol·K = 8.314 J/mol·K
- **Planck's constant:** 6.626 × 10⁻³⁴ J·s
- **Speed of light:** 2.998 × 10⁸ m/s
- **Elementary charge:** 1.602 × 10⁻¹⁹ C
- **Faraday constant:** 96,485 C/mol

**Temperature Conversions:**
- **K = °C + 273.15**
- **°C = (°F - 32) × 5/9**
- **°F = (9/5)°C + 32**

**Pressure Conversions:**
- **1 atm = 760 mmHg = 760 torr = 101.3 kPa = 14.7 psi**
- **1 Pa = 1 N/m²**

**Energy Conversions:**
- **1 cal = 4.184 J**
- **1 kcal = 4.184 kJ**
- **1 eV = 1.602 × 10⁻¹⁹ J**

**Mass Conversions:**
- **1 kg = 2.205 lb**
- **1 g = 1000 mg**
- **1 atomic mass unit = 1.661 × 10⁻²⁴ g**

**Volume Conversions:**
- **1 L = 1000 mL = 1000 cm³ = 1 dm³**
- **1 gallon = 3.785 L**
- **1 cubic foot = 28.317 L**

### E. Laboratory Techniques

**Measurement Techniques:**
- **Mass measurement:** Use analytical balance, weigh by difference
- **Volume measurement:** Graduated cylinders for approximate, volumetric flasks for precise
- **Temperature measurement:** Calibrate thermometer, avoid thermometer shock
- **pH measurement:** Calibrate pH meter with buffer solutions

**Safety Equipment:**
- **Fume hood:** Use for volatile or hazardous substances
- **Safety shower:** For chemical splashes on body
- **Eyewash station:** For eye contamination
- **Fire extinguisher:** Know types and locations
- **Spill kit:** For chemical cleanup

**Glassware Care:**
- **Cleaning:** Use appropriate cleaning solutions, rinse thoroughly
- **Drying:** Air dry or use oven (check temperature limits)
- **Storage:** Store upright, protect from breakage
- **Inspection:** Check for cracks before use

**Titration Techniques:**
- **Burette preparation:** Rinse with solution, remove air bubbles
- **Endpoint detection:** Use appropriate indicator, observe color change
- **Titration speed:** Add slowly near endpoint
- **Record keeping:** Note initial and final volumes

### F. Mathematical Review

**Significant Figures Rules:**
1. All non-zero digits are significant
2. Zeros between non-zero digits are significant
3. Leading zeros are not significant
4. Trailing zeros after decimal are significant
5. Use scientific notation for clarity

**Logarithm Operations:**
- **log(a × b) = log(a) + log(b)**
- **log(a/b) = log(a) - log(b)**
- **log(aⁿ) = n × log(a)**
- **pH = -log[H⁺]**

**Exponential Notation:**
- **Scientific notation:** a × 10ⁿ where 1 ≤ a < 10
- **Engineering notation:** a × 10ⁿ where n is multiple of 3
- **Arithmetic:** Handle exponents separately from coefficients

**Algebra for Equilibrium:**
- **Quadratic formula:** For ax² + bx + c = 0, x = [-b ± √(b² - 4ac)]/2a
- **ICE tables:** Systematic method for equilibrium calculations
- **Approximation method:** Use when K is very small or large

### G. Glossary of Terms

**A**
- **Acid:** Substance that donates H⁺ ions (Brønsted-Lowry) or accepts electron pairs (Lewis)
- **Alkali metal:** Group 1 element, highly reactive metal
- **Alloy:** Mixture of metals or metal with nonmetal
- **Anion:** Negatively charged ion
- **Atom:** Smallest unit of element that retains chemical properties
- **Atomic number:** Number of protons in nucleus

**B**
- **Base:** Substance that accepts H⁺ ions (Brønsted-Lowry) or donates electron pairs (Lewis)
- **Boiling point:** Temperature at which liquid vapor pressure equals atmospheric pressure
- **Bond:** Attractive force holding atoms together
- **Boyle's law:** Pressure and volume are inversely proportional at constant temperature

**C**
- **Catalyst:** Substance that speeds reaction without being consumed
- **Cation:** Positively charged ion
- **Chemical change:** Change producing new substances
- **Compound:** Substance formed from two or more elements in fixed ratio
- **Concentration:** Amount of solute per amount of solution or solvent

**D**
- **Density:** Mass per unit volume
- **Dissociation:** Separation of ions in solution
- **Double displacement reaction:** Exchange of parts between two compounds

**E**
- **Electron:** Negatively charged subatomic particle
- **Element:** Pure substance consisting of only one type of atom
- **Endothermic:** Reaction absorbing heat energy
- **Equilibrium:** State where forward and reverse reaction rates are equal
- **Exothermic:** Reaction releasing heat energy

**F**
- **Formula:** Symbolic representation of compound composition
- **Freezing point:** Temperature at which liquid becomes solid
- **Functional group:** Specific arrangement of atoms determining chemical properties

**H**
- **Halogen:** Group 17 element, highly reactive nonmetal
- **Heat:** Energy transferred due to temperature difference
- **Hydrogen bond:** Strong dipole-dipole attraction involving H bonded to N, O, or F

**I**
- **Ion:** Atom or molecule with electrical charge
- **Ionic bond:** Electrostatic attraction between oppositely charged ions
- **Isotope:** Atoms with same atomic number but different mass numbers

**K**
- **Kinetic energy:** Energy of motion
- **Kinetic molecular theory:** Theory explaining behavior of gases

**M**
- **Matter:** Anything with mass and volume
- **Mixture:** Combination of two or more substances not chemically combined
- **Molecule:** Group of atoms bonded together
- **Molar mass:** Mass of one mole of substance

**N**
- **Neutron:** Neutral subatomic particle in nucleus
- **Noble gas:** Group 18 element, very unreactive
- **Nucleus:** Central part of atom containing protons and neutrons

**O**
- **Orbital:** Region in atom where electrons are likely found
- **Oxidation:** Loss of electrons or increase in oxidation state
- **Oxidation number:** Charge assigned to atom in compound

**P**
- **pH:** Measure of acidity, -log[H⁺]
- **Physical change:** Change not producing new substances
- **Polymer:** Large molecule made of repeating units
- **Proton:** Positively charged subatomic particle

**R**
- **Reduction:** Gain of electrons or decrease in oxidation state
- **Reaction:** Process of chemical change
- **Reversible reaction:** Reaction that can proceed in both directions

**S**
- **Solution:** Homogeneous mixture of two or more substances
- **Solubility:** Maximum amount of solute that can dissolve
- **Solvent:** Substance doing the dissolving
- **Solute:** Substance being dissolved

**T**
- **Titration:** Technique for determining unknown concentration
- **Transition metal:** Element in d-block of periodic table

**V**
- **Valence electrons:** Electrons in outermost shell
- **Vapor pressure:** Pressure of vapor above liquid

**W**
- **Weight:** Force of gravity on mass

---

## Index of Key Topics

**Atomic Structure:** electron configuration, isotopes, periodic trends
**Chemical Bonding:** ionic, covalent, metallic, intermolecular forces
**Chemical Reactions:** balancing, types, redox, stoichiometry
**Gases:** gas laws, kinetic molecular theory, real gases
**Solutions:** concentration, colligative properties, solubility
**Acids and Bases:** pH, titrations, buffers, hydrolysis
**Equilibrium:** chemical equilibrium, Le Chatelier's principle
**Kinetics:** reaction rates, rate laws, mechanisms
**Organic Chemistry:** hydrocarbons, functional groups, polymers

---

**Final Notes:**
This textbook provides a comprehensive foundation in high school chemistry. Each chapter builds upon previous concepts, creating a cohesive understanding of chemical principles. Practice problems and real-world applications reinforce learning. Chemistry is an experimental science - laboratory work complements theoretical understanding. Continued study will reveal fascinating connections between chemistry and other scientific fields, as well as its applications in technology, medicine, environmental science, and everyday life.

Remember that chemistry is not just memorization of facts, but understanding patterns and applying principles to solve problems. The periodic table, conservation laws, and equilibrium concepts provide frameworks that apply throughout chemistry. Master these fundamentals, and more complex topics become manageable.