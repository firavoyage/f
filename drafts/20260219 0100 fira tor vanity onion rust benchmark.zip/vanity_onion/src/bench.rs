use ed25519_dalek::SigningKey;
use rand::rngs::OsRng;
use rand::RngCore;
use sha3::{Digest, Sha3_256};
use data_encoding::BASE32_NOPAD;
use rayon::prelude::*;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Instant;

fn onion_address(pubkey: &[u8]) -> String {
    let version: u8 = 0x03;

    let mut hasher = Sha3_256::new();
    hasher.update(b".onion checksum");
    hasher.update(pubkey);
    hasher.update(&[version]);
    let checksum = hasher.finalize();

    let mut address_bytes = Vec::new();
    address_bytes.extend_from_slice(pubkey);
    address_bytes.extend_from_slice(&checksum[..2]);
    address_bytes.push(version);

    BASE32_NOPAD.encode(&address_bytes).to_lowercase()
}

fn main() {
    let duration_secs = 10;
    let counter = Arc::new(AtomicU64::new(0));
    let start = Instant::now();

    (0..num_cpus::get()).into_par_iter().for_each(|_| {
        let mut csprng = OsRng;

        while start.elapsed().as_secs() < duration_secs {
            let mut secret = [0u8; 32];
            csprng.fill_bytes(&mut secret);
            let signing_key = SigningKey::from_bytes(&secret);
            let verify_key = signing_key.verifying_key();
            let _ = onion_address(verify_key.as_bytes());
            counter.fetch_add(1, Ordering::Relaxed);
        }
    });

    let elapsed = start.elapsed().as_secs_f64();
    let attempts = counter.load(Ordering::Relaxed);

    println!("Ran for {:.2} seconds", elapsed);
    println!("Total attempts: {}", attempts);
    println!("Speed: {:.0} keys/sec", attempts as f64 / elapsed);
}
