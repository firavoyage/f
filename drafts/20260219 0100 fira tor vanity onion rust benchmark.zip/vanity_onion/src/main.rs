use data_encoding::BASE32_NOPAD;
use ed25519_dalek::SigningKey;
use rand::rngs::OsRng;
use rayon::prelude::*;
use sha3::{Digest, Sha3_256};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

fn onion_address(pubkey: &[u8]) -> String {
    let version: u8 = 0x03;

    let mut hasher = Sha3_256::new();
    hasher.update(b".onion checksum");
    hasher.update(pubkey);
    hasher.update(&[version]);
    let checksum = hasher.finalize();

    let mut address_bytes = Vec::new();
    address_bytes.extend_from_slice(pubkey);
    address_bytes.extend_from_slice(&checksum[..2]);
    address_bytes.push(version);

    BASE32_NOPAD.encode(&address_bytes).to_lowercase()
}

fn main() {
    let prefix = "fira2007"; // change this
    let found = Arc::new(AtomicBool::new(false));

    (0..num_cpus::get()).into_par_iter().for_each(|_| {
        let mut csprng = OsRng;

        while !found.load(Ordering::Relaxed) {
            use rand::RngCore;

            let mut secret = [0u8; 32];
            csprng.fill_bytes(&mut secret);
            let signing_key = SigningKey::from_bytes(&secret);
            let verify_key = signing_key.verifying_key();
            let address = onion_address(verify_key.as_bytes());

            if address.starts_with(prefix) {
                println!("FOUND: {}.onion", address);
                println!("Private key: {:?}", signing_key.to_bytes());
                found.store(true, Ordering::Relaxed);
                break;
            }
        }
    });
}
