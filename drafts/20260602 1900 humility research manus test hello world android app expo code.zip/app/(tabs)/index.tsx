import { ScrollView, Text, View, TouchableOpacity } from "react-native";

import { ScreenContainer } from "@/components/screen-container";

/**
 * Home Screen - NativeWind Example
 *
 * This template uses NativeWind (Tailwind CSS for React Native).
 * You can use familiar Tailwind classes directly in className props.
 *
 * Key patterns:
 * - Use `className` instead of `style` for most styling
 * - Theme colors: use tokens directly (bg-background, text-foreground, bg-primary, etc.); no dark: prefix needed
 * - Responsive: standard Tailwind breakpoints work on web
 * - Custom colors defined in tailwind.config.js
 */
export default function HomeScreen() {
  return (
    <ScreenContainer className="flex-1 items-center justify-center px-6">
      <View className="items-center gap-6">
        {/* Main Hello World Message */}
        <Text className="text-6xl font-bold text-foreground text-center">
          Hello World
        </Text>
        
        {/* Subtitle */}
        <Text className="text-lg text-muted text-center leading-relaxed">
          Welcome to your React Native mobile app built with Expo
        </Text>
        
        {/* Decorative Line */}
        <View className="w-16 h-1 bg-primary rounded-full mt-4" />
      </View>
    </ScreenContainer>
  );
}
