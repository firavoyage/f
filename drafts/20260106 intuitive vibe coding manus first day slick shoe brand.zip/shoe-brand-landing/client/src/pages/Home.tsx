import { Button } from "@/components/ui/button";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Zap, Activity, Layers, ChevronDown } from "lucide-react";
import CustomCursor from "@/components/CustomCursor";
import GlitchText from "@/components/GlitchText";
import { useRef } from "react";

export default function Home() {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden selection:bg-primary selection:text-background cursor-none">
      <CustomCursor />
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 w-full z-40 px-8 py-6 flex justify-between items-center mix-blend-difference">
        <div className="text-2xl font-bold tracking-tighter uppercase font-['Monument_Extended']">
          STRIDE<span className="text-primary">.</span>
        </div>
        <div className="hidden md:flex gap-8 text-sm font-mono tracking-widest">
          <a href="#" className="hover:text-primary transition-colors">COLLECTION</a>
          <a href="#" className="hover:text-primary transition-colors">TECHNOLOGY</a>
          <a href="#" className="hover:text-primary transition-colors">ABOUT</a>
        </div>
        <Button variant="outline" className="rounded-none border-primary text-primary hover:bg-primary hover:text-black transition-all duration-300 font-mono text-xs tracking-widest uppercase">
          Pre-Order V1
        </Button>
      </nav>

      {/* Hero Section */}
      <section ref={targetRef} className="relative h-screen flex items-center justify-center overflow-hidden">
        <motion.div style={{ y, opacity }} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
          <div className="absolute inset-0 bg-[url('/images/hero-shoe.jpg')] bg-cover bg-center opacity-60 mix-blend-luminosity" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </motion.div>

        <div className="container relative z-10 flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          >
            <h1 className="text-6xl md:text-9xl font-black uppercase tracking-tighter leading-none mb-4 font-['Monument_Extended']">
              <GlitchText text="Beyond" /> <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                <GlitchText text="Velocity" />
              </span>
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="max-w-md text-muted-foreground font-mono text-sm md:text-base mb-8 tracking-widest"
          >
            ENGINEERED FOR THE POST-HUMAN ERA. <br />
            SPEED IS NO LONGER A LIMIT.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8, duration: 0.5 }}
          >
            <Button className="group relative px-8 py-6 bg-white text-black rounded-none font-bold tracking-wider hover:bg-primary transition-colors duration-300 overflow-hidden">
              <span className="relative z-10 flex items-center gap-2">
                EXPLORE SERIES <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </Button>
          </motion.div>
        </div>

        <motion.div 
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-muted-foreground animate-bounce"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <ChevronDown className="w-6 h-6" />
        </motion.div>
      </section>

      {/* Product Showcase - Horizontal Scroll */}
      <section className="py-32 bg-background relative z-20">
        <div className="container mb-20">
          <div className="flex items-end justify-between border-b border-border pb-4">
            <h2 className="text-4xl md:text-6xl font-bold uppercase font-['Monument_Extended']">
              The <span className="text-primary">Lineup</span>
            </h2>
            <span className="font-mono text-muted-foreground">01 / 03</span>
          </div>
        </div>

        <div className="container grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative group"
          >
            <div className="absolute -inset-4 bg-gradient-to-r from-primary to-secondary opacity-20 blur-2xl group-hover:opacity-40 transition-opacity duration-500" />
            <img 
              src="/images/shoe-side-profile.jpg" 
              alt="Stride V1 Side Profile" 
              className="relative z-10 w-full grayscale group-hover:grayscale-0 transition-all duration-500 scale-100 group-hover:scale-105"
            />
            <div className="absolute top-4 right-4 z-20 font-mono text-xs bg-black/80 px-2 py-1 border border-primary text-primary">
              V1.0 PROTO
            </div>
          </motion.div>

          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              <h3 className="text-3xl font-bold uppercase mb-4 font-['Monument_Extended']">Cyber-Kinetic V1</h3>
              <p className="text-muted-foreground font-mono leading-relaxed mb-6">
                Constructed with a proprietary carbon-graphene matrix. The V1 adapts to your stride pattern in real-time, adjusting sole density for optimal energy return.
              </p>
              
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="border border-border p-4 hover:border-primary transition-colors group">
                  <Zap className="w-6 h-6 text-primary mb-2 group-hover:scale-110 transition-transform" />
                  <h4 className="font-bold uppercase text-sm mb-1">Energy Return</h4>
                  <p className="text-xs text-muted-foreground font-mono">98.5% Efficiency</p>
                </div>
                <div className="border border-border p-4 hover:border-secondary transition-colors group">
                  <Activity className="w-6 h-6 text-secondary mb-2 group-hover:scale-110 transition-transform" />
                  <h4 className="font-bold uppercase text-sm mb-1">Adaptive Fit</h4>
                  <p className="text-xs text-muted-foreground font-mono">Neural Mesh</p>
                </div>
              </div>

              <Button variant="outline" className="w-full md:w-auto rounded-none border-white text-white hover:bg-white hover:text-black transition-all uppercase font-bold tracking-wider">
                View Specifications
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Tech Breakdown - Parallax */}
      <section className="py-32 bg-black relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('/images/shoe-detail-sole.jpg')] bg-fixed bg-cover bg-center opacity-20" />
        
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center mb-24">
            <motion.h2 
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-bold uppercase font-['Monument_Extended'] mb-6"
            >
              Deconstructed <br />
              <span className="text-outline-white text-transparent bg-clip-text bg-gradient-to-b from-white to-transparent opacity-50">Perfection</span>
            </motion.h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Upper", desc: "Hydrophobic Nano-Mesh", icon: Layers },
              { title: "Midsole", desc: "React-Core Foam", icon: Activity },
              { title: "Outsole", desc: "Carbon-Graphene Plate", icon: Zap },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="bg-zinc-900/50 backdrop-blur-sm border border-white/10 p-8 hover:bg-zinc-900/80 hover:border-primary/50 transition-all duration-300 group"
              >
                <item.icon className="w-10 h-10 text-white mb-6 group-hover:text-primary transition-colors" />
                <h3 className="text-xl font-bold uppercase mb-2 font-['Monument_Extended']">{item.title}</h3>
                <p className="text-muted-foreground font-mono text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Floating Parts Section */}
      <section className="py-32 bg-background relative">
        <div className="container flex flex-col md:flex-row items-center gap-16">
          <div className="w-full md:w-1/2">
            <motion.img 
              src="/images/shoe-floating-parts.jpg" 
              alt="Exploded View"
              initial={{ opacity: 0, rotate: -10 }}
              whileInView={{ opacity: 1, rotate: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1, type: "spring" }}
              className="w-full h-auto drop-shadow-[0_0_30px_rgba(204,255,0,0.15)]"
            />
          </div>
          <div className="w-full md:w-1/2 space-y-8">
            <h2 className="text-4xl md:text-6xl font-bold uppercase font-['Monument_Extended'] leading-tight">
              Every Layer <br />
              <span className="text-primary">Calculated</span>
            </h2>
            <p className="text-lg text-muted-foreground font-mono">
              We stripped away everything non-essential. What remains is pure performance architecture. 
              Every gram justifies its existence through speed.
            </p>
            <ul className="space-y-4 font-mono text-sm">
              {["Zero-Gravity Cushioning", "Adaptive Lacing System", "Biometric Feedback Sensors"].map((feature, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.4 + (i * 0.1) }}
                  className="flex items-center gap-4 border-b border-border pb-2"
                >
                  <span className="text-primary">0{i + 1}</span>
                  {feature}
                </motion.li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-20 border-t border-white/10">
        <div className="container flex flex-col md:flex-row justify-between items-start gap-12">
          <div>
            <h2 className="text-3xl font-bold uppercase font-['Monument_Extended'] mb-4">STRIDE.</h2>
            <p className="text-muted-foreground font-mono text-sm max-w-xs">
              The future of footwear is here. <br />
              Don't get left behind.
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-12 font-mono text-sm">
            <div className="flex flex-col gap-4">
              <h4 className="text-white font-bold uppercase">Shop</h4>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">New Arrivals</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Best Sellers</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Accessories</a>
            </div>
            <div className="flex flex-col gap-4">
              <h4 className="text-white font-bold uppercase">Support</h4>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">FAQ</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Shipping</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Returns</a>
            </div>
            <div className="flex flex-col gap-4">
              <h4 className="text-white font-bold uppercase">Social</h4>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Instagram</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Twitter</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Discord</a>
            </div>
          </div>
        </div>
        <div className="container mt-20 pt-8 border-t border-white/5 flex justify-between items-center font-mono text-xs text-muted-foreground">
          <p>© 2024 STRIDE INC. ALL RIGHTS RESERVED.</p>
          <p>DESIGNED BY MANUS</p>
        </div>
      </footer>
    </div>
  );
}
