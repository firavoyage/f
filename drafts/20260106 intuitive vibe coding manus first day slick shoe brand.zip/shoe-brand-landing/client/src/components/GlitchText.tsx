import { motion } from 'framer-motion';
import { useState } from 'react';

interface GlitchTextProps {
  text: string;
  className?: string;
}

export default function GlitchText({ text, className = "" }: GlitchTextProps) {
  const [isHovered, setIsHovered] = useState(false);

  const glitchVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <div 
      className={`relative inline-block group ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.span
        className="relative z-10 block"
        initial="hidden"
        animate="visible"
        variants={glitchVariants}
      >
        {text}
      </motion.span>
      
      {isHovered && (
        <>
          <span className="absolute top-0 left-0 -z-10 w-full h-full text-primary opacity-70 animate-pulse translate-x-[2px] translate-y-[-2px] clip-path-polygon-[0_0,100%_0,100%_45%,0_45%]">
            {text}
          </span>
          <span className="absolute top-0 left-0 -z-10 w-full h-full text-secondary opacity-70 animate-pulse translate-x-[-2px] translate-y-[2px] clip-path-polygon-[0_80%,100%_20%,100%_100%,0_100%]">
            {text}
          </span>
        </>
      )}
    </div>
  );
}
