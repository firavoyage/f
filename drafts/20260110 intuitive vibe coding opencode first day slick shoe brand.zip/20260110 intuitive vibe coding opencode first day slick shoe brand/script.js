// DOM Elements
const navbar = document.querySelector('.navbar');
const navLinks = document.querySelectorAll('.nav-link');
const shoeCards = document.querySelectorAll('.shoe-card');
const quickViewBtns = document.querySelectorAll('.quick-view');
const ctaButtons = document.querySelectorAll('.cta-button, .primary-btn, .secondary-btn, .collection-btn');

// Smooth scrolling for navigation links
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Navbar scroll effect
let lastScrollY = 0;
window.addEventListener('scroll', () => {
    const currentScrollY = window.scrollY;
    
    if (currentScrollY > 100) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        navbar.style.boxShadow = '0 5px 20px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = 'none';
    }
    
    lastScrollY = currentScrollY;
});

// Intersection Observer for fade-in animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, observerOptions);

// Observe elements for animations
document.querySelectorAll('.shoe-card, .collection-text, .about-content').forEach(el => {
    el.classList.add('fade-in');
    observer.observe(el);
});

// Shoe card interactions
shoeCards.forEach((card, index) => {
    // Stagger animation on load
    card.style.animationDelay = `${index * 0.1}s`;
    
    // Click interaction
    card.addEventListener('click', function(e) {
        if (!e.target.classList.contains('quick-view')) {
            // Add ripple effect
            createRipple(e, this);
            
            // Simulate product view
            showProductDetails(this.dataset.shoe);
        }
    });
    
    // Mouse move effect
    card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 10;
        const rotateY = (centerX - x) / 10;
        
        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
    });
    
    card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateZ(0)';
    });
});

// Quick view buttons
quickViewBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        createRipple(e, e.target);
        showQuickView(e.target.closest('.shoe-card'));
    });
});

// Ripple effect for buttons
function createRipple(event, element) {
    const ripple = document.createElement('span');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.style.position = 'absolute';
    ripple.style.borderRadius = '50%';
    ripple.style.background = 'rgba(255, 255, 255, 0.6)';
    ripple.style.transform = 'scale(0)';
    ripple.style.animation = 'ripple 0.6s linear';
    ripple.style.pointerEvents = 'none';
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => ripple.remove(), 600);
}

// Add ripple animation to CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Product detail modal
function showProductDetails(shoeId) {
    const modal = document.createElement('div');
    modal.className = 'product-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="modal-close">&times;</span>
            <div class="modal-body">
                <div class="modal-image">
                    <div class="shoe-placeholder shoe-${shoeId}"></div>
                </div>
                <div class="modal-info">
                    <h2>${getShoeName(shoeId)}</h2>
                    <p class="modal-price">${getShoePrice(shoeId)}</p>
                    <p class="modal-description">Experience ultimate comfort and style with our premium footwear collection.</p>
                    <div class="modal-actions">
                        <button class="modal-btn primary">ADD TO CART</button>
                        <button class="modal-btn secondary">WISHLIST</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal styles
    if (!document.querySelector('#modal-styles')) {
        const modalStyles = document.createElement('style');
        modalStyles.id = 'modal-styles';
        modalStyles.textContent = `
            .product-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                z-index: 2000;
                display: flex;
                align-items: center;
                justify-content: center;
                opacity: 0;
                animation: fadeIn 0.3s forwards;
            }
            
            .modal-content {
                background: white;
                border-radius: 20px;
                max-width: 800px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
                position: relative;
                transform: scale(0.9);
                animation: scaleIn 0.3s 0.1s forwards;
            }
            
            @keyframes scaleIn {
                to { transform: scale(1); }
            }
            
            .modal-close {
                position: absolute;
                top: 20px;
                right: 20px;
                font-size: 2rem;
                cursor: pointer;
                color: #666;
                transition: color 0.3s;
            }
            
            .modal-close:hover {
                color: #ff6b35;
            }
            
            .modal-body {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 2rem;
                padding: 3rem;
            }
            
            .modal-image {
                height: 400px;
                border-radius: 15px;
                overflow: hidden;
            }
            
            .modal-info h2 {
                font-family: 'Bebas Neue', cursive;
                font-size: 2.5rem;
                letter-spacing: 2px;
                margin-bottom: 1rem;
            }
            
            .modal-price {
                font-size: 1.5rem;
                color: #ff6b35;
                font-weight: 600;
                margin-bottom: 1rem;
            }
            
            .modal-description {
                color: #666;
                line-height: 1.6;
                margin-bottom: 2rem;
            }
            
            .modal-actions {
                display: flex;
                gap: 1rem;
            }
            
            .modal-btn {
                padding: 1rem 2rem;
                border: none;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s;
                letter-spacing: 1px;
            }
            
            .modal-btn.primary {
                background: #ff6b35;
                color: white;
            }
            
            .modal-btn.secondary {
                background: transparent;
                color: #333;
                border: 2px solid #333;
            }
            
            .modal-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            }
        `;
        document.head.appendChild(modalStyles);
    }
    
    document.body.appendChild(modal);
    
    // Close modal
    const closeBtn = modal.querySelector('.modal-close');
    closeBtn.addEventListener('click', () => {
        modal.style.animation = 'fadeOut 0.3s forwards';
        setTimeout(() => modal.remove(), 300);
    });
    
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.animation = 'fadeOut 0.3s forwards';
            setTimeout(() => modal.remove(), 300);
        }
    });
}

// Quick view function
function showQuickView(card) {
    const shoeId = card.dataset.shoe;
    showProductDetails(shoeId);
}

// Helper functions
function getShoeName(id) {
    const names = {
        '1': 'AIR MAX PRO',
        '2': 'URBAN RUNNER', 
        '3': 'CLASSIC LUX'
    };
    return names[id] || 'PREMIUM FOOTWEAR';
}

function getShoePrice(id) {
    const prices = {
        '1': '$189.99',
        '2': '$159.99',
        '3': '$249.99'
    };
    return prices[id] || '$199.99';
}

// Button animations
ctaButtons.forEach(btn => {
    btn.addEventListener('mouseenter', (e) => {
        // Add particle effect
        createParticles(e.target);
    });
    
    btn.addEventListener('click', (e) => {
        createRipple(e, e.target);
        
        // Simulate action
        if (btn.textContent.includes('SHOP') || btn.textContent.includes('EXPLORE') || btn.textContent.includes('DISCOVER')) {
            // Scroll to collection
            document.querySelector('#featured').scrollIntoView({ behavior: 'smooth' });
        } else if (btn.textContent.includes('WATCH')) {
            alert('Video coming soon! 🎬');
        }
    });
});

// Particle effect
function createParticles(element) {
    const particles = 5;
    const rect = element.getBoundingClientRect();
    
    for (let i = 0; i < particles; i++) {
        const particle = document.createElement('div');
        particle.style.position = 'fixed';
        particle.style.left = rect.left + rect.width / 2 + 'px';
        particle.style.top = rect.top + rect.height / 2 + 'px';
        particle.style.width = '4px';
        particle.style.height = '4px';
        particle.style.background = '#ff6b35';
        particle.style.borderRadius = '50%';
        particle.style.pointerEvents = 'none';
        particle.style.zIndex = '9999';
        
        const angle = (Math.PI * 2 * i) / particles;
        const velocity = 50 + Math.random() * 50;
        const lifetime = 1000 + Math.random() * 500;
        
        document.body.appendChild(particle);
        
        let startTime = Date.now();
        const animate = () => {
            const elapsed = Date.now() - startTime;
            const progress = elapsed / lifetime;
            
            if (progress < 1) {
                const x = Math.cos(angle) * velocity * progress;
                const y = Math.sin(angle) * velocity * progress + progress * progress * 100;
                const opacity = 1 - progress;
                
                particle.style.transform = `translate(${x}px, ${y}px)`;
                particle.style.opacity = opacity;
                
                requestAnimationFrame(animate);
            } else {
                particle.remove();
            }
        };
        
        requestAnimationFrame(animate);
    }
}

// Color dot selection
document.querySelectorAll('.color-dot').forEach(dot => {
    dot.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // Remove active state from siblings
        const siblings = dot.parentElement.querySelectorAll('.color-dot');
        siblings.forEach(sibling => sibling.style.borderColor = 'transparent');
        
        // Add active state to clicked dot
        dot.style.borderColor = '#ff6b35';
        dot.style.transform = 'scale(1.2)';
        
        // Reset after a moment
        setTimeout(() => {
            dot.style.transform = 'scale(1)';
        }, 200);
    });
});

// Loading animation for images
document.querySelectorAll('.shoe-placeholder').forEach(placeholder => {
    placeholder.classList.add('loading');
    
    // Simulate image loading
    setTimeout(() => {
        placeholder.classList.remove('loading');
    }, Math.random() * 1000 + 500);
});

// Parallax effect for hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    const heroContent = document.querySelector('.hero-content');
    
    if (hero && scrolled < window.innerHeight) {
        hero.style.transform = `translateY(${scrolled * 0.5}px)`;
        heroContent.style.transform = `translateY(${scrolled * 0.3}px)`;
        heroContent.style.opacity = 1 - scrolled / 800;
    }
});

// Stats counter animation
const stats = document.querySelectorAll('.stat-number');
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
            entry.target.classList.add('counted');
            animateCounter(entry.target);
        }
    });
}, { threshold: 0.5 });

stats.forEach(stat => statsObserver.observe(stat));

function animateCounter(element) {
    const target = element.textContent;
    const isPlus = target.includes('+');
    const isK = target.includes('K');
    const number = parseInt(target.replace(/[^\d]/g, ''));
    
    let current = 0;
    const increment = number / 50;
    const timer = setInterval(() => {
        current += increment;
        if (current >= number) {
            current = number;
            clearInterval(timer);
        }
        
        let display = Math.floor(current);
        if (isK) {
            display = (display / 1000).toFixed(0) + 'K';
        }
        if (isPlus && current === number) {
            display += '+';
        }
        
        element.textContent = display;
    }, 30);
}

// Initialize animations on page load
document.addEventListener('DOMContentLoaded', () => {
    // Add entrance animations
    document.querySelectorAll('.shoe-card').forEach((card, index) => {
        card.style.animation = `slideInUp 0.6s ease ${index * 0.1}s forwards`;
    });
    
    // Initialize 3D shoe rotation
    const shoeModel = document.querySelector('.shoe-model');
    if (shoeModel) {
        let rotation = 0;
        setInterval(() => {
            rotation += 1;
            shoeModel.style.transform = `rotateY(${rotation}deg)`;
        }, 50);
    }
});

// Add keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        // Close any open modal
        const modal = document.querySelector('.product-modal');
        if (modal) {
            modal.remove();
        }
    }
});

// Performance optimization - throttle scroll events
let ticking = false;
function updateOnScroll() {
    if (!ticking) {
        requestAnimationFrame(() => {
            // Update scroll-based animations here
            ticking = false;
        });
        ticking = true;
    }
}

window.addEventListener('scroll', updateOnScroll);