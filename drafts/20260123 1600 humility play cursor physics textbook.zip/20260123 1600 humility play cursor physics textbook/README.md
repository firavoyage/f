# High School Physics (Open Textbook)

An editable high school physics textbook written in Markdown.

## How this repo is organized

- `book/` contains the textbook content (Markdown).
- `book/chapters/` contains chapter files.

## Build (optional)

If you want a PDF, you can use Pandoc.

### PDF via Pandoc (example)

1. Install pandoc and a LaTeX engine (e.g. `texlive-full` on Linux).
2. From the repo root, run:

```bash
pandoc book/index.md -o physics.pdf
```

## License

Unless you replace this section, the content is provided under **CC BY 4.0**.

