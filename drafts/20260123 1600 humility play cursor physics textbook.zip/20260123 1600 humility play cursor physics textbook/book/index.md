# High School Physics

**An open, student-friendly textbook** with worked examples, practice problems, and labs.

## How to use this book

- Read the lesson sections and **work the examples by hand**.
- Do the **Check Your Understanding** questions immediately.
- Save the **Mixed Practice** set for review and test prep.
- In labs, prioritize **safety, careful measurement, and clear graphs**.

## Table of Contents

### Front Matter

- [0. Mathematical Tools for Physics](chapters/00-math-tools.md)
- [0. Units, Conversions, and Significant Figures](chapters/00-units-sigfigs.md)
- [0. Measurement, Uncertainty, and Graphing](chapters/00-uncertainty-graphing.md)
- [Constants, Symbols, and Useful Data](chapters/00-constants-data.md)

### Part I — Motion and Forces (Mechanics)

- [1. Physics and Modeling](chapters/01-modeling.md)
- [2. One-Dimensional Kinematics](chapters/02-1d-kinematics.md)
- [3. Two-Dimensional Motion (Vectors, Projectiles)](chapters/03-2d-motion.md)
- [4. Forces and Newton’s Laws](chapters/04-newton-laws.md)
- [5. Applications of Newton’s Laws (Friction, Inclines)](chapters/05-applications-forces.md)
- [6. Work, Energy, and Power](chapters/06-work-energy.md)
- [7. Momentum and Collisions](chapters/07-momentum.md)
- [8. Circular Motion and Gravitation](chapters/08-circular-gravitation.md)

### Part II — Fluids, Thermal Physics, and Waves

- [9. Fluids](chapters/09-fluids.md)
- [10. Thermal Physics](chapters/10-thermal.md)
- [11. Waves and Sound](chapters/11-waves-sound.md)

### Part III — Electricity, Magnetism, and Light

- [12. Electrostatics](chapters/12-electrostatics.md)
- [13. Circuits](chapters/13-circuits.md)
- [14. Magnetism and Electromagnetic Induction](chapters/14-magnetism-induction.md)
- [15. Light and Optics](chapters/15-optics.md)

### Part IV — Modern Physics (Optional / Extension)

- [16. Atomic Physics](chapters/16-atomic.md)
- [17. Nuclear Physics](chapters/17-nuclear.md)
- [18. Special Relativity (Intro)](chapters/18-relativity.md)

### Appendices

- [A. Problem-Solving Strategy](chapters/A-problem-solving.md)
- [B. Graphing and Linear Fits](chapters/B-linear-fits.md)
- [C. Answer Key (Student Edition)](chapters/C-answer-key.md)
- [D. Teacher Materials (restricted / optional)](chapters/D-teacher-materials.md)

