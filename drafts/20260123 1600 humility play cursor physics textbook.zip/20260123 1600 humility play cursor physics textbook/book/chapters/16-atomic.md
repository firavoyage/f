# 16. Atomic Physics

Atomic physics studies the structure and behavior of atoms.

## 16.1 Basic structure

- **Protons** (+) and **neutrons** (0) are in the nucleus.
- **Electrons** (−) occupy regions around the nucleus.

## 16.2 Spectra (idea)

Atoms emit/absorb light at specific wavelengths, producing line spectra.

This supports the idea that atomic energy levels are quantized.

## 16.3 Photoelectric effect (idea)

Light can eject electrons from a metal if frequency is high enough.

Key idea: light energy comes in quanta (photons), \(E=hf\).

## Check Your Understanding

1. What evidence suggests atoms have quantized energy levels?
2. Why does increasing light intensity not always eject electrons in the photoelectric effect?

