# 9. Fluids

Fluids (liquids and gases) can flow and take the shape of their container.

## 9.1 Density

\[
\rho = \frac{m}{V}
\]

Unit: kg/m\(^3\) (or g/cm\(^3\)).

## 9.2 Pressure

Pressure is force per area:

\[
P = \frac{F}{A}
\]

In a fluid at rest, pressure increases with depth:

\[
P = P_0 + \rho g h
\]

## 9.3 Buoyancy (Archimedes’ principle)

The buoyant force equals the weight of displaced fluid:

\[
F_B = \rho_{\text{fluid}} g V_{\text{displaced}}
\]

An object floats when buoyant force equals weight.

## Worked Example: Pressure at depth

Find the pressure 5.0 m below the surface of freshwater (\(\rho = 1000\ \text{kg/m}^3\)), ignoring air pressure changes.

\[
\Delta P = \rho g h = (1000)(9.8)(5.0) = 4.9\times 10^4\ \text{Pa}
\]

## Check Your Understanding

1. Why do dams tend to be thicker near the bottom?
2. A block floats. What can you say about its average density compared to the fluid?
3. Convert \(1.0\ \text{atm}\) to pascals if \(1\ \text{atm} \approx 1.01\times 10^5\ \text{Pa}\).

## Mixed Practice

1. A 0.50 m\(^3\) object has mass 200 kg. Find its density.
2. A person stands on one foot with contact area \(0.020\ \text{m}^2\). If their weight is 600 N, find pressure on the floor.
3. A submerged object displaces \(0.030\ \text{m}^3\) of water. Find the buoyant force.

