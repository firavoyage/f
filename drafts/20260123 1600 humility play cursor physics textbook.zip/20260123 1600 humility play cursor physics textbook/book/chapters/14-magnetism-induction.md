# 14. Magnetism and Electromagnetic Induction

Magnetism involves moving charges and magnetic fields.

## 14.1 Magnetic fields

Magnetic field \(\vec{B}\) is measured in tesla (T).

Magnetic field lines:

- go from N to S outside a magnet
- form closed loops (no magnetic monopoles observed)

## 14.2 Force on a moving charge (idea)

For a charge moving in a magnetic field:

\[
F = qvB\sin\theta
\]

Direction is perpendicular to both \(\vec{v}\) and \(\vec{B}\) (often handled with the right-hand rule).

## 14.3 Electromagnetic induction (idea)

Changing magnetic flux can induce an emf (voltage).

Qualitative statement of Faraday’s law:

- A changing magnetic field through a loop induces a voltage around the loop.

Lenz’s law gives direction: induced effects oppose the change that produced them.

## Worked Example: Straight wire in a magnetic field (magnitude)

A wire of length 0.20 m carries 3.0 A perpendicular to a 0.50 T magnetic field. Find force magnitude.

\[
F = ILB\sin\theta = (3.0)(0.20)(0.50)\sin90^\circ = 0.30\ \text{N}
\]

## Check Your Understanding

1. Can a stationary charge feel a magnetic force? Explain.
2. What must happen to induce a voltage in a loop using a magnet?
3. What does Lenz’s law mean in everyday words?

## Mixed Practice

1. A charge \(q=2.0\times 10^{-6}\ \text{C}\) moves at 400 m/s perpendicular to a 0.20 T field. Find magnetic force magnitude.
2. A 5.0 A current runs through a 0.10 m wire segment at \(30^\circ\) to a 0.40 T field. Find force magnitude.
3. Describe one way to increase induced emf in a coil (qualitatively).

