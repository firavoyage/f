# 4. Forces and Newton’s Laws

Dynamics explains **why** motion changes: forces cause acceleration.

## 4.1 Newton’s Laws (statements)

### Newton’s First Law (inertia)

If the net external force on an object is zero, its velocity stays constant.

### Newton’s Second Law

\[
\sum \vec{F} = m\vec{a}
\]

### Newton’s Third Law

For every interaction, forces come in pairs: if A pushes on B, then B pushes on A with equal magnitude and opposite direction.

Important: action–reaction forces act on **different objects**.

## 4.2 Free-body diagrams (FBDs)

Steps:

1. Choose the object (system).
2. Draw the object as a dot/box.
3. Draw all external forces as arrows from the object.
4. Label forces (and directions).
5. Choose axes and write component equations.

## 4.3 Common forces

- **Weight**: \(\vec{W} = m\vec{g}\) (downward)
- **Normal force**: \(\vec{N}\) (perpendicular to surface)
- **Tension**: \(\vec{T}\) (along a rope/string)
- **Friction**: opposes relative motion (see next chapter)

## 4.4 Equilibrium and constant velocity

Equilibrium means:

\[
\sum \vec{F} = 0 \Rightarrow \vec{a} = 0
\]

An object can be at rest **or** moving at constant velocity and still be in equilibrium.

## Worked Example 1: Hanging mass (equilibrium)

A 2.0 kg mass hangs at rest from a rope. Find the tension.

Forces: tension up, weight down. Net force is zero:

\[
T - mg = 0 \Rightarrow T = mg = (2.0)(9.8) = 19.6\ \text{N}
\]

## Worked Example 2: Horizontal push

A 5.0 kg box on a frictionless floor is pushed with 12 N horizontally. Find the acceleration.

\[
\sum F_x = ma_x \Rightarrow a = \frac{12}{5.0} = 2.4\ \text{m/s}^2
\]

## Common mistakes

- Putting both action–reaction forces on the same FBD.
- Forgetting that \(N\) is not always equal to \(mg\) (e.g., on an incline or when accelerating).
- Confusing mass (kg) with weight (N).

## Check Your Understanding

1. State Newton’s three laws in your own words.
2. A student stands on a scale in an elevator. What does the scale measure?
3. Identify the Newton’s third-law pair for “Earth pulls on you by gravity.”

## Mixed Practice

1. A 1200 kg car accelerates at \(2.0\ \text{m/s}^2\). What net force acts on it?
2. Two students pull on a rope in opposite directions with 200 N and 250 N. What is the tension at each end? (Assume a light rope and static pulls.)
3. A 0.50 kg cart experiences a net force of 0.80 N. Find its acceleration.

