# Constants, Symbols, and Useful Data

Use this page as a reference. Your teacher may provide a different “equation sheet”; always follow course expectations.

## Common constants (SI units)

- **Gravitational acceleration near Earth**: \(g \approx 9.80\ \text{m/s}^2\)
- **Speed of light**: \(c \approx 3.00 \times 10^8\ \text{m/s}\)
- **Elementary charge**: \(e \approx 1.60 \times 10^{-19}\ \text{C}\)
- **Coulomb’s constant**: \(k \approx 8.99 \times 10^9\ \text{N}\cdot\text{m}^2/\text{C}^2\)
- **Gravitational constant**: \(G \approx 6.67 \times 10^{-11}\ \text{N}\cdot\text{m}^2/\text{kg}^2\)

## Metric prefixes (selected)

- pico (p): \(10^{-12}\)
- nano (n): \(10^{-9}\)
- micro (\(\mu\)): \(10^{-6}\)
- milli (m): \(10^{-3}\)
- centi (c): \(10^{-2}\)
- kilo (k): \(10^{3}\)
- mega (M): \(10^{6}\)
- giga (G): \(10^{9}\)

## Common symbols (typical meanings)

These can vary by course and context.

- \(x\): position (m)
- \(\Delta x\): displacement (m)
- \(t\): time (s)
- \(v\): velocity (m/s)
- \(a\): acceleration (m/s\(^2\))
- \(F\): force (N)
- \(m\): mass (kg)
- \(W\): work (J)
- \(E\): energy (J)
- \(P\): power (W)
- \(p\): momentum (kg·m/s)
- \(q\): charge (C)
- \(V\): electric potential (V)
- \(I\): current (A)
- \(R\): resistance (Ω)

