# 17. Nuclear Physics

Nuclear physics studies the nucleus, radioactivity, and nuclear energy.

## 17.1 Isotopes

Isotopes are atoms of the same element with different numbers of neutrons.

## 17.2 Radioactive decay (idea)

Common decay types:

- **Alpha (\(\alpha\))**: helium nucleus emitted.
- **Beta (\(\beta\))**: electron or positron emitted.
- **Gamma (\(\gamma\))**: high-energy photon emitted.

## 17.3 Half-life

Half-life is the time for half of a radioactive sample to decay.

## Check Your Understanding

1. What is an isotope?
2. What does half-life mean?

