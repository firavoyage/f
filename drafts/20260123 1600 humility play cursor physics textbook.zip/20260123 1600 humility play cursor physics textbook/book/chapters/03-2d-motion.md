# 3. Two-Dimensional Motion (Vectors, Projectiles)

Many real motions occur in 2D. The key idea: **analyze x and y components separately**.

## 3.1 Vector components

For a vector of magnitude \(A\) at angle \(\theta\) above +x:

\[
A_x = A\cos\theta,\quad A_y = A\sin\theta
\]

## 3.2 Relative velocity (idea)

Velocity depends on the reference frame.

Example: If you walk at 1.5 m/s on a train moving 10 m/s, your ground speed could be 11.5 m/s forward or 8.5 m/s if walking backward.

## 3.3 Projectile motion (no air resistance)

Assumptions:

- Only acceleration is gravity.
- Horizontal acceleration \(a_x = 0\).
- Vertical acceleration \(a_y = -g\) (if up is positive).

Key results:

- \(v_x\) is constant.
- \(v_y\) changes linearly with time.
- The path is a parabola.

## 3.4 Solving projectile problems (recipe)

1. Choose axes (often +x forward, +y up).
2. Split initial velocity into components.
3. Use 1D kinematics in x and y separately.
4. Connect with the common time \(t\).

## Worked Example: Range on level ground

A ball is launched at \(v_0=20\ \text{m/s}\) at \(35^\circ\) above horizontal from level ground. Find time of flight and range (ignore air resistance).

Components:

\[
v_{0x} = 20\cos35^\circ = 16.4\ \text{m/s}
\]
\[
v_{0y} = 20\sin35^\circ = 11.5\ \text{m/s}
\]

Time of flight for level launch/landing:

\[
t = \frac{2v_{0y}}{g} = \frac{2(11.5)}{9.8} \approx 2.35\ \text{s}
\]

Range:

\[
R = v_{0x} t \approx (16.4)(2.35) \approx 38.5\ \text{m}
\]

## Check Your Understanding

1. A vector has magnitude 50 N at \(30^\circ\) above +x. Find \(F_x\) and \(F_y\).
2. A projectile is launched horizontally from a cliff. Which component of velocity changes? Which stays constant?
3. Why can you solve x-motion and y-motion separately in projectile motion?

## Mixed Practice

1. A soccer ball is kicked at 22 m/s at \(40^\circ\). Find its time of flight and range on level ground (ignore air resistance).
2. A rock is thrown horizontally at 12 m/s from a 20 m high cliff. How long until it hits the ground, and how far does it travel horizontally?
3. A projectile has \(v_{0x}=15\ \text{m/s}\) and \(v_{0y}=10\ \text{m/s}\). Find its maximum height and time to peak.

