# 5. Applications of Newton’s Laws (Friction, Inclines)

Many “real” force problems involve friction and tilted surfaces. The physics stays the same: draw a good free-body diagram and apply \(\sum \vec{F} = m\vec{a}\).

## 5.1 Friction

Friction is a contact force that opposes relative motion (or the tendency to move) between surfaces.

### Static friction

Static friction adjusts up to a maximum value:

\[
f_s \le \mu_s N
\]

### Kinetic friction

Kinetic (sliding) friction has magnitude:

\[
f_k = \mu_k N
\]

Static friction is usually larger than kinetic friction for the same surfaces: \(\mu_s > \mu_k\).

## 5.2 Inclines

Choose axes parallel/perpendicular to the surface.

For a mass \(m\) on an incline at angle \(\theta\):

- Perpendicular component of weight: \(mg\cos\theta\)
- Parallel component of weight (down the incline): \(mg\sin\theta\)

If there is no acceleration perpendicular to the surface, then:

\[
N = mg\cos\theta
\]

## Worked Example 1: Sliding with friction

A 10 kg crate slides on a level floor. The coefficient of kinetic friction is \(\mu_k=0.20\). Find the friction force magnitude and acceleration if no other horizontal forces act.

Normal force: \(N=mg=(10)(9.8)=98\ \text{N}\).

Friction: \(f_k=\mu_k N = (0.20)(98)=19.6\ \text{N}\).

Net force is opposite motion, so:

\[
a = \frac{F_{\text{net}}}{m} = \frac{-19.6}{10} = -1.96\ \text{m/s}^2
\]

## Worked Example 2: Block on an incline (no friction)

A 2.0 kg block slides down a \(30^\circ\) frictionless incline. Find its acceleration.

Along the incline:

\[
\sum F_{\parallel} = mg\sin\theta = ma
\Rightarrow a = g\sin\theta = 9.8\sin30^\circ = 4.9\ \text{m/s}^2
\]

## Check Your Understanding

1. Explain the difference between static and kinetic friction.
2. A 5 kg block rests on a \(20^\circ\) incline and does not move. What force prevents it from sliding?
3. For a block on a frictionless incline, why does the mass cancel out when solving for acceleration?

## Mixed Practice

1. A 15 kg sled is pulled on level ground with a 60 N horizontal force. If \(\mu_k = 0.10\), find the acceleration.
2. A 3.0 kg block is pushed up a \(25^\circ\) incline with a force of 20 N parallel to the incline. If \(\mu_k=0.15\), find the acceleration direction and magnitude.
3. A 1.5 kg block sits on a level table. What is the maximum horizontal force that can be applied without moving it if \(\mu_s=0.40\)?

