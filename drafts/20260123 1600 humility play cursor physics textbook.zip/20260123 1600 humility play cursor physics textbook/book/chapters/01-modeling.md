# 1. Physics and Modeling

Physics is the study of patterns in nature using **models**. A model is a simplified description of a situation that is good enough to predict and explain.

## 1.1 What makes physics “physics”?

- **Observation**: what happens?
- **Quantification**: how much, how fast, how strong?
- **Modeling**: what simple rules describe it?
- **Prediction**: what should happen next?
- **Testing**: does the prediction match data?

## 1.2 The modeling cycle

1. **Define the system**: what objects are included?
2. **Choose assumptions**: ignore air resistance? treat an object as a point?
3. **Represent**: diagrams, graphs, equations.
4. **Solve**: compute unknowns.
5. **Evaluate**: units, reasonableness, compare with data.

## 1.3 Systems and interactions

A **system** is the object(s) you are focusing on.

Examples:

- A rolling cart (system) and the track (environment).
- A falling ball (system) and Earth (environment).

Interactions often come as forces (contact forces, gravity, friction) or energy transfers.

## 1.4 Representations you’ll use all year

- **Sketch**: a quick picture with labels.
- **Motion diagram**: positions at equal time steps.
- **Free-body diagram**: forces on an object.
- **Graph**: how a quantity changes.
- **Equation**: compact relationship between variables.

## Worked Example: Sanity-checking a claim

Claim: “A car accelerates from 0 to 30 m/s in 2 seconds.”

Compute acceleration:

\[
a = \frac{\Delta v}{\Delta t} = \frac{30\ \text{m/s}}{2\ \text{s}} = 15\ \text{m/s}^2
\]

Compare to \(g \approx 9.8\ \text{m/s}^2\). That’s about \(1.5g\), which is very high for a typical car. The claim might be false, or it might describe a race car.

## Check Your Understanding

1. Define “model” in your own words and give one example from everyday life.
2. Why do physicists sometimes ignore air resistance?
3. For a thrown ball, what could be the system? What could be the environment?

## Mixed Practice

1. A student says, “My measurement is 2.3, but I’m not sure of the unit.” Explain why the unit is essential.
2. Describe one assumption that makes a physics problem easier, and one risk of that assumption.

