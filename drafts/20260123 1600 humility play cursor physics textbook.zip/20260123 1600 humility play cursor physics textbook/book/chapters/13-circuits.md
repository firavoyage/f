# 13. Circuits

Circuits describe the flow of electric charge through components like batteries and resistors.

## 13.1 Current, voltage, resistance

- **Current**: \(I = \frac{\Delta q}{\Delta t}\) (A)
- **Voltage**: electric potential difference \(V\) (V)
- **Resistance**: opposition to current \(R\) (Ω)

## 13.2 Ohm’s law (ideal resistor)

\[
V = IR
\]

## 13.3 Series and parallel (resistors)

### Series

- Same current through each.
- Equivalent resistance:

\[
R_{\text{eq}} = R_1 + R_2 + \cdots
\]

### Parallel

- Same voltage across each branch.
- Equivalent resistance:

\[
\frac{1}{R_{\text{eq}}} = \frac{1}{R_1} + \frac{1}{R_2} + \cdots
\]

## 13.4 Electric power

\[
P = IV
\]

Using Ohm’s law:

\[
P = I^2R = \frac{V^2}{R}
\]

## Worked Example: Two resistors in series

A 12 V battery is connected to two resistors in series: 4 Ω and 8 Ω. Find current and power dissipated in the 8 Ω resistor.

\[
R_{\text{eq}} = 4 + 8 = 12\ \Omega
\]

\[
I = \frac{V}{R_{\text{eq}}} = \frac{12}{12} = 1.0\ \text{A}
\]

Voltage across 8 Ω:

\[
V_8 = IR = (1.0)(8) = 8\ \text{V}
\]

Power in 8 Ω:

\[
P_8 = IV_8 = (1.0)(8) = 8\ \text{W}
\]

## Check Your Understanding

1. In a series circuit, which is the same for each resistor: current or voltage?
2. In a parallel circuit, which is the same for each branch: current or voltage?
3. A device uses 60 W on a 120 V outlet. What current does it draw?

## Mixed Practice

1. A 9 V battery is connected to a 3 Ω resistor. Find current and power.
2. Two resistors 6 Ω and 12 Ω are in parallel across 12 V. Find equivalent resistance and total current.
3. A 5 Ω and 10 Ω resistor are in series with a 15 V supply. Find current and voltage across each resistor.

