# 10. Thermal Physics

Thermal physics connects temperature, energy, and heat transfer.

## 10.1 Temperature vs thermal energy

- **Temperature** measures the average kinetic energy per particle.
- **Thermal energy** depends on temperature and how much matter you have.

## 10.2 Heat and specific heat

Heat \(Q\) is energy transferred due to temperature difference.

For a temperature change (no phase change):

\[
Q = mc\Delta T
\]

- \(m\): mass
- \(c\): specific heat capacity
- \(\Delta T\): temperature change

## 10.3 Phase change (latent heat)

During melting/boiling, temperature can stay constant while energy transfers:

\[
Q = mL
\]

## 10.4 Heat transfer mechanisms

- **Conduction**: particle-to-particle contact (common in solids).
- **Convection**: bulk fluid motion (liquids/gases).
- **Radiation**: electromagnetic waves (no medium needed).

## Worked Example: Heating water

How much energy is needed to raise 0.50 kg of water from \(20^\circ\text{C}\) to \(80^\circ\text{C}\)? Use \(c = 4180\ \text{J/(kg·}^\circ\text{C)}\).

\[
Q = mc\Delta T = (0.50)(4180)(60) \approx 1.25\times 10^5\ \text{J}
\]

## Check Your Understanding

1. What’s the difference between heat and temperature?
2. Why does metal feel colder than wood at the same room temperature?
3. Which heat transfer mechanism dominates the warming of Earth by the Sun?

## Mixed Practice

1. How much heat is needed to warm 2.0 kg of aluminum by \(15^\circ\text{C}\) if \(c=900\ \text{J/(kg·}^\circ\text{C)}\)?
2. A 0.20 kg sample absorbs \(6.0\times 10^4\) J during melting. If it is melting at constant temperature, find latent heat \(L\).
3. Explain why convection currents form in a heated pot of water.

