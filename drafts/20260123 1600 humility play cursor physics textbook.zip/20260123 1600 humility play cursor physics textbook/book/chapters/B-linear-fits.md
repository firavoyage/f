# B. Graphing and Linear Fits

Many physics relationships look linear after the right graphing choice.

## B.1 Linearizing a relationship (idea)

If a relationship is \(y \propto x^2\), then a plot of \(y\) vs \(x^2\) can be a straight line.

## B.2 Slope meaning

If \(y = mx + b\), then:

- \(m\) is the physical constant/combination represented by the slope.
- \(b\) represents an offset or initial value.

## B.3 Best-fit lines

Draw (or compute) a line that follows the overall trend, not every point. Random scatter is expected.

