# 0. Measurement, Uncertainty, and Graphing

Physics is built on measurement. A good result is not just a number, but a number with a **unit** and a reasonable **uncertainty**.

## 0.1 Accuracy vs precision

- **Accuracy**: closeness to the true value.
- **Precision**: repeatability (measurements cluster tightly).

You can be precise but inaccurate if there is a systematic error.

## 0.2 Uncertainty (simple approach)

For many classroom tools:

- A meterstick with 1 mm markings: uncertainty \(\pm 1\ \text{mm}\) (or sometimes \(\pm 0.5\ \text{mm}\), depending on convention).
- A digital timer reading 0.01 s: uncertainty often \(\pm 0.01\ \text{s}\), plus human reaction time if started by hand.

Write results like:

\[
L = (0.532 \pm 0.001)\ \text{m}
\]

## 0.3 Percent error (when a reference value exists)

\[
\%\ \text{error} = \left|\frac{\text{measured} - \text{accepted}}{\text{accepted}}\right| \times 100\%
\]

## 0.4 Graphing for physics

A good physics graph:

- **Title**: what is being tested.
- **Axes labeled with quantities and units** (e.g., \(t\) (s), \(x\) (m)).
- **Reasonable scale**: uses most of the grid.
- **Best-fit line/curve**: not connect-the-dots unless instructed.

### Slope has meaning

If you graph \(x\) vs \(t\), slope is velocity:

\[
\text{slope} = \frac{\Delta x}{\Delta t} = v
\]

### Area has meaning (later)

Area under a \(v\) vs \(t\) graph is displacement.

## Check Your Understanding

1. Explain the difference between accuracy and precision with a real-world example.
2. A student measures the same length five times and gets 12.1 cm, 12.1 cm, 12.2 cm, 12.1 cm, 12.2 cm. Is this precise? Accurate?
3. A graph of velocity vs time is a straight line with slope \(2.0\ \text{m/s}^2\). What does the slope represent?

