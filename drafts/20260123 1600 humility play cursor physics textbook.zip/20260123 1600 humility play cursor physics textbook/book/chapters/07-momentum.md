# 7. Momentum and Collisions

Momentum connects force and motion, and it is especially useful for collisions and explosions.

## 7.1 Momentum and impulse

Momentum:

\[
\vec{p} = m\vec{v}
\]

Impulse (force applied over time) changes momentum:

\[
\vec{J} = \Delta \vec{p} = \vec{F}_{\text{avg}}\Delta t
\]

## 7.2 Conservation of momentum

For a system with no net external impulse:

\[
\vec{p}_i = \vec{p}_f
\]

Momentum is a vector; directions/signs matter.

## 7.3 Types of collisions

- **Elastic**: kinetic energy is conserved (rare in everyday macroscopic collisions).
- **Inelastic**: kinetic energy is not conserved.
- **Perfectly inelastic**: objects stick together (maximum kinetic energy loss consistent with momentum conservation).

## Worked Example 1: Perfectly inelastic collision

A 0.20 kg cart moving at 3.0 m/s hits and sticks to a 0.30 kg cart at rest. Find their final speed.

Momentum conservation:

\[
m_1 v_1 + m_2 v_2 = (m_1+m_2)v_f
\]

\[
(0.20)(3.0) + (0.30)(0) = (0.50)v_f
\Rightarrow v_f = 1.2\ \text{m/s}
\]

## Worked Example 2: Impulse

A 0.15 kg baseball changes velocity from 30 m/s toward a bat to 40 m/s away from the bat. If this takes 0.005 s, find the average force.

Choose away-from-bat as positive. Then \(v_i=-30\), \(v_f=+40\):

\[
\Delta p = m(v_f-v_i) = 0.15(40 - (-30)) = 10.5\ \text{kg·m/s}
\]

\[
F_{\text{avg}} = \frac{\Delta p}{\Delta t} = \frac{10.5}{0.005} = 2100\ \text{N}
\]

## Check Your Understanding

1. What is momentum? How is it different from kinetic energy?
2. Why does a longer collision time usually mean a smaller average force (for the same momentum change)?
3. In a collision, is momentum always conserved? Is kinetic energy always conserved?

## Mixed Practice

1. A 1000 kg car moving at 12 m/s rear-ends a 900 kg car moving at 8 m/s. If they stick together, find the final speed.
2. A 0.050 kg hockey puck is hit from rest to 20 m/s in 0.010 s. Find the average force.
3. A 2.0 kg object experiences a constant 6.0 N force for 4.0 s. If it starts from rest, what is its final momentum?

