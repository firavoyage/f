# 11. Waves and Sound

Waves transfer energy and information without transporting matter overall.

## 11.1 Wave vocabulary

- **Amplitude \(A\)**: maximum displacement (related to energy).
- **Wavelength \(\lambda\)**: distance between repeating points.
- **Period \(T\)**: time for one cycle.
- **Frequency \(f\)**: cycles per second (Hz), \(f=\frac{1}{T}\).
- **Wave speed \(v\)**:

\[
v = f\lambda
\]

## 11.2 Transverse vs longitudinal waves

- **Transverse**: oscillation is perpendicular to travel (rope waves, light).
- **Longitudinal**: oscillation is parallel to travel (sound in air).

## 11.3 Sound basics

Sound is a longitudinal wave that needs a medium.

- Higher **frequency** → higher pitch.
- Larger **amplitude** → louder sound (generally).

## 11.4 Interference (idea)

When waves overlap, displacements add (superposition).

- **Constructive interference**: amplitudes reinforce.
- **Destructive interference**: amplitudes reduce/cancel.

## Worked Example: Wave speed

A wave has frequency 5.0 Hz and wavelength 2.4 m. Find its speed.

\[
v = f\lambda = (5.0)(2.4) = 12\ \text{m/s}
\]

## Check Your Understanding

1. If frequency doubles while wave speed stays constant, what happens to wavelength?
2. Why can’t you hear sound in space?
3. What is superposition?

## Mixed Practice

1. A sound wave in air has wavelength 0.85 m and frequency 400 Hz. Find its speed.
2. A wave travels at 3.0 m/s with wavelength 0.50 m. Find frequency and period.
3. Explain the difference between transverse and longitudinal waves with one example each.

