# 0. Units, Conversions, and Significant Figures

## 0.1 SI base units (quick list)

- **Length**: meter (m)
- **Mass**: kilogram (kg)
- **Time**: second (s)
- **Electric current**: ampere (A)
- **Temperature**: kelvin (K)
- **Amount of substance**: mole (mol)
- **Luminous intensity**: candela (cd)

Many useful units are derived, e.g. \(1\ \text{N} = 1\ \text{kg}\cdot\text{m}/\text{s}^2\).

## 0.2 Unit conversions (factor-label method)

Strategy: multiply by conversion factors equal to 1.

Example: convert \(72\ \text{km/h}\) to m/s.

\[
72\ \frac{\text{km}}{\text{h}}
\times \frac{1000\ \text{m}}{1\ \text{km}}
\times \frac{1\ \text{h}}{3600\ \text{s}}
= 20\ \text{m/s}
\]

## 0.3 Dimensional analysis (sanity checks)

If an equation is correct, units match on both sides.

Example:

- \(x = vt\) has units \( \text{m} = (\text{m/s})(\text{s})\), which works.

Dimensional checks catch many algebra mistakes.

## 0.4 Significant figures (sig figs)

Measurements have limited precision, so answers should reflect that precision.

### Counting sig figs (basic rules)

- Non-zero digits are significant: 347 has 3.
- Zeros between non-zero digits are significant: 1005 has 4.
- Leading zeros are not significant: 0.0042 has 2.
- Trailing zeros after a decimal are significant: 2.30 has 3.

### Rounding in calculations

- **Multiply/divide**: answer has the **same number of sig figs** as the factor with the fewest sig figs.
- **Add/subtract**: answer has the **same decimal place** as the least precise term.

## Check Your Understanding

1. Convert \(3.5\ \text{cm}\) to meters.
2. Convert \(15\ \text{m/s}\) to km/h.
3. Evaluate \( (2.4)(3.12) \) and round to correct sig figs.
4. Evaluate \(12.3 + 4.56\) and round correctly.

