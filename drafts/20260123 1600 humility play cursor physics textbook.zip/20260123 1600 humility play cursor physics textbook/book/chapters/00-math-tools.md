# 0. Mathematical Tools for Physics

Physics uses simple math ideas over and over: **algebra**, **graphs**, **trig**, and **vectors**. This chapter is a quick reference.

## 0.1 Powers of ten and scientific notation

Scientific notation writes numbers as:

\[
a \times 10^n \quad \text{where } 1 \le a < 10 \text{ and } n \text{ is an integer.}
\]

Examples:

- \(3{,}600 = 3.6 \times 10^3\)
- \(0.0042 = 4.2 \times 10^{-3}\)

## 0.2 Rearranging formulas

Goal: isolate the unknown and keep the equation balanced.

Example:

Given \(v = v_0 + at\), solve for \(t\):

\[
t = \frac{v - v_0}{a}
\]

## 0.3 Graphing basics (slope and intercept)

For a straight line:

\[
y = mx + b
\]

- **Slope \(m\)**: how much \(y\) changes per change in \(x\).
- **Intercept \(b\)**: value of \(y\) when \(x=0\).

Units matter: if \(y\) is in meters and \(x\) in seconds, slope has units m/s.

## 0.4 Trigonometry for physics

Right triangle with hypotenuse \(r\):

- \(\sin\theta = \frac{\text{opposite}}{\text{hypotenuse}}\)
- \(\cos\theta = \frac{\text{adjacent}}{\text{hypotenuse}}\)
- \(\tan\theta = \frac{\text{opposite}}{\text{adjacent}}\)

Common moves:

- Resolve a vector: \(A_x = A\cos\theta\), \(A_y = A\sin\theta\) (if \(\theta\) is measured from the +x axis).

## 0.5 Vectors (magnitude + direction)

A vector has **magnitude** (size) and **direction**.

Examples: displacement, velocity, acceleration, force.

A scalar has only magnitude: time, mass, temperature, energy.

### Components

If \(\vec{A} = \langle A_x, A_y \rangle\), then:

\[
|\vec{A}| = \sqrt{A_x^2 + A_y^2}
\]

Direction (angle from +x):

\[
\theta = \tan^{-1}\left(\frac{A_y}{A_x}\right)
\]

### Tip: signs carry meaning

Negative components often mean “left” or “down” depending on your chosen axes. Always draw a quick sketch.

## Check Your Understanding

1. Write \(72{,}000\) in scientific notation.
2. A line goes through \((0, 2)\) and \((4, 10)\). Find its slope and write the equation.
3. A vector has components \(A_x=3\) and \(A_y=4\). Find its magnitude.

