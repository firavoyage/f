# 15. Light and Optics

Light behaves like a wave in many situations and like a particle (photon) in others. Here we focus on ray optics.

## 15.1 Reflection

Law of reflection:

\[
\theta_i = \theta_r
\]

Angles are measured from the normal (a line perpendicular to the surface).

## 15.2 Refraction (Snell’s law)

When light changes medium, its speed and direction can change.

\[
n_1\sin\theta_1 = n_2\sin\theta_2
\]

If \(n_2 > n_1\), light bends toward the normal.

## 15.3 Lenses (thin lens equation)

\[
\frac{1}{f} = \frac{1}{d_o} + \frac{1}{d_i}
\]

Magnification:

\[
m = \frac{h_i}{h_o} = -\frac{d_i}{d_o}
\]

## Worked Example: Thin lens

A converging lens has focal length 10 cm. An object is placed 30 cm from the lens. Find image distance.

\[
\frac{1}{d_i} = \frac{1}{f} - \frac{1}{d_o} = \frac{1}{10} - \frac{1}{30} = \frac{2}{30} = \frac{1}{15}
\Rightarrow d_i = 15\ \text{cm}
\]

## Check Your Understanding

1. Why are angles in reflection/refraction measured from the normal?
2. What happens to a light ray entering a medium with higher refractive index?
3. In the lens equation, what sign indicates a real vs virtual image? (Depends on sign convention—state the convention you are using.)

## Mixed Practice

1. Light goes from air (\(n\approx 1.00\)) into glass (\(n=1.50\)) at \(30^\circ\) from the normal. Find the refracted angle.
2. A lens with \(f=20\ \text{cm}\) has an object at \(d_o=60\ \text{cm}\). Find \(d_i\) and magnification.
3. Explain total internal reflection qualitatively.

