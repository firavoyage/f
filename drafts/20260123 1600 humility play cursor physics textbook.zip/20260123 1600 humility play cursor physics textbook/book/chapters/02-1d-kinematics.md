# 2. One-Dimensional Kinematics

Kinematics describes motion using position, velocity, and acceleration—**without** asking what causes the motion.

## 2.1 Position and displacement

- **Position \(x\)**: location along a line (m).
- **Displacement \(\Delta x\)**: change in position:

\[
\Delta x = x_f - x_i
\]

Displacement can be negative; it depends on your coordinate choice.

## 2.2 Velocity

Average velocity:

\[
v_{\text{avg}} = \frac{\Delta x}{\Delta t}
\]

Instantaneous velocity is the slope of the position-time graph.

## 2.3 Acceleration

Average acceleration:

\[
a_{\text{avg}} = \frac{\Delta v}{\Delta t}
\]

Acceleration is the slope of the velocity-time graph.

## 2.4 Motion graphs

### Position vs time (\(x\) vs \(t\))

- Slope = velocity.
- Curvature indicates changing velocity.

### Velocity vs time (\(v\) vs \(t\))

- Slope = acceleration.
- Area under the curve = displacement.

## 2.5 Constant-acceleration equations

These apply when acceleration is constant (common in many problems).

\[
v = v_0 + at
\]
\[
x = x_0 + v_0 t + \frac{1}{2}at^2
\]
\[
v^2 = v_0^2 + 2a(x - x_0)
\]
\[
\Delta x = \left(\frac{v+v_0}{2}\right)t
\]

## Worked Example 1: Braking distance

A car traveling \(25\ \text{m/s}\) brakes with constant acceleration \(-5.0\ \text{m/s}^2\). How far does it travel before stopping?

Given: \(v_0=25\ \text{m/s}\), \(v=0\), \(a=-5.0\ \text{m/s}^2\).

Use \(v^2 = v_0^2 + 2a\Delta x\):

\[
0 = (25)^2 + 2(-5.0)\Delta x
\Rightarrow \Delta x = \frac{625}{10} = 62.5\ \text{m}
\]

## Worked Example 2: Free fall (no air resistance)

A ball is dropped from rest. How fast is it moving after \(1.5\ \text{s}\)?

Given \(v_0=0\), \(a=g=9.80\ \text{m/s}^2\), \(t=1.5\ \text{s}\):

\[
v = v_0 + at = 0 + (9.80)(1.5) = 14.7\ \text{m/s}
\]

Direction: downward (depending on your sign convention).

## Common mistakes

- Mixing up **speed** (scalar) and **velocity** (vector/sign).
- Using constant-acceleration equations when acceleration is not constant.
- Forgetting that \(\Delta x\) can be negative.
- Plugging in \(g=9.8\) without thinking about sign.

## Check Your Understanding

1. A runner goes from \(x=10\ \text{m}\) to \(x=4\ \text{m}\) in 3 s. Find displacement and average velocity.
2. A car’s velocity increases from 5 m/s to 17 m/s in 4 s. Find average acceleration.
3. Sketch a \(v\) vs \(t\) graph for an object moving with constant negative acceleration.

## Mixed Practice

1. A train starts from rest and accelerates at \(0.60\ \text{m/s}^2\) for 20 s. Find its final velocity and displacement.
2. A rock is thrown straight up at \(18\ \text{m/s}\). How long until it reaches the top? (Ignore air resistance.)
3. A cyclist slows from 12 m/s to 4 m/s over 30 m. Find the acceleration.
4. Challenge: A car travels 200 m in 10 s with constant acceleration. If its initial speed is 10 m/s, find its acceleration.

