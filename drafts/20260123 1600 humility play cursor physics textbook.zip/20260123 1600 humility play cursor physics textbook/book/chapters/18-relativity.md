# 18. Special Relativity (Intro)

Special relativity applies when objects move near the speed of light.

## 18.1 Postulates (ideas)

1. The laws of physics are the same in all inertial frames.
2. The speed of light in vacuum is the same for all inertial observers.

## 18.2 Consequences (qualitative)

- Time dilation (moving clocks run slow).
- Length contraction (moving objects shorten along direction of motion).
- Relativity of simultaneity (agreement on “same time” depends on frame).

## Check Your Understanding

1. Why don’t you notice relativity in everyday life?
2. What does it mean to say the speed of light is the same for all observers?

