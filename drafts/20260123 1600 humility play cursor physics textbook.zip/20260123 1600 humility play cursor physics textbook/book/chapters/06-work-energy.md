# 6. Work, Energy, and Power

Energy methods can simplify problems, especially when forces are complicated but energy transfers are clear.

## 6.1 Work

Work is energy transferred by a force acting through a displacement.

For a constant force parallel to displacement:

\[
W = Fd
\]

In general (constant force at angle \(\theta\)):

\[
W = Fd\cos\theta
\]

Unit: joule (J), where \(1\ \text{J} = 1\ \text{N}\cdot\text{m}\).

## 6.2 Kinetic energy

\[
K = \frac{1}{2}mv^2
\]

## 6.3 Gravitational potential energy (near Earth)

Change in gravitational potential energy:

\[
\Delta U_g = mg\Delta y
\]

## 6.4 Conservation of mechanical energy (basic form)

If only conservative forces (like gravity and ideal springs) do work:

\[
K_i + U_i = K_f + U_f
\]

With nonconservative work (like friction):

\[
K_i + U_i + W_{\text{nc}} = K_f + U_f
\]

## 6.5 Power

Power is the rate of doing work:

\[
P = \frac{W}{t}
\]

Unit: watt (W), where \(1\ \text{W} = 1\ \text{J/s}\).

## Worked Example 1: Ramp and speed

A 1.0 kg cart starts from rest and rolls down a frictionless ramp, dropping 0.80 m in height. Find its speed at the bottom.

Energy conservation:

\[
mgh = \frac{1}{2}mv^2 \Rightarrow v = \sqrt{2gh} = \sqrt{2(9.8)(0.80)} \approx 4.0\ \text{m/s}
\]

## Worked Example 2: Work by friction

A 2.0 kg block slides 3.0 m on a level surface. Kinetic friction is 4.0 N. Find the work done by friction.

Friction opposes motion, so \(\theta=180^\circ\):

\[
W_f = Fd\cos180^\circ = (4.0)(3.0)(-1) = -12\ \text{J}
\]

Negative work means mechanical energy decreased.

## Check Your Understanding

1. A 10 N force acts over 2.0 m in the same direction. How much work is done?
2. A 3.0 kg object moves at 4.0 m/s. Find its kinetic energy.
3. When is mechanical energy conserved?

## Mixed Practice

1. A 0.50 kg ball is thrown upward at 12 m/s. Ignoring air resistance, how high does it rise?
2. A 1200 kg car speeds up from 10 m/s to 20 m/s. Find the change in kinetic energy.
3. A student climbs a 4.0 m staircase in 5.0 s. If the student’s mass is 60 kg, what average power is required just to increase gravitational potential energy?
4. A 5.0 kg crate is pushed 8.0 m with a 40 N force at \(30^\circ\) above horizontal. Find the work done by the applied force.

