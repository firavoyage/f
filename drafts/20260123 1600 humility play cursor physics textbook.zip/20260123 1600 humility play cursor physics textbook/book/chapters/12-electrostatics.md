# 12. Electrostatics

Electrostatics studies electric charge at rest and the forces it produces.

## 12.1 Charge

- Charge comes in two types: positive and negative.
- Like charges repel; unlike charges attract.
- Charge is conserved.

Unit: coulomb (C).

## 12.2 Coulomb’s law

For two point charges:

\[
F = k\frac{|q_1 q_2|}{r^2}
\]

Direction: along the line connecting charges; sign determines attraction/repulsion.

## 12.3 Electric field (idea)

Electric field is force per charge:

\[
\vec{E} = \frac{\vec{F}}{q}
\]

For a point charge:

\[
E = k\frac{|q|}{r^2}
\]

## Worked Example: Force between charges

Two charges \(q_1 = +2.0\ \mu\text{C}\) and \(q_2 = -3.0\ \mu\text{C}\) are 0.50 m apart. Find the magnitude of the force.

\[
F = k\frac{|q_1 q_2|}{r^2}
= (8.99\times 10^9)\frac{(2.0\times 10^{-6})(3.0\times 10^{-6})}{(0.50)^2}
\approx 0.216\ \text{N}
\]

Attractive (opposite signs).

## Check Your Understanding

1. Why do you use absolute value in Coulomb’s law for magnitude?
2. What does electric field represent physically?
3. If distance doubles, how does force change?

## Mixed Practice

1. Find the electric force between \(+1.0\ \mu\text{C}\) and \(+1.0\ \mu\text{C}\) separated by 0.20 m.
2. A charge creates an electric field of 400 N/C at a point. What force would it exert on a \(2.0\times 10^{-6}\) C test charge?
3. Compare electric and gravitational forces: how are their equations similar?

