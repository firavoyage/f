# C. Answer Key (Student Edition)

This section is intentionally minimal in the student edition. In many classes, full solutions are provided separately.

## Chapter 0 — Check Your Understanding (selected)

### 0. Mathematical Tools for Physics

1. \(72{,}000 = 7.2\times 10^4\)
2. Slope \(m=\frac{10-2}{4-0}=2\). Equation: \(y=2x+2\).
3. Magnitude \(=\sqrt{3^2+4^2}=5\).

### 0. Units, Conversions, and Significant Figures

1. \(3.5\ \text{cm} = 0.035\ \text{m}\)

