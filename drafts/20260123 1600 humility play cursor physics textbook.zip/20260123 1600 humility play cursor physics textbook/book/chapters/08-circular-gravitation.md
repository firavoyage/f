# 8. Circular Motion and Gravitation

Circular motion involves acceleration even at constant speed, because velocity direction changes.

## 8.1 Uniform circular motion

For an object moving in a circle of radius \(r\) at speed \(v\):

\[
a_c = \frac{v^2}{r}
\]

Direction: toward the center (centripetal).

Centripetal force is not a new kind of force; it is the **net inward force**:

\[
\sum F_{\text{in}} = m\frac{v^2}{r}
\]

## 8.2 Gravitation (Newton’s law)

The gravitational force between two masses:

\[
F_g = G\frac{m_1 m_2}{r^2}
\]

Near Earth’s surface, weight is \(W=mg\), which is a special case.

## 8.3 Orbital motion (idea)

For a circular orbit, gravity provides centripetal force:

\[
G\frac{Mm}{r^2} = m\frac{v^2}{r}
\Rightarrow v = \sqrt{\frac{GM}{r}}
\]

## Worked Example 1: Centripetal acceleration

A car goes around a curve of radius 50 m at 14 m/s. Find centripetal acceleration.

\[
a_c = \frac{v^2}{r} = \frac{14^2}{50} = 3.92\ \text{m/s}^2
\]

## Worked Example 2: Gravitational force

Find the gravitational force between two 5.0 kg masses separated by 0.20 m.

\[
F_g = G\frac{m_1 m_2}{r^2}
= (6.67\times 10^{-11})\frac{(5.0)(5.0)}{(0.20)^2}
\approx 4.2\times 10^{-8}\ \text{N}
\]

## Check Your Understanding

1. Why is there acceleration in uniform circular motion even if speed is constant?
2. What provides the centripetal force for a satellite in circular orbit?
3. If speed doubles in a circle of the same radius, how does \(a_c\) change?

## Mixed Practice

1. A 0.20 kg ball on a string moves in a circle of radius 0.80 m at 3.0 m/s. Find the required centripetal force.
2. A roller coaster loop has radius 12 m. What centripetal acceleration occurs at 18 m/s?
3. Two masses 2.0 kg and 3.0 kg are 0.50 m apart. Find the gravitational force between them.

