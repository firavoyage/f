# D. Teacher Materials (Optional)

This chapter is a placeholder for instructor-only resources:

- Full worked solutions
- Rubrics
- Quizzes/tests
- Lab data sets and expected graphs

If you want, tell me:

- your course level (regular / honors / AP-aligned)
- your pacing (semester / year)
- calculator policy and math prerequisites

and I can generate teacher materials consistent with your constraints.

