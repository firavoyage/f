# A. Problem-Solving Strategy

Use this routine consistently.

## A.1 The 5-step method

1. **Sketch and define the system**.
2. **List knowns/unknowns** (with units).
3. **Choose equations** that match the model/assumptions.
4. **Solve algebraically first**, then plug in numbers.
5. **Evaluate**: units, sign, size, and common-sense check.

## A.2 Tips that prevent most mistakes

- Keep symbols until the end.
- Track units on every line.
- Use a clear sign convention (state it).
- If your answer is “weird,” it may be correct—but check assumptions first.

