# Lab 02 — Acceleration on a Ramp

## Question

How does the slope of a velocity–time graph relate to acceleration for a cart rolling down a ramp?

## Safety

- Keep the ramp stable and secured.
- Catch the cart so it doesn’t fall off a table.

## Materials

- Low-friction cart + track or ramp
- Meterstick
- Timer or motion sensor (preferred)
- Books/blocks to raise the ramp

## Procedure (motion sensor preferred)

1. Set the ramp at a small angle.
2. Release the cart from rest.
3. Record velocity vs time (or position vs time).
4. Repeat for a steeper angle.

## Analysis

1. For each angle, plot \(v\) vs \(t\).
2. Determine the best-fit slope of each plot and interpret it as acceleration.
3. Compare accelerations for the two angles. Explain the difference using forces/components.

## Extension (optional)

Measure ramp angle \(\theta\) and compare measured \(a\) to \(g\sin\theta\) (qualitatively or quantitatively).

