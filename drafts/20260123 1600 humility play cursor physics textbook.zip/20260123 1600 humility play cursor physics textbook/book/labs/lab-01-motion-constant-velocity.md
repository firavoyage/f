# Lab 01 — Motion at Constant Velocity

## Question

When an object moves at (approximately) constant velocity, what does a position–time graph look like, and what does its slope represent?

## Safety

- Keep walking paths clear.
- Do not run with equipment.

## Materials

- Meterstick or measuring tape
- Timer (phone stopwatch is ok)
- Masking tape (to mark positions)
- Optional: motion sensor

## Procedure (tape + timer)

1. Mark a straight line with tape at 0 m, 1 m, 2 m, 3 m, 4 m, 5 m.
2. One student walks steadily along the line.
3. A partner records the time when the walker reaches each mark.
4. Repeat for a faster walk (or a slow jog, if allowed).

## Data table (suggested)

| Trial | Position \(x\) (m) | Time \(t\) (s) |
|------:|-------------------:|---------------:|
| 1     | 0.0                |                |
|       | 1.0                |                |
|       | 2.0                |                |
|       | 3.0                |                |
|       | 4.0                |                |
|       | 5.0                |                |

## Analysis

1. Plot \(x\) vs \(t\) for each trial.
2. Draw a best-fit line for each plot.
3. Compute slope for each line. Include units.
4. Interpret the slope physically.

## Conclusion prompts

- Which trial had larger slope? What does that mean?
- How consistent was the “constant velocity” assumption? What evidence supports your claim?

