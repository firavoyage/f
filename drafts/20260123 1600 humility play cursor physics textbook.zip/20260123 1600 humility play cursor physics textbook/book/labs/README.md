# Labs

These labs are designed for common classroom equipment. Each lab includes:

- Purpose + key question
- Safety notes
- Materials
- Procedure
- Data table suggestions
- Analysis questions

See individual lab files:

- `lab-01-motion-constant-velocity.md`
- `lab-02-acceleration-cart-ramp.md`
- `lab-03-newtons-second-law.md`

