# Lab 03 — Testing Newton’s Second Law

## Question

How does acceleration depend on net force and mass?

## Safety

- Keep fingers away from moving cart wheels.
- Ensure hanging masses can’t hit feet if they fall.

## Materials

- Cart and track
- Pulley + string
- Mass hanger + masses
- Meterstick
- Timer or motion sensor

## Setup idea

A cart on a track is connected by a string over a pulley to a hanging mass. The hanging mass provides an approximately constant net force.

## Procedure (high level)

1. Choose a cart mass \(m\) (include added masses).
2. Choose a hanging mass \(m_h\) to provide pulling force.
3. Release from rest and measure acceleration (via motion sensor or timing method).
4. Repeat while changing:
   - net force (change \(m_h\)), keeping total mass roughly constant, or
   - total mass (add mass to cart), keeping force roughly constant.

## Analysis

1. Create a graph of acceleration vs net force for constant mass. Describe the relationship.
2. Create a graph of acceleration vs total mass for constant force. Describe the relationship.
3. Compare to the model \(a=\frac{F_{\text{net}}}{m}\).

## Sources of error (prompt)

Discuss friction, pulley losses, and reaction time (if using manual timing).

