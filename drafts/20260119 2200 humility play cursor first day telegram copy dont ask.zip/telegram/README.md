## Telegram Copy (Mock)

This is a lightweight, static Telegram-style clone that runs locally in the browser. It uses only HTML/CSS/JS with mocked chat data — no backend or real messaging.

### Features
- Sidebar chat list with pinned items and search filter
- Chat header showing presence and avatar initials
- Message thread with outgoing/incoming styling
- Composer with send-on-enter; mock bot echoes replies
- Light/dark theme toggle stored in localStorage

### Run
Open `index.html` in a browser:
```bash
cd /home/fira/telegram
python -m http.server 3000
# visit http://localhost:3000
```

### Notes
- All data lives in-memory; refreshing resets state.
- The “New chat” action is a stub for now.
