const el = (selector) => document.querySelector(selector);
const template = (id) => document.getElementById(id).content.firstElementChild;

const chats = [
  {
    id: "anna",
    name: "Anna Petrova",
    online: true,
    pinned: true,
    preview: "See you at 7? 🙂",
    messages: [
      { from: "anna", text: "Hey! Ready for tonight?", ts: Date.now() - 1000 * 60 * 60 },
      { from: "me", text: "Absolutely. Same place?", ts: Date.now() - 1000 * 60 * 45 },
      { from: "anna", text: "Yep. See you at 7? 🙂", ts: Date.now() - 1000 * 60 * 30 },
    ],
  },
  {
    id: "team",
    name: "Product Team",
    online: false,
    pinned: true,
    preview: "Roadmap doc updated",
    messages: [
      { from: "me", text: "Shared the roadmap doc 🚀", ts: Date.now() - 1000 * 60 * 120 },
      { from: "matt", text: "Looks great to me", ts: Date.now() - 1000 * 60 * 80 },
      { from: "me", text: "Will present tomorrow", ts: Date.now() - 1000 * 60 * 10 },
    ],
  },
  {
    id: "bot",
    name: "Echo Bot",
    online: true,
    pinned: false,
    preview: "Type anything, I reply",
    messages: [
      { from: "bot", text: "Hi! I'm a pretend bot. Send me something.", ts: Date.now() - 1000 * 60 * 5 },
    ],
  },
];

let activeChatId = chats[0].id;
let theme = localStorage.getItem("tg-theme") || "light";

const formatTime = (ts) =>
  new Intl.DateTimeFormat(undefined, {
    hour: "2-digit",
    minute: "2-digit",
  }).format(ts);

const renderChatList = () => {
  const list = el("#chat-list");
  list.innerHTML = "";

  const query = el("#search-input").value.trim().toLowerCase();

  const sorted = [...chats].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    const at = a.messages.at(-1)?.ts ?? 0;
    const bt = b.messages.at(-1)?.ts ?? 0;
    return bt - at;
  });

  sorted
    .filter((chat) => chat.name.toLowerCase().includes(query))
    .forEach((chat) => {
      const item = template("chat-item-template").cloneNode(true);
      item.dataset.id = chat.id;
      item.querySelector(".chat-item__title").textContent = chat.name;
      item.querySelector(".chat-item__preview").textContent =
        chat.messages.at(-1)?.text ?? chat.preview;
      item.querySelector(".avatar").textContent = chat.name[0];
      item.querySelector(".chat-item__time").textContent = formatTime(chat.messages.at(-1)?.ts);
      item.classList.toggle("chat-item--active", chat.id === activeChatId);
      item.classList.toggle("chat-item--pinned", chat.pinned);

      item.addEventListener("click", () => {
        activeChatId = chat.id;
        renderChatList();
        renderChat();
      });

      list.appendChild(item);
    });
};

const renderChat = () => {
  const chat = chats.find((c) => c.id === activeChatId);
  if (!chat) return;

  el("#chat-title").textContent = chat.name;
  el("#chat-avatar").textContent = chat.name[0];
  el("#chat-status").textContent = chat.online ? "online" : "last seen recently";

  const messagesEl = el("#messages");
  messagesEl.innerHTML = "";

  chat.messages.forEach((msg) => {
    const node = template("message-template").cloneNode(true);
    node.querySelector(".message__text").textContent = msg.text;
    node.querySelector(".message__time").textContent = formatTime(msg.ts);
    node.classList.toggle("message--outgoing", msg.from === "me");
    if (msg.from === "bot") {
      node.querySelector(".message__status").textContent = "🤖";
    }
    messagesEl.appendChild(node);
  });

  messagesEl.scrollTop = messagesEl.scrollHeight;
};

const sendMessage = () => {
  const input = el("#message-input");
  const text = input.value.trim();
  if (!text) return;
  const chat = chats.find((c) => c.id === activeChatId);
  if (!chat) return;
  const ts = Date.now();
  chat.messages.push({ from: "me", text, ts });
  input.value = "";
  renderChatList();
  renderChat();
  if (chat.id === "bot") {
    setTimeout(() => {
      chat.messages.push({
        from: "bot",
        text: `Echo: ${text}`,
        ts: Date.now(),
      });
      renderChatList();
      renderChat();
    }, 500);
  }
};

const toggleTheme = () => {
  theme = theme === "light" ? "dark" : "light";
  localStorage.setItem("tg-theme", theme);
  document.documentElement.classList.toggle("dark", theme === "dark");
};

const init = () => {
  document.documentElement.classList.toggle("dark", theme === "dark");
  el("#send").addEventListener("click", sendMessage);
  el("#message-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  el("#theme-toggle").addEventListener("click", toggleTheme);
  el("#search-input").addEventListener("input", renderChatList);
  el("#new-chat").addEventListener("click", () => alert("This is a mock Telegram copy."));
  renderChatList();
  renderChat();
};

document.addEventListener("DOMContentLoaded", init);
