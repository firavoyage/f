# Chapter 5: Multi-Head Attention

In the last chapter, we explored the magic of Self-Attention, which allows a word to look at all other words in a sentence and decide which ones are most important for its own meaning. It's like a single detective carefully considering all the clues.

But what if one detective isn't enough? What if there are different kinds of relationships between words that a single attention mechanism might miss? For example, one relationship might be about grammar (e.g., which verb goes with which noun), another about semantic meaning (e.g., synonyms or related concepts), and another about coreference (e.g., which pronoun refers to which person).

This is where **Multi-Head Attention** comes in. Instead of having just one "attention head" (our single detective), we have multiple attention heads working in parallel. Each head is like a different detective, specializing in looking for a different kind of relationship or pattern in the sentence.

## Multiple Perspectives, Richer Understanding

Imagine our sentence: "The quick brown fox jumps over the lazy dog."

*   **Head 1 (Grammar Detective):** Might focus on the relationship between "fox" (noun) and "jumps" (verb), understanding the subject-verb agreement.
*   **Head 2 (Description Detective):** Might focus on "fox" and its adjectives "quick" and "brown," understanding its characteristics.
*   **Head 3 (Context Detective):** Might focus on "jumps" and "over," understanding the action's direction.
*   **Head 4 (Contrast Detective):** Might notice the contrast between "quick brown fox" and "lazy dog."

Each attention head performs the same Query-Key-Value (QKV) calculation we discussed in Chapter 4, but it does so independently. The key difference is that each head uses its *own, separate* set of learned Query, Key, and Value transformation matrices. This means each head learns to project the original word embeddings into a different "subspace" where it can find specific types of relationships.

## The Process of Multi-Head Attention

Here's how it works step-by-step:

1.  **Split and Project:** The input embeddings for each word are not just fed into one Q, K, V calculation. Instead, they are first projected into multiple sets of Q, K, and V vectors. If we have `H` attention heads, the original embedding for a word is transformed `H` times, resulting in `H` different Q, K, and V vectors for that word.

    *Example: If an embedding has 512 dimensions and we have 8 heads, each head might work with Q, K, V vectors of 64 dimensions (512 / 8 = 64).*

2.  **Parallel Attention:** Each of these `H` sets of Q, K, V vectors then goes through its own independent Self-Attention calculation. This means each head generates its own set of attention weights and its own context-aware output vector for each word.

    `Head_i(Q, K, V) = Attention(Q_i, K_i, V_i)`

3.  **Concatenate:** Once all `H` attention heads have produced their output vectors for all words, these `H` output vectors for each word are concatenated (joined together side-by-side). If each head produced a 64-dimension vector, and we have 8 heads, concatenating them would result in a 512-dimension vector (8 * 64 = 512).

4.  **Linear Transformation:** Finally, this concatenated vector is passed through one last linear transformation (a fancy way of saying it's multiplied by another learned matrix). This step combines the information from all the different attention heads into a single, unified output vector that has the same dimension as the original input embedding. This output vector now contains a rich, multi-faceted understanding of the word's context.

    `MultiHead(Q, K, V) = Concat(Head_1, ..., Head_H) * W_O`

    Where `W_O` is the final learned weight matrix.

## Why is Multi-Head Attention so effective?

*   **Captures Diverse Relationships:** By allowing multiple attention heads to focus on different aspects of the input, the model can learn a much richer and more nuanced understanding of the relationships between words. Some heads might focus on syntax, others on semantics, and others on long-range dependencies.
*   **Increased Representational Power:** Having multiple "perspectives" on the same data significantly increases the model's ability to represent complex linguistic phenomena.
*   **Robustness:** If one attention head fails to capture a particular relationship, others might still catch it, making the model more robust.

Multi-Head Attention is a critical component of the Transformer architecture, allowing LLMs to process and understand language with unprecedented depth. It's one of the key reasons why these models are so powerful at tasks like translation, summarization, and generating coherent text. In the next chapter, we'll put all these pieces together to see how the full Transformer Block is constructed.
