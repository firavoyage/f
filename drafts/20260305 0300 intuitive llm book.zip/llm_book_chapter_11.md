# Chapter 11: Rolling the Dice

In the last chapter, we saw how an LLM calculates probabilities for every possible next word using the softmax layer. We also briefly touched upon **greedy decoding**, where the model simply picks the word with the highest probability. While simple, greedy decoding often leads to text that is repetitive, predictable, and lacks creativity. It always takes the "safest" option, which isn't how humans speak or write.

To make LLMs generate more diverse, creative, and human-like text, we introduce **sampling strategies**. These strategies involve a bit of "rolling the dice" – introducing a controlled amount of randomness into the word selection process. This allows the model to sometimes pick a word that isn't the absolute most probable, but still makes sense in context, leading to more interesting and varied outputs.

## Temperature: Controlling the Creativity

Imagine you're at a buffet, and you have a favorite dish you always pick. Greedy decoding is like always picking that one dish. **Temperature** is a parameter that controls how "adventurous" the LLM is in its word choices. It's applied to the logits *before* the softmax function.

Mathematically, the softmax function with temperature `T` looks like this:

`P(word_i) = e^(z_i / T) / Σ [e^(z_j / T)]`

Here's how `T` affects the probabilities:

*   **High Temperature (e.g., T > 1.0):** Makes the probability distribution flatter. This means the probabilities of less likely words increase, and the model is more likely to pick a less common but still plausible word. It encourages more creative, surprising, and sometimes nonsensical outputs. Think of it as turning up the heat, making the model 
 more "random" or "creative."
*   **Low Temperature (e.g., T < 1.0):** Makes the probability distribution sharper. This means the probabilities of the most likely words increase even further, and the model is more likely to pick the most probable words. This leads to more conservative, focused, and predictable outputs, similar to greedy decoding but with a slight chance for variation. Think of it as cooling down the model, making it more "safe" or "deterministic."
*   **Temperature = 1.0:** This is the standard softmax, where the probabilities are calculated directly from the logits without any scaling.
*   **Temperature = 0:** This effectively becomes greedy decoding, always picking the most probable word.

Adjusting the temperature is a common way to control the output style of an LLM. For creative writing, you might use a higher temperature. For factual summaries, a lower temperature is usually preferred.

## Top-K Sampling: Limiting the Choices

Even with temperature, an LLM still considers *all* words in its vocabulary. **Top-K sampling** simplifies this by only considering the `K` most probable words for the next token. All other words are completely ignored.

Here's how it works:

1.  The LLM calculates the probabilities for all words in its vocabulary (after applying temperature, if desired).
2.  It then identifies the `K` words with the highest probabilities.
3.  From these `K` words, it randomly samples one word based on their (re-normalized) probabilities.

For example, if `K=3` and the probabilities are:

| Word   | Probability |
| :----- | :---------- |
| mat    | 0.609       |
| couch  | 0.224       |
| floor  | 0.136       |
| dog    | 0.030       |
| table  | 0.001       |
| ...    | ...         |

With `K=3`, the model would only consider "mat," "couch," and "floor." It would then re-normalize their probabilities (so they sum to 1) and pick one of them randomly. This prevents the model from ever picking a very unlikely word like "table" or "moon," which might lead to nonsensical output.

Top-K sampling helps to keep the generated text coherent while still introducing some randomness. However, a fixed `K` value might not always be ideal. Sometimes, the distribution of probabilities is very sharp (one word is much more likely than others), and `K` might be too large, allowing unlikely words. Other times, the distribution is very flat (many words are almost equally likely), and `K` might be too small, limiting creativity too much.

## Top-P (Nucleus) Sampling: Dynamic Choices

To address the limitations of a fixed `K`, **Top-P sampling** (also known as **Nucleus sampling**) offers a more dynamic approach. Instead of picking a fixed number of words, Top-P sampling selects the smallest set of most probable words whose cumulative probability exceeds a certain threshold `P`.

Here's how it works:

1.  The LLM calculates the probabilities for all words and sorts them from most likely to least likely.
2.  It then adds words to a list, starting from the most probable, until the sum of their probabilities reaches or exceeds `P`.
3.  From this dynamically sized list of words, it randomly samples one word based on their (re-normalized) probabilities.

For example, if `P=0.9` and the probabilities are:

| Word   | Probability | Cumulative Probability |
| :----- | :---------- | :--------------------- |\n| mat    | 0.609       | 0.609                  |
| couch  | 0.224       | 0.833                  |
| floor  | 0.136       | 0.969 (exceeds P=0.9)  |
| dog    | 0.030       | 0.999                  |
| table  | 0.001       | 1.000                  |

In this case, the model would select "mat," "couch," and "floor" because their cumulative probability (0.969) is greater than `P=0.9`. It would then sample from these three words. If `P` was set to `0.8`, it would only consider "mat" and "couch" (cumulative 0.833).

Top-P sampling is often preferred because it adapts to the shape of the probability distribution. If there are only a few very likely words, it will focus on those. If there are many words with similar probabilities, it will consider more options, leading to more diverse and natural-sounding text.

## Combining Strategies

Often, these sampling strategies are combined. For instance, you might apply a `temperature` to soften or sharpen the probabilities, and then use `Top-P` sampling to select the final set of words to choose from. This gives fine-grained control over the creativity and coherence of the generated text.

These sampling techniques are crucial for making LLMs useful and engaging. Without them, the models would be stuck in a loop of predicting the most obvious next word, leading to dull and uninspired outputs. By introducing controlled randomness, LLMs can generate text that feels fresh, creative, and surprisingly human-like. In the next chapter, we'll look at how LLMs manage to keep track of the conversation and generate long, coherent responses.

## References

[1] Holtzman, A., Buys, J., Du, L., Forbes, M., & Choi, Y. (2019). The Curious Case of Neural Text Degeneration. *International Conference on Learning Representations (ICLR)*. [https://arxiv.org/abs/1904.09751](https://arxiv.org/abs/1904.09751)
[2] Fan, A., Lewis, M., & Dauphin, Y. (2018). Hierarchical Neural Story Generation. *Proceedings of the 2018 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long and Short Papers)*, 889-898. [https://aclanthology.org/N18-1104/](https://aclanthology.org/N18-1104/)
