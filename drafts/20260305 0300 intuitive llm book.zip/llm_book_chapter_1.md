# Chapter 1: What is an LLM?

Imagine you have a super-smart friend who has read almost every book, article, and conversation ever written on the internet. This friend doesn't *understand* things in the way a human does, with feelings or personal experiences. Instead, this friend is incredibly good at predicting what word comes next in a sentence, based on all the text they've ever seen. This super-smart friend is a **Large Language Model**, or **LLM** for short.

At its core, an LLM is a computer program designed to process and generate human-like text. The "Large" part means it has been trained on an enormous amount of text data—trillions of words, often spanning petabytes of information [1]. The "Language Model" part refers to its ability to understand the patterns and structures of human language. Think of it like a very sophisticated autocomplete feature, but one that can write entire essays, answer complex questions, or even generate creative stories.

## The Idea of a "Next-Word Predictor"

The fundamental job of an LLM is surprisingly simple: given a sequence of words, predict the most likely next word. Let's take a simple example:

"The cat sat on the..."

What word do you expect to come next? Probably "mat," "couch," or "floor." An LLM does this same prediction, but on a much grander scale and with far more nuance. It calculates the probability of every possible word in its vocabulary appearing next. For instance, it might determine:

*   "mat": 60% probability
*   "couch": 25% probability
*   "floor": 10% probability
*   "dog": 3% probability
*   "moon": 1% probability
*   Other words: 1% probability

This might seem too simple for something so powerful, but this basic ability, when scaled up with massive amounts of data and complex mathematical structures, allows LLMs to perform astonishing feats of language generation and comprehension. They don't just predict one word; they predict word after word, building coherent sentences, paragraphs, and even entire documents.

## How is this useful?

This "next-word prediction" capability is the foundation for many applications you might have already encountered:

*   **Chatbots and Virtual Assistants:** When you ask a question, the LLM predicts the best sequence of words to form an answer.
*   **Content Creation:** From writing marketing copy to drafting emails, LLMs can generate text that sounds natural and relevant.
*   **Translation:** By understanding patterns between languages, LLMs can predict equivalent words and phrases in different tongues.
*   **Summarization:** They can identify the most important information in a long text and condense it into a shorter version.

It's important to remember that while LLMs can generate text that seems intelligent, they don't possess consciousness or true understanding. They are incredibly sophisticated pattern-matching machines. They learn statistical relationships between words and concepts from the vast ocean of text they've been trained on. In the following chapters, we will dive deeper into how these models turn words into numbers, how they learn these patterns, and how they generate their impressive outputs.

## References

[1] OpenAI. (2023). *GPT-4 Technical Report*. [https://openai.com/research/gpt-4](https://openai.com/research/gpt-4)
