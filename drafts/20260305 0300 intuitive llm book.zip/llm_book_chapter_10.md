# Chapter 10: Predicting the Future

We've spent a lot of time understanding how LLMs are built (the Transformer architecture) and how they learn (training with massive datasets, loss functions, and optimizers). Now, it's time for the exciting part: how does a trained LLM actually *generate* new text? How does it predict the future words that form coherent sentences and paragraphs?

The core idea remains the same as in Chapter 1: the LLM is a next-word predictor. After all the complex calculations within its many Transformer Blocks, the model arrives at a point where it needs to decide what word comes next. This decision-making process involves a special layer called the **softmax layer** and the concept of **probability distributions**.

## The Final Output: Logits

After an input sequence of words (which could be a prompt you give it, or the words it has already generated) passes through all the Transformer Blocks, the final output for the *next* word isn't immediately a word. Instead, for each possible word in the LLM's vocabulary, the model produces a raw numerical score. These scores are called **logits**.

Imagine the LLM has a vocabulary of 50,000 words. For the next word, it will output 50,000 logits, one for each word. These logits can be any real number—positive, negative, or zero. A higher logit generally means the model thinks that word is more likely to appear next, but these raw scores aren't probabilities yet.

## The Softmax Layer: Turning Scores into Probabilities

To turn these raw logits into meaningful probabilities, the LLM uses the **softmax function**. The softmax function takes a vector of arbitrary real numbers (our logits) and transforms them into a probability distribution. This means:

1.  All the output numbers will be between 0 and 1.
2.  All the output numbers will sum up to 1.

This makes it easy to interpret: a word with a probability of 0.75 is much more likely than a word with a probability of 0.05.

The mathematical formula for the softmax function for a given logit `z_i` (for word `i`) is:

`P(word_i) = e^(z_i) / Σ [e^(z_j)]`

Let's break this down:

*   `e` is Euler's number, an important mathematical constant (approximately 2.718).
*   `e^(z_i)` means `e` raised to the power of the logit `z_i`. This operation makes all numbers positive and spreads them out, giving more weight to higher logits.
*   `Σ [e^(z_j)]` means the sum of `e` raised to the power of *all* logits in the vocabulary. This sum is used to normalize the values, ensuring they all add up to 1.

### Example: Softmax in Action

Let's say for the prompt "The cat sat on the...", the LLM outputs the following logits for a tiny vocabulary:

| Word   | Logit (z) |
| :----- | :-------- |
| mat    | 2.0       |
| couch  | 1.0       |
| floor  | 0.5       |
| dog    | -1.0      |

First, we calculate `e^z` for each logit:

*   `e^(2.0)` ≈ 7.389
*   `e^(1.0)` ≈ 2.718
*   `e^(0.5)` ≈ 1.649
*   `e^(-1.0)` ≈ 0.368

Next, we sum these values: `7.389 + 2.718 + 1.649 + 0.368 = 12.124`

Finally, we divide each `e^z` by the sum to get the probabilities:

*   `P(mat) = 7.389 / 12.124` ≈ **0.609 (60.9%)**
*   `P(couch) = 2.718 / 12.124` ≈ **0.224 (22.4%)**
*   `P(floor) = 1.649 / 12.124` ≈ **0.136 (13.6%)**
*   `P(dog) = 0.368 / 12.124` ≈ **0.030 (3.0%)**

Notice that these probabilities sum up to 1 (or very close to 1 due to rounding). The word "mat" has the highest probability, indicating it's the most likely next word according to the model.

## From Probabilities to Text: The Greedy Approach

Once the softmax layer has given us a probability distribution over all possible next words, how does the LLM actually pick *one* word to add to the sequence? The simplest method is called **greedy decoding**.

In greedy decoding, the LLM simply picks the word with the highest probability. In our example above, it would pick "mat" because it has a 60.9% chance, which is higher than any other word. It then adds "mat" to the input sequence, and the entire process repeats to predict the *next* word after "The cat sat on the mat...".

While straightforward, greedy decoding has a significant drawback: it always picks the locally best option, which might not lead to the globally best (most coherent or interesting) sequence of words. Imagine you're navigating a maze. Always taking the path that looks best right now might lead you to a dead end later. For generating creative or diverse text, greedy decoding is often too predictable and repetitive.

This limitation leads us to more sophisticated sampling strategies, which we will explore in the next chapter. These strategies introduce a bit of randomness or allow the model to consider multiple good options, making the generated text much more natural and varied.

## References

[1] Bridle, J. S. (1990). Probabilistic interpretation of feedforward classification network outputs, with relationships to statistical pattern recognition. *Neurocomputing: Algorithms, Architectures and Applications*, 227-236.
[2] Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press. [https://www.deeplearningbook.org/](https://www.deeplearningbook.org/)
