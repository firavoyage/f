# Chapter 12: The Context Window

We've explored how LLMs predict the next word and how sampling strategies add creativity. But how do these models generate long, coherent responses, remembering what they've just said or what you've told them earlier in a conversation? This ability is tied to the concept of the **context window** and a clever optimization called the **KV Cache**.

## The Context Window: The LLM's Short-Term Memory

An LLM doesn't remember everything it has ever learned during training when it's generating text. Instead, it operates within a **context window**. This context window is like a limited-size notepad where the LLM keeps track of the most recent words in the conversation or text it's generating. Every time the LLM generates a new word, that word is added to the context window, and if the window is full, the oldest word might be forgotten to make space for the new one.

Think of it this way: when you're having a conversation, you don't remember every single word ever spoken in your life. You focus on the most recent sentences to understand the flow of the discussion. The context window is the LLM's equivalent of this short-term memory. It's the sequence of tokens (words and sub-words) that the model considers when predicting the *next* token.

The size of the context window is a crucial characteristic of an LLM. It's measured in tokens. A model with a 4,000-token context window can 
process and generate text that is about 4,000 tokens long (roughly 3,000 words in English, though it varies). Newer models can have context windows of 32,000, 128,000, or even more tokens [1].

Why is the context window size important?

*   **Coherence:** A larger context window allows the LLM to maintain a more consistent and coherent narrative over longer stretches of text. It can refer back to ideas or details mentioned much earlier in the conversation or document.
*   **Understanding:** For tasks like summarization or question-answering, a larger context window means the model can take in more of the original text, leading to more accurate and comprehensive results.
*   **Computational Cost:** Processing a larger context window requires more memory and computational power, especially because the attention mechanism (Chapter 4) scales quadratically with the sequence length. This is why there's a trade-off between context window size and efficiency.

## The KV Cache: Remembering What It Just Said

When an LLM generates text, it does so one word (or token) at a time. For each new token it generates, it needs to re-evaluate the entire sequence of tokens it has seen so far, including the ones it just generated. If it had to re-calculate the Query, Key, and Value vectors for *every* token from scratch *every* time, it would be incredibly slow and inefficient.

This is where the **KV Cache** comes in. KV stands for Key and Value. Remember from Chapter 4 that in the self-attention mechanism, each word generates a Key vector and a Value vector. These vectors are crucial for other words to pay attention to it.

When the LLM processes the initial prompt, it calculates the Key and Value vectors for all the tokens in that prompt. Instead of discarding them, it stores them in a special memory called the KV Cache. Then, when it generates the first new token, it only needs to calculate the Key and Value vectors for *that single new token*. It can then combine these new K and V vectors with all the previously cached K and V vectors from the prompt to perform the attention calculation for the next token.

Here's a simplified illustration:

1.  **Initial Prompt:** "The cat sat on the"
    *   The LLM processes "The", "cat", "sat", "on", "the".
    *   It calculates and stores `K_The, V_The`, `K_cat, V_cat`, `K_sat, V_sat`, `K_on, V_on`, `K_the, V_the` in the KV Cache.
2.  **Generate First Word:** Predicts "mat"
    *   The LLM processes "mat".
    *   It calculates `K_mat, V_mat`.
    *   It uses `K_mat, V_mat` *and all the cached K and V vectors* to predict the next word.
    *   It adds `K_mat, V_mat` to the KV Cache.
3.  **Generate Second Word:** Predicts "floor"
    *   The LLM processes "floor".
    *   It calculates `K_floor, V_floor`.
    *   It uses `K_floor, V_floor` *and all the cached K and V vectors* (from "The cat sat on the mat") to predict the next word.
    *   It adds `K_floor, V_floor` to the KV Cache.

This process continues, with the KV Cache growing with each generated token. The KV Cache significantly speeds up the generation process because the model doesn't have to re-compute the Key and Value vectors for tokens it has already processed. It just retrieves them from memory.

## The Limit of the Cache

The size of the KV Cache is directly related to the context window size. If the context window is 4,000 tokens, the KV Cache can store the Key and Value vectors for up to 4,000 tokens. Once the context window is full, the oldest Key and Value vectors are discarded to make room for new ones, mirroring how the context window itself operates.

The KV Cache is a crucial optimization that makes the real-time, token-by-token generation of LLMs practical. Without it, generating long responses would be prohibitively slow and computationally expensive. It allows the LLM to efficiently "remember" the conversation history and maintain coherence, which is essential for the impressive conversational abilities we see in modern LLMs.

## References

[1] OpenAI. (2023). *GPT-4 Technical Report*. [https://openai.com/research/gpt-4](https://openai.com/research/gpt-4)
[2] Pope, A., et al. (2022). Efficiently Scaling Transformer Inference. *arXiv preprint arXiv:2211.05102*. [https://arxiv.org/abs/2211.05102](https://arxiv.org/abs/2211.05102)
