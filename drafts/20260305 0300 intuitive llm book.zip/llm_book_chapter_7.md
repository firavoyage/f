# Chapter 7: The Big Data Buffet

We've learned how LLMs turn words into numbers and how the Transformer architecture helps them understand the context of those numbers. But how do these models learn all of this in the first place? It's not like someone sits down and programs every single grammar rule or every fact into them. Instead, LLMs learn by reading, and they read *a lot*.

Imagine a child learning about the world. They don't get a rulebook; they observe, listen, and experience. They learn what words mean by hearing them used in different sentences, and they learn how sentences are put together by listening to countless conversations and stories. LLMs learn in a similar, but vastly scaled-up, way. They are fed an enormous "buffet" of text data, and from this data, they learn the patterns of human language.

This initial, massive learning phase is called **pre-training**.

## The Scale of the Data

When we say "enormous amount of text data," we're not talking about a few books. We're talking about text collected from almost every corner of the internet and digitized books. This includes:

*   **Web pages:** Billions of web pages, from news articles and blogs to forums and social media posts.
*   **Books:** Vast digital libraries of books, both fiction and non-fiction.
*   **Wikipedia:** The entire encyclopedia, a rich source of factual information.
*   **Code:** Programming code from public repositories, which helps LLMs understand logical structures.

To give you a sense of scale, some of the largest LLMs have been trained on datasets containing **trillions of tokens** [1]. If you were to read one token per second, it would take you tens of thousands of years to read the amount of data these models consume in their pre-training phase!

## Common Crawl: The Internet's Snapshot

One of the most famous and widely used datasets for pre-training LLMs is **Common Crawl** [2]. Imagine a giant robot that tirelessly surfs the internet, downloading billions of web pages every month. That's essentially what Common Crawl does. It's a non-profit organization that provides open access to petabytes of web crawl data.

When an LLM is pre-trained using Common Crawl, it's essentially reading a massive snapshot of the public internet. This includes everything from academic papers to casual forum discussions. While incredibly rich, this data also comes with challenges:

*   **Noise and Redundancy:** The internet is full of repetitive content, spam, and low-quality text. The training process needs to be robust enough to handle this "noise."
*   **Bias:** The internet reflects human biases, and these biases can be learned by the LLM. If the training data contains stereotypes, the model might reproduce them.
*   **Outdated Information:** The internet is constantly changing, so some information in the crawl might be old or incorrect.

Because of these issues, raw Common Crawl data is often filtered and cleaned before being used for LLM training. This cleaning process might involve removing duplicate content, filtering out low-quality pages, and trying to balance the representation of different topics or viewpoints.

## The Pre-training Task: Predicting the Next Word (Again!)

During pre-training, the LLM is given a very simple, yet powerful, task: **predict the next word in a sequence**. It's the same fundamental task we discussed in Chapter 1, but now applied to this enormous dataset.

Here's how it works:

1.  The model is shown a sequence of words from the training data (e.g., "The cat sat on the").
2.  It then tries to predict the next word (e.g., "mat").
3.  It compares its prediction to the actual next word in the text.
4.  If its prediction is wrong, the model adjusts its internal parameters (the weights and biases within its Transformer Blocks) to make a better prediction next time. This adjustment process is called **backpropagation** and **gradient descent**, which we'll explore in Chapter 9.

This process is repeated billions and trillions of times across the entire dataset. By constantly trying to predict the next word, the LLM implicitly learns:

*   **Grammar and Syntax:** How words fit together to form grammatically correct sentences.
*   **Semantics:** The meanings of words and how they relate to each other.
*   **World Knowledge:** Factual information and common sense, simply by observing how concepts are discussed in text.
*   **Reasoning Patterns:** How arguments are constructed and how ideas flow.

Pre-training is the most computationally intensive part of building an LLM. It requires massive computing power (hundreds or thousands of powerful GPUs) running for weeks or even months. But the result is a highly capable model that has learned a vast amount about human language and the world it describes, forming the foundation for all its future abilities.

## References

[1] Brown, T. B., Mann, B., Ryder, N., Subbiah, M., Kaplan, J., Dhariwal, P., ... & Amodei, D. (2020). Language Models are Few-Shot Learners. *Advances in Neural Information Processing Systems*, 33, 1877-1901. [https://arxiv.org/abs/2005.14165](https://arxiv.org/abs/2005.14165)
[2] Common Crawl. (n.d.). *About Common Crawl*. [https://commoncrawl.org/](https://commoncrawl.org/)
