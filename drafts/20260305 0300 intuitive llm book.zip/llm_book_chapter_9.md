# Chapter 9: The Optimizer's Journey

In the previous chapter, we learned about the **loss function**, which acts like a strict teacher, telling the LLM how wrong its predictions are. Now, we need to understand how the LLM uses this feedback to actually *learn* and improve. This is the job of the **optimizer**, and its journey involves two key concepts: **backpropagation** and **gradient descent**.

Imagine you're blindfolded and standing on a hilly landscape. Your goal is to find the lowest point (the bottom of a valley). You can't see, so how do you know which way to go? You might feel the slope of the ground beneath your feet. If it slopes down to your left, you take a small step in that direction. If it slopes down to your right, you step that way. You keep taking small steps in the direction of the steepest descent until you can't feel any more downward slope—you've found a low point.

This analogy perfectly describes **gradient descent**. The hilly landscape represents the "loss landscape," where every point on the landscape corresponds to a different combination of the LLM's internal settings (its **weights** and **biases**). The height of the point represents the loss value for that combination of settings. Our goal is to find the combination of weights and biases that results in the lowest possible loss.

## Weights and Biases: The LLM's Internal Settings

Throughout the Transformer Blocks, within the attention mechanisms and the feed-forward networks, there are billions of tiny knobs and dials. These are the **weights** and **biases**. They are just numbers that determine how information flows and is transformed within the model. When we say an LLM "learns," we mean it's adjusting these weights and biases. Initially, these are set randomly, which is why an untrained LLM just produces gibberish.

## Gradient Descent: Finding the Lowest Point

**Gradient descent** is the algorithm that guides the adjustment of these weights and biases. The "gradient" in gradient descent is a mathematical term that tells us the direction of the steepest slope on our loss landscape. If we want to minimize the loss, we need to move in the *opposite* direction of the gradient.

Here's the simplified process:

1.  **Make a Prediction:** The LLM takes some input text and makes a prediction for the next word.
2.  **Calculate Loss:** The loss function (e.g., cross-entropy) compares the prediction to the actual next word and calculates a loss value.
3.  **Calculate Gradients (Backpropagation):** This is where **backpropagation** comes in. Backpropagation is a clever algorithm that efficiently calculates how much each individual weight and bias in the entire LLM contributed to the final loss. It works by moving backward through the network, from the output layer all the way to the input layer, calculating the "gradient" (the slope) of the loss with respect to each weight and bias. It tells us, for each knob, whether turning it up or down would decrease the loss, and by how much.

    Think of it like this: the loss function tells you the overall error. Backpropagation then figures out which specific parts of the LLM were most responsible for that error and how they need to change.

4.  **Update Weights and Biases:** Once we have the gradients for all weights and biases, the optimizer uses these gradients to update them. The update rule is typically:

    `New_Weight = Old_Weight - (Learning_Rate * Gradient_of_Loss_with_respect_to_Weight)`

    *   **Learning Rate:** This is a small positive number (e.g., 0.001) that controls how big of a step we take down the slope. If the learning rate is too large, we might overshoot the lowest point. If it's too small, learning will be very slow.
    *   The minus sign is crucial because we want to move in the *opposite* direction of the gradient (downhill, not uphill).

This entire process—prediction, loss calculation, backpropagation, and weight update—is repeated millions or billions of times, for millions of different text examples from the training data. Each repetition is a small step down the loss landscape, gradually bringing the LLM closer to a state where it can make highly accurate next-word predictions.

## Why is this so hard?

*   **Billions of Parameters:** Modern LLMs have billions, even trillions, of weights and biases. Calculating gradients for all of them and updating them efficiently is a massive computational challenge.
*   **Complex Loss Landscape:** The "hilly landscape" is not a simple bowl shape. It's incredibly complex, with many small bumps and valleys. The optimizer needs to navigate this landscape without getting stuck in a "local minimum" (a small dip that isn't the absolute lowest point).
*   **Vanishing/Exploding Gradients:** In very deep networks, gradients can sometimes become extremely small (vanish) or extremely large (explode), making it difficult for the model to learn. Techniques like Layer Normalization (Chapter 6) and careful initialization of weights help mitigate these issues.

## The Optimizer's Role

While gradient descent is the core idea, there are many sophisticated "optimizers" (like Adam, RMSprop, or SGD with momentum) that refine this process. These optimizers use clever tricks to make the descent faster, more stable, and less likely to get stuck. They are like advanced hikers who know how to navigate difficult terrain more effectively.

By continuously adjusting its weights and biases based on the feedback from the loss function and the guidance of the optimizer, the LLM slowly but surely learns the intricate patterns, grammar, and semantics of human language. This training process is what transforms a randomly initialized network into a powerful language model capable of generating coherent and meaningful text. In the next part, we'll finally explore how these trained models actually generate text.

## References

[1] Rumelhart, D. E., Hinton, G. E., & Williams, R. J. (1986). Learning representations by back-propagating errors. *Nature*, 323(6088), 533-536. [https://www.nature.com/articles/323533a0](https://www.nature.com/articles/323533a0)
[2] Kingma, D. P., & Ba, J. (2014). Adam: A Method for Stochastic Optimization. *International Conference on Learning Representations (ICLR)*. [https://arxiv.org/abs/1412.6980](https://arxiv.org/abs/1412.6980)
