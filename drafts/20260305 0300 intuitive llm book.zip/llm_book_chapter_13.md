# Chapter 13: Teaching Manners

By now, we understand that Large Language Models (LLMs) are incredibly powerful next-word predictors, trained on vast amounts of internet text. This pre-training gives them a broad understanding of language, facts, and common sense. However, if you were to interact with a raw, pre-trained LLM, you might find it a bit... unruly. It might generate text that is factually incorrect, biased, toxic, or simply not helpful in a conversational setting. It has learned to mimic the internet, and the internet isn't always polite or accurate.

This is where **alignment** comes in. Alignment is the process of teaching an LLM to be helpful, harmless, and honest (or at least, to follow instructions and avoid generating undesirable content). One of the first crucial steps in aligning an LLM is **Supervised Fine-Tuning (SFT)**, which is essentially teaching the model manners and how to follow instructions.

## From Predicting to Following Instructions

During pre-training, the LLM's goal was simply to predict the next word. It didn't care *why* it was predicting that word, only that it was statistically likely. After pre-training, we want the LLM to do more than just complete sentences; we want it to *respond* to our requests, *answer* our questions, and *follow* our instructions. This requires a shift in its behavior.

Supervised Fine-Tuning achieves this by training the pre-trained LLM on a much smaller, but very high-quality, dataset of examples where humans have explicitly demonstrated the desired behavior. This dataset consists of pairs of prompts and ideal responses.

Imagine you're teaching a very knowledgeable but socially awkward robot how to interact with people. You wouldn't just let it read all human conversations; you'd give it specific examples of good interactions:

*   **Human:** "What is the capital of France?"
*   **Robot (Desired):** "The capital of France is Paris."

*   **Human:** "Write a short poem about cats."
*   **Robot (Desired):** "Furry friends, soft and sly, / Prowling softly, passing by. / Gentle purrs and playful pounce, / On tiny paws, they softly bounce."

This dataset is carefully curated, often by human annotators, to cover a wide range of instructions and desired responses. It teaches the LLM not just *what* to say, but *how* to say it in a helpful and appropriate manner.

## The Process of Supervised Fine-Tuning

SFT is a continuation of the training process, but with a different objective and a different dataset:

1.  **Start with a Pre-trained LLM:** We take the LLM that has already learned general language patterns from the massive pre-training dataset.
2.  **Curated Instruction Dataset:** A new dataset is prepared. This dataset contains examples of user prompts (instructions) and the high-quality, human-written responses that we want the LLM to emulate. These responses are often crafted to be helpful, safe, and adhere to specific guidelines.
3.  **Continued Training:** The LLM is then trained on this instruction dataset. The training objective is still to predict the next word, but now it's predicting the next word *in the context of following an instruction*. The loss function (cross-entropy loss, as discussed in Chapter 8) measures how well the LLM's generated response matches the human-written ideal response.
4.  **Adjusting Weights:** Just like in pre-training, the optimizer (Chapter 9) uses backpropagation to adjust the LLM's weights and biases. However, because the dataset is much smaller and more focused, these adjustments primarily fine-tune the model's behavior to follow instructions, rather than learning entirely new language patterns.

## What SFT Teaches the LLM

Supervised Fine-Tuning is critical for several reasons:

*   **Instruction Following:** It teaches the model to understand and execute commands, rather than just continuing a given text in a statistically probable way.
*   **Helpfulness:** It guides the model to generate responses that are directly relevant and useful to the user's query.
*   **Safety and Harmlessness:** By training on examples of safe and non-toxic responses, SFT helps reduce the generation of harmful content.
*   **Conversational Turn-Taking:** It helps the model learn the dynamics of a conversation, such as when to answer, when to ask for clarification, and how to maintain a coherent dialogue.

After SFT, the LLM is much more polite and capable of interacting with users in a meaningful way. It has learned the 
basics of good behavior, but there's still more to learn to truly make it a helpful and trustworthy assistant. This leads us to the next stage of alignment, which involves human feedback, and we'll explore that in the next chapter.

## References

[1] Ouyang, L., Wu, J., Jiang, X., Almeida, D., Wainwright, C. L., Mishkin, P., ... & Lowe, R. (2022). Training language models to follow instructions with human feedback. *Advances in Neural Information Processing Systems*, 35, 27730-27744. [https://arxiv.org/abs/2203.02155](https://arxiv.org/abs/2203.02155)
