# Chapter 2: Words as Numbers

To a computer, words are just a jumble of letters, and letters are just a jumble of ones and zeros. Computers don't understand language the way humans do. So, before a Large Language Model (LLM) can start predicting the next word, it needs a way to turn human language—the words we speak and write—into something it can understand: **numbers**.

This process is called **tokenization**, and the individual pieces of text that are converted into numbers are called **tokens**. A token isn't always a whole word. Sometimes it's a part of a word, a whole word, or even a punctuation mark. The goal is to break down text into meaningful units that the LLM can work with efficiently.

## Why not just use letters?

You might wonder, why not just give the computer individual letters? Imagine trying to predict the next letter in a sentence. The possibilities are huge, and the meaning of a single letter is very small. "T" could be followed by "h" for "the," "o" for "to," or "r" for "run." It would be very hard for the model to learn complex patterns.

Using whole words is better, but what about words like "running," "ran," and "runs"? They all relate to the same action. If the model treats them as completely separate words, it has to learn about each one individually. This is where tokens come in. Tokenization tries to find a good balance.

## How Tokenization Works

There are many ways to tokenize text, but one common method used in LLMs is called **Byte Pair Encoding (BPE)** [1]. Here's a simplified idea of how it works:

1.  **Start with individual characters:** Imagine the LLM starts by treating every character (like 'a', 'b', 'c', ' ', '.', etc.) as its own token.
2.  **Find the most common pairs:** It then looks for the most frequently occurring pairs of characters and merges them into a new token. For example, if "th" appears very often, it becomes a single token.
3.  **Repeat:** This process is repeated. If "the" is a common sequence, it might merge "th" and "e" into "the" as a single token.

This continues until a certain number of tokens are created, or no more common pairs can be found. This way, common words like "hello" or "world" often become single tokens, while less common words or new words might be broken down into smaller, more manageable sub-word tokens. For example:

| Original Word | Possible Tokens (BPE) |
| :------------ | :-------------------- |
| `unbelievable` | `un`, `believe`, `able` |
| `tokenization` | `token`, `iz`, `ation` |
| `running` | `run`, `ning` |

This approach has several advantages:

*   **Handles unknown words:** If the model encounters a word it has never seen before (like a new slang term or a very specific technical term), it can break it down into smaller, known sub-word tokens. This is much better than just marking it as "unknown."
*   **Reduces vocabulary size:** Instead of having a vocabulary of millions of unique words, which would be computationally expensive, BPE creates a vocabulary of common sub-word units and words. This makes the model more efficient.
*   **Captures morphological information:** By breaking words into parts like prefixes and suffixes, the model can implicitly learn about word structure and meaning (e.g., `un-` often means "not").

## From Tokens to Numbers: One-Hot Encoding (and why it's not enough)

Once we have tokens, we need to turn them into numbers. A simple way to do this is called **one-hot encoding**. Imagine you have a vocabulary of 10,000 unique tokens. Each token gets a unique number from 0 to 9,999. Then, for each token, you create a very long list of numbers (a vector) where almost all the numbers are zero, except for one position which is a '1'.

For example, if "cat" is token number 123, its one-hot vector would be:

`[0, 0, ..., 0, 1 (at position 123), 0, ..., 0]`

This works for giving each token a unique numerical representation. However, there's a big problem: **one-hot vectors don't capture any meaning or relationship between words.** The one-hot vector for "cat" is just as different from "dog" as it is from "moon." In the real world, "cat" and "dog" are much more similar in meaning than "cat" and "moon." Our numerical representation should reflect that.

This limitation leads us to the next crucial step in how LLMs understand language: **embeddings**, which we'll explore in the next chapter. Embeddings are a much smarter way to turn words into numbers, allowing the model to grasp the subtle relationships between them.

## References

[1] Sennrich, R., Haddow, B., & Birch, A. (2016). Neural Machine Translation of Rare Words with Subword Units. *Proceedings of the 54th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers)*, 1715-1725. [https://aclanthology.org/P16-1162/](https://aclanthology.org/P16-1162/)
