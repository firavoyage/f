'''# Chapter 3: The Map of Meaning

In the last chapter, we saw that simply assigning a unique number to each word (like with one-hot encoding) isn't enough. It tells the computer that words are different, but not *how* they are different or similar. To truly understand language, a model needs to grasp the relationships between words. "King" is to "Queen" as "Man" is to "Woman." "Walking" is a slower version of "running." How can we represent these rich relationships with numbers?

The answer is **embeddings**. An embedding is a way of representing a word not as a single number, but as a list of numbers called a **vector**. Instead of a vector with thousands of zeros and a single one, an embedding vector is much shorter (maybe a few hundred to a few thousand numbers long) and all the numbers are meaningful. Each number in the vector represents a different "feature" or "dimension" of the word's meaning.

## High-Dimensional Space: A Library for Words

Imagine a giant library where every book is a word. In a normal library, you might organize books alphabetically. But what if you could organize them by their meaning? You could put all the books about animals in one section, all the books about royalty in another, and all the books about actions in a third. This is a bit like what embeddings do, but in a much more powerful way.

Now, imagine that instead of just a few sections, you have thousands of different "shelves" or "dimensions." One dimension might represent "royalness." In this dimension, "King," "Queen," and "Prince" would have high values, while "Cat," "Sandwich," and "Running" would have low values. Another dimension might represent "age," where "Man" and "Woman" have higher values than "Boy" and "Girl." A third dimension could represent "living vs. non-living," and so on.

This "library" with thousands of dimensions is what we call **high-dimensional space**. It's impossible for us to visualize thousands of dimensions (we can barely handle three!), but for a computer, it's just a list of numbers. By representing each word as a point in this high-dimensional space, we create a "map of meaning." Words with similar meanings will be located close to each other on this map.

| Word | "Royalness" | "Gender (Male)" | "Age (Adult)" | ... (hundreds more) |
| :--- | :---------- | :-------------- | :------------ | :------------------ |
| King | 0.98 | 0.95 | 0.91 | ... |
| Queen | 0.97 | -0.96 | 0.89 | ... |
| Man | 0.01 | 0.94 | 0.90 | ... |
| Woman | 0.02 | -0.95 | 0.88 | ... |
| Cat | -0.23 | 0.05 | 0.31 | ... |

*Note: These are just illustrative numbers. The actual dimensions learned by an LLM are abstract and not so easily named.*

## Vector Math: The Magic of Meaning

The real magic of embeddings is that you can do math with them. Because words are now vectors (lists of numbers), you can add and subtract them to explore relationships between concepts. The most famous example of this is:

**Vector("King") - Vector("Man") + Vector("Woman") ≈ Vector("Queen")**

Let's break this down. When you subtract the vector for "Man" from "King," you are essentially removing the "maleness" feature. What's left is a vector representing the concept of "royalty." Then, when you add the vector for "Woman," you are adding the "femaleness" feature to this concept of royalty. The resulting vector is very, very close to the vector for "Queen."

This ability to perform arithmetic on word meanings is incredibly powerful. It allows the model to understand analogies and relationships in a way that was impossible with simple one-hot encoding. It can learn that "France" is to "Paris" as "Japan" is to "Tokyo," or that "big" is the opposite of "small."

## How are Embeddings Learned?

So where do these magical embedding vectors come from? They are not created by humans. Instead, the LLM **learns** them during its training process. The model starts with random vectors for every token in its vocabulary. As it trains on trillions of words, its goal is to predict the next word in a sentence. To get better at this prediction, it constantly adjusts the embedding vectors.

If the model sees the sentence "The cat sat on the mat" over and over again, it will learn that "cat" and "mat" often appear in similar contexts. It will start to move their vectors closer together in the high-dimensional space. Similarly, if it sees words like "king," "queen," "prince," and "princess" used with words like "palace," "crown," and "throne," it will learn to group all these "royalty" words together.

These learned embeddings are one of the most important foundational pieces of an LLM. They transform messy, unstructured text into a structured, numerical format that the model can work with. With this map of meaning, the LLM is now ready to learn the complex grammar and logic of language, which is the job of the Transformer architecture we will explore in the next part.
'''
