# Chapter 8: Learning from Mistakes

In the last chapter, we talked about how LLMs learn by trying to predict the next word in a massive dataset. But how does the model know if its prediction was good or bad? And how does it use that information to get better? This is where the concept of **loss functions** comes in. A loss function is like a strict teacher who gives the LLM a score based on how wrong its prediction was. The higher the score, the bigger the mistake.

The goal of training an LLM is to minimize this loss score. The model constantly tries to adjust its internal settings (called **parameters** or **weights**) so that its predictions become more accurate, and thus, its loss score goes down.

## The Guessing Game: How an LLM Predicts

Let's revisit our simple example: "The cat sat on the..."

When the LLM processes this sentence, it doesn't just pick one word. Instead, it calculates a probability for *every single word* in its vocabulary (which can be tens of thousands or even hundreds of thousands of words) to be the next word. For instance, it might say:

*   "mat": 60% probability
*   "couch": 25% probability
*   "floor": 10% probability
*   "dog": 3% probability
*   "moon": 1% probability
*   Other words: 1% probability

Let's say the *actual* next word in the training text was "mat." The LLM assigned a 60% probability to "mat." That's pretty good, but it's not 100%. The loss function will measure this difference.

## Cross-Entropy Loss: The LLM's Report Card

The most common loss function used for training LLMs is called **Cross-Entropy Loss** [1]. It's particularly good at measuring how well a model predicts probabilities for categories (in our case, categories are words in the vocabulary). Here's the basic idea:

Cross-entropy loss penalizes the model more heavily when it's very confident about a wrong answer, and less heavily when it's uncertain but still wrong. It also rewards the model for being confident about the correct answer.

Let's use a simplified example. Imagine the LLM's vocabulary only has three words: "mat", "couch", "floor".

| Word   | Predicted Probability | Actual (Target) Probability |
| :----- | :-------------------- | :-------------------------- |
| mat    | 0.60                  | 1.0 (because "mat" was the actual next word) |
| couch  | 0.25                  | 0.0                         |
| floor  | 0.10                  | 0.0                         |

The formula for cross-entropy loss for a single prediction is:

`Loss = - Σ [Target_Probability(word) * log(Predicted_Probability(word))]`

Where `Σ` means "sum of," and `log` is the natural logarithm.

Let's calculate it for our example:

*   For "mat": `1.0 * log(0.60) = 1.0 * (-0.51) = -0.51`
*   For "couch": `0.0 * log(0.25) = 0.0` (anything multiplied by zero is zero)
*   For "floor": `0.0 * log(0.10) = 0.0`

So, the total loss for this prediction is `-( -0.51 + 0.0 + 0.0 ) = 0.51`.

Now, what if the LLM was *more* confident about "mat"? Let's say it predicted:

| Word   | Predicted Probability | Actual (Target) Probability |
| :----- | :-------------------- | :-------------------------- |
| mat    | 0.90                  | 1.0                         |
| couch  | 0.05                  | 0.0                         |
| floor  | 0.05                  | 0.0                         |

Loss = `-( 1.0 * log(0.90) + 0.0 * log(0.05) + 0.0 * log(0.05) )`
Loss = `-( 1.0 * (-0.11) + 0 + 0 ) = 0.11`

Notice that `0.11` is much smaller than `0.51`. This shows that when the model is more confident about the correct answer, the loss is lower. The model wants to get this loss as close to zero as possible.

What if the model was very confident about the *wrong* answer? Let's say the actual word was "mat", but the model predicted:

| Word   | Predicted Probability | Actual (Target) Probability |
| :----- | :-------------------- | :-------------------------- |
| mat    | 0.05                  | 1.0                         |
| couch  | 0.90                  | 0.0                         |
| floor  | 0.05                  | 0.0                         |

Loss = `-( 1.0 * log(0.05) + 0.0 * log(0.90) + 0.0 * log(0.05) )`
Loss = `-( 1.0 * (-2.99) + 0 + 0 ) = 2.99`

This loss (`2.99`) is much higher! This tells the model that it made a big mistake and needs to adjust its parameters significantly. This is exactly what we want: a strong signal to learn from big errors.

## The Role of the Loss Function

The cross-entropy loss function provides a clear, numerical signal to the LLM about how well it's performing its next-word prediction task. This signal is crucial because it tells the model *how* to adjust its billions of parameters. Without a way to quantify error, the model wouldn't know if it was getting better or worse.

Every time the LLM makes a prediction and calculates the loss, this loss value is used to guide the learning process. The goal is to continuously tweak the model's internal weights and biases in a direction that reduces this loss. This iterative process of making predictions, calculating loss, and adjusting parameters is the heart of how LLMs learn, and it's powered by a sophisticated optimization technique called **backpropagation** and **gradient descent**, which we will explore in the next chapter.

## References

[1] Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press. [https://www.deeplearningbook.org/](https://www.deeplearningbook.org/)
