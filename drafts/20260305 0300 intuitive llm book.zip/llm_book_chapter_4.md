
# Chapter 4: The Secret Sauce: Attention

In the previous chapters, we learned how words are turned into numbers (tokens) and then into meaningful numerical representations called embeddings. These embeddings give the computer a sense of a word's meaning. But how does an LLM understand the *context* of a word within a sentence? How does it know that in "The bank of the river," "bank" refers to land, while in "The money in the bank," it refers to a financial institution?

The answer lies in a brilliant mechanism called **Attention**. Specifically, **Self-Attention**. Before Attention, models struggled to keep track of long-range dependencies in sentences. They might forget the beginning of a long sentence by the time they reached the end. Attention solves this by allowing the model to "look" at other words in the input sequence to decide which ones are most important for understanding a particular word.

## Imagine a Detective

Think of each word in a sentence as a detective. When a detective (word) is trying to understand its own meaning, it doesn't just look at itself. It looks at all the other detectives (words) in the room. Some other detectives might be very important for its investigation, while others might be irrelevant. The detective then assigns an "importance score" to every other detective, including itself.

For example, in the sentence "The quick brown fox jumps over the lazy dog," when the word "fox" is trying to understand itself, it might pay a lot of attention to "quick" and "brown" because they describe it. It might also pay attention to "jumps" because that's what a fox does. It would pay less attention to "lazy" or "dog" because they describe a different animal.

## The Math Behind Self-Attention: Queries, Keys, and Values

In the world of LLMs, this "looking" and "assigning importance" is done through a mathematical process involving three special vectors for each word: the **Query (Q)**, the **Key (K)**, and the **Value (V)**. These are derived from the word's embedding, but they serve different purposes:

*   **Query (Q):** This is like the question the current word is asking: "What other words are relevant to me?"
*   **Key (K):** This is like a label or description for each word: "Here's what I have to offer."
*   **Value (V):** This is the actual information content of the word: "If you pay attention to me, this is what you'll get."

Here's a simplified breakdown of the self-attention calculation for a single word (let's say, `word_i`):

1.  **Calculate Attention Scores (Query-Key Dot Product):** For `word_i`'s Query vector (Q_i), we compare it to the Key vector (K_j) of *every other word* (`word_j`) in the sentence (including `word_i` itself). This comparison is usually done using a **dot product**. The dot product tells us how similar two vectors are. A higher dot product means `word_i` should pay more attention to `word_j`.

    `Attention_Score(i, j) = Q_i ⋅ K_j`

2.  **Scale and Softmax:** The attention scores can be very large, so they are first scaled down (divided by the square root of the dimension of the key vectors, `d_k`) to prevent issues during training. Then, these scaled scores are passed through a **softmax function**. Softmax turns a list of numbers into a probability distribution, where all numbers are positive and sum up to 1. This means each attention score now represents a percentage of attention `word_i` should give to `word_j`.

    `Attention_Weights(i, j) = Softmax( (Q_i ⋅ K_j) / sqrt(d_k) )`

3.  **Weighted Sum of Values:** Finally, `word_i` takes the Value vector (V_j) of every other word (`word_j`) and multiplies it by its corresponding attention weight. It then sums up all these weighted Value vectors. This sum becomes the new, context-aware representation of `word_i`.

    `Output_Vector(i) = Σ [Attention_Weights(i, j) * V_j]` (sum over all j)

This `Output_Vector(i)` now contains information not just about `word_i` itself, but also about all the other words that were relevant to it, weighted by their importance. This process happens for *every word* in the input sequence, simultaneously. This means each word gets a rich, context-aware representation that captures its relationships with all other words.

## Why is this so powerful?

*   **Long-Range Dependencies:** Attention allows a word to directly access information from any other word in the sequence, no matter how far apart they are. This is crucial for understanding long sentences or paragraphs.
*   **Contextual Understanding:** It helps resolve ambiguities (like the "bank" example) by letting the model weigh the importance of surrounding words.
*   **Parallel Processing:** The calculations for each word can happen at the same time, which makes training LLMs much faster on specialized hardware like GPUs.

Self-attention is the core innovation of the **Transformer architecture**, which we will delve into in the next chapter. It's the "secret sauce" that enabled LLMs to make such incredible leaps in understanding and generating human language. Without it, the powerful models we see today would not be possible.
