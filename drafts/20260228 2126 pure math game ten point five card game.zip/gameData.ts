/**
 * 十点半游戏分析数据
 * 基于严格数学计算（精确分数运算）
 * 
 * 规则：52张牌，无王
 * - 黑牌(♠♣): 0.5点
 * - 红牌A,J,Q,K: 1点
 * - 红牌2-10: 2-10点
 * - 超过10.5爆牌归零
 */

// 牌组点数分布
export const cardDistribution = [
  { value: 0.5, count: 26, prob: 0.5000, label: '0.5点 (黑牌)', color: '#94a3b8' },
  { value: 1.0, count: 8, prob: 0.1538, label: '1点 (红A/J/Q/K)', color: '#ef4444' },
  { value: 2.0, count: 2, prob: 0.0385, label: '2点', color: '#f97316' },
  { value: 3.0, count: 2, prob: 0.0385, label: '3点', color: '#f97316' },
  { value: 4.0, count: 2, prob: 0.0385, label: '4点', color: '#f97316' },
  { value: 5.0, count: 2, prob: 0.0385, label: '5点', color: '#f97316' },
  { value: 6.0, count: 2, prob: 0.0385, label: '6点', color: '#f97316' },
  { value: 7.0, count: 2, prob: 0.0385, label: '7点', color: '#f97316' },
  { value: 8.0, count: 2, prob: 0.0385, label: '8点', color: '#f97316' },
  { value: 9.0, count: 2, prob: 0.0385, label: '9点', color: '#f97316' },
  { value: 10.0, count: 2, prob: 0.0385, label: '10点', color: '#f97316' },
];

// 单人策略数据（动态规划最优解）
export const singlePlayerStrategy = [
  { score: 0.5, bustProb: 0.0000, drawExpected: 6.2692, optimalValue: 6.2692, action: 'draw' },
  { score: 1.0, bustProb: 0.0000, drawExpected: 5.9615, optimalValue: 5.9615, action: 'draw' },
  { score: 1.5, bustProb: 0.0000, drawExpected: 5.9423, optimalValue: 5.9423, action: 'draw' },
  { score: 2.0, bustProb: 0.0000, drawExpected: 5.6346, optimalValue: 5.6346, action: 'draw' },
  { score: 2.5, bustProb: 0.0000, drawExpected: 5.6154, optimalValue: 5.6154, action: 'draw' },
  { score: 3.0, bustProb: 0.0000, drawExpected: 5.3077, optimalValue: 5.3077, action: 'draw' },
  { score: 3.5, bustProb: 0.0000, drawExpected: 5.2885, optimalValue: 5.2885, action: 'draw' },
  { score: 4.0, bustProb: 0.0000, drawExpected: 4.9808, optimalValue: 4.9808, action: 'draw' },
  { score: 4.5, bustProb: 0.1538, drawExpected: 4.9808, optimalValue: 4.9808, action: 'draw' },
  { score: 5.0, bustProb: 0.1923, drawExpected: 4.9808, optimalValue: 5.0000, action: 'stop' },
  { score: 5.5, bustProb: 0.1923, drawExpected: 5.3846, optimalValue: 5.5000, action: 'stop' },
  { score: 6.0, bustProb: 0.2308, drawExpected: 5.3654, optimalValue: 6.0000, action: 'stop' },
  { score: 6.5, bustProb: 0.2308, drawExpected: 5.7115, optimalValue: 6.5000, action: 'stop' },
  { score: 7.0, bustProb: 0.2692, drawExpected: 5.7115, optimalValue: 7.0000, action: 'stop' },
  { score: 7.5, bustProb: 0.2692, drawExpected: 6.0769, optimalValue: 7.5000, action: 'stop' },
  { score: 8.0, bustProb: 0.3077, drawExpected: 6.0192, optimalValue: 8.0000, action: 'stop' },
  { score: 8.5, bustProb: 0.3077, drawExpected: 6.3654, optimalValue: 8.5000, action: 'stop' },
  { score: 9.0, bustProb: 0.3462, drawExpected: 6.2885, optimalValue: 9.0000, action: 'stop' },
  { score: 9.5, bustProb: 0.3462, drawExpected: 6.6154, optimalValue: 9.5000, action: 'stop' },
  { score: 10.0, bustProb: 0.5000, drawExpected: 5.2500, optimalValue: 10.0000, action: 'stop' },
  { score: 10.5, bustProb: 1.0000, drawExpected: 0.0000, optimalValue: 10.5000, action: 'stop' },
];

// 最优策略下的最终点数分布
export const finalDistribution = [
  { score: 0, prob: 0.1444, label: '爆牌', color: '#ef4444' },
  { score: 5.0, prob: 0.1671, label: '5.0', color: '#60a5fa' },
  { score: 5.5, prob: 0.0646, label: '5.5', color: '#60a5fa' },
  { score: 6.0, prob: 0.0766, label: '6.0', color: '#60a5fa' },
  { score: 6.5, prob: 0.0482, label: '6.5', color: '#60a5fa' },
  { score: 7.0, prob: 0.0766, label: '7.0', color: '#60a5fa' },
  { score: 7.5, prob: 0.0482, label: '7.5', color: '#60a5fa' },
  { score: 8.0, prob: 0.0766, label: '8.0', color: '#60a5fa' },
  { score: 8.5, prob: 0.0482, label: '8.5', color: '#60a5fa' },
  { score: 9.0, prob: 0.0766, label: '9.0', color: '#60a5fa' },
  { score: 9.5, prob: 0.0482, label: '9.5', color: '#60a5fa' },
  { score: 10.0, prob: 0.0766, label: '10.0', color: '#60a5fa' },
  { score: 10.5, prob: 0.0482, label: '10.5 ★', color: '#fbbf24' },
];

// 多人竞技策略数据
export const multiplayerStrategy: Record<number, Array<{
  score: number;
  stopWinProb: number;
  drawWinProb: number;
  action: string;
  optimalWinProb: number;
}>> = {
  2: [
    { score: 0.5, stopWinProb: 0.1444, drawWinProb: 0.4980, action: 'draw', optimalWinProb: 0.4980 },
    { score: 1.0, stopWinProb: 0.1444, drawWinProb: 0.4714, action: 'draw', optimalWinProb: 0.4714 },
    { score: 1.5, stopWinProb: 0.1444, drawWinProb: 0.4726, action: 'draw', optimalWinProb: 0.4726 },
    { score: 2.0, stopWinProb: 0.1444, drawWinProb: 0.4460, action: 'draw', optimalWinProb: 0.4460 },
    { score: 2.5, stopWinProb: 0.1444, drawWinProb: 0.4472, action: 'draw', optimalWinProb: 0.4472 },
    { score: 3.0, stopWinProb: 0.1444, drawWinProb: 0.4206, action: 'draw', optimalWinProb: 0.4206 },
    { score: 3.5, stopWinProb: 0.1444, drawWinProb: 0.4218, action: 'draw', optimalWinProb: 0.4218 },
    { score: 4.0, stopWinProb: 0.1444, drawWinProb: 0.3952, action: 'draw', optimalWinProb: 0.3952 },
    { score: 4.5, stopWinProb: 0.1444, drawWinProb: 0.3964, action: 'draw', optimalWinProb: 0.3964 },
    { score: 5.0, stopWinProb: 0.3115, drawWinProb: 0.3805, action: 'draw', optimalWinProb: 0.3805 },
    { score: 5.5, stopWinProb: 0.3757, drawWinProb: 0.3897, action: 'draw', optimalWinProb: 0.3897 },
    { score: 6.0, stopWinProb: 0.4144, drawWinProb: 0.4124, action: 'stop', optimalWinProb: 0.4144 },
    { score: 6.5, stopWinProb: 0.4768, drawWinProb: 0.4603, action: 'stop', optimalWinProb: 0.4768 },
    { score: 7.0, stopWinProb: 0.5392, drawWinProb: 0.4684, action: 'stop', optimalWinProb: 0.5392 },
    { score: 7.5, stopWinProb: 0.6016, drawWinProb: 0.5140, action: 'stop', optimalWinProb: 0.6016 },
    { score: 8.0, stopWinProb: 0.6640, drawWinProb: 0.5197, action: 'stop', optimalWinProb: 0.6640 },
    { score: 8.5, stopWinProb: 0.7264, drawWinProb: 0.5628, action: 'stop', optimalWinProb: 0.7264 },
    { score: 9.0, stopWinProb: 0.7887, drawWinProb: 0.5661, action: 'stop', optimalWinProb: 0.7887 },
    { score: 9.5, stopWinProb: 0.8511, drawWinProb: 0.6069, action: 'stop', optimalWinProb: 0.8511 },
    { score: 10.0, stopWinProb: 0.9135, drawWinProb: 0.4880, action: 'stop', optimalWinProb: 0.9135 },
    { score: 10.5, stopWinProb: 0.9759, drawWinProb: 0.0000, action: 'stop', optimalWinProb: 0.9759 },
  ],
  3: [
    { score: 0.5, stopWinProb: 0.0208, drawWinProb: 0.3896, action: 'draw', optimalWinProb: 0.3896 },
    { score: 1.0, stopWinProb: 0.0208, drawWinProb: 0.3567, action: 'draw', optimalWinProb: 0.3567 },
    { score: 1.5, stopWinProb: 0.0208, drawWinProb: 0.3576, action: 'draw', optimalWinProb: 0.3576 },
    { score: 2.0, stopWinProb: 0.0208, drawWinProb: 0.3267, action: 'draw', optimalWinProb: 0.3267 },
    { score: 2.5, stopWinProb: 0.0208, drawWinProb: 0.3289, action: 'draw', optimalWinProb: 0.3289 },
    { score: 3.0, stopWinProb: 0.0208, drawWinProb: 0.3003, action: 'draw', optimalWinProb: 0.3003 },
    { score: 3.5, stopWinProb: 0.0208, drawWinProb: 0.3042, action: 'draw', optimalWinProb: 0.3042 },
    { score: 4.0, stopWinProb: 0.0208, drawWinProb: 0.2787, action: 'draw', optimalWinProb: 0.2787 },
    { score: 4.5, stopWinProb: 0.0208, drawWinProb: 0.2855, action: 'draw', optimalWinProb: 0.2855 },
    { score: 5.0, stopWinProb: 0.0970, drawWinProb: 0.2651, action: 'draw', optimalWinProb: 0.2651 },
    { score: 5.5, stopWinProb: 0.1412, drawWinProb: 0.2781, action: 'draw', optimalWinProb: 0.2781 },
    { score: 6.0, stopWinProb: 0.1718, drawWinProb: 0.2677, action: 'draw', optimalWinProb: 0.2677 },
    { score: 6.5, stopWinProb: 0.2275, drawWinProb: 0.2947, action: 'draw', optimalWinProb: 0.2947 },
    { score: 7.0, stopWinProb: 0.2912, drawWinProb: 0.3071, action: 'draw', optimalWinProb: 0.3071 },
    { score: 7.5, stopWinProb: 0.3621, drawWinProb: 0.3664, action: 'draw', optimalWinProb: 0.3664 },
    { score: 8.0, stopWinProb: 0.4413, drawWinProb: 0.3918, action: 'stop', optimalWinProb: 0.4413 },
    { score: 8.5, stopWinProb: 0.5278, drawWinProb: 0.4594, action: 'stop', optimalWinProb: 0.5278 },
    { score: 9.0, stopWinProb: 0.6226, drawWinProb: 0.4908, action: 'stop', optimalWinProb: 0.6226 },
    { score: 9.5, stopWinProb: 0.7246, drawWinProb: 0.5641, action: 'stop', optimalWinProb: 0.7246 },
    { score: 10.0, stopWinProb: 0.8350, drawWinProb: 0.4763, action: 'stop', optimalWinProb: 0.8350 },
    { score: 10.5, stopWinProb: 0.9526, drawWinProb: 0.0000, action: 'stop', optimalWinProb: 0.9526 },
  ],
  4: [
    { score: 0.5, stopWinProb: 0.0030, drawWinProb: 0.3227, action: 'draw', optimalWinProb: 0.3227 },
    { score: 1.0, stopWinProb: 0.0030, drawWinProb: 0.2920, action: 'draw', optimalWinProb: 0.2920 },
    { score: 1.5, stopWinProb: 0.0030, drawWinProb: 0.2961, action: 'draw', optimalWinProb: 0.2961 },
    { score: 2.0, stopWinProb: 0.0030, drawWinProb: 0.2672, action: 'draw', optimalWinProb: 0.2672 },
    { score: 2.5, stopWinProb: 0.0030, drawWinProb: 0.2722, action: 'draw', optimalWinProb: 0.2722 },
    { score: 3.0, stopWinProb: 0.0030, drawWinProb: 0.2451, action: 'draw', optimalWinProb: 0.2451 },
    { score: 3.5, stopWinProb: 0.0030, drawWinProb: 0.2512, action: 'draw', optimalWinProb: 0.2512 },
    { score: 4.0, stopWinProb: 0.0030, drawWinProb: 0.2264, action: 'draw', optimalWinProb: 0.2264 },
    { score: 4.5, stopWinProb: 0.0030, drawWinProb: 0.2343, action: 'draw', optimalWinProb: 0.2343 },
    { score: 5.0, stopWinProb: 0.0302, drawWinProb: 0.2128, action: 'draw', optimalWinProb: 0.2128 },
    { score: 5.5, stopWinProb: 0.0531, drawWinProb: 0.2244, action: 'draw', optimalWinProb: 0.2244 },
    { score: 6.0, stopWinProb: 0.0718, drawWinProb: 0.2092, action: 'draw', optimalWinProb: 0.2092 },
    { score: 6.5, stopWinProb: 0.1087, drawWinProb: 0.2290, action: 'draw', optimalWinProb: 0.2290 },
    { score: 7.0, stopWinProb: 0.1575, drawWinProb: 0.2274, action: 'draw', optimalWinProb: 0.2274 },
    { score: 7.5, stopWinProb: 0.2181, drawWinProb: 0.2670, action: 'draw', optimalWinProb: 0.2670 },
    { score: 8.0, stopWinProb: 0.2937, drawWinProb: 0.2969, action: 'draw', optimalWinProb: 0.2969 },
    { score: 8.5, stopWinProb: 0.3836, drawWinProb: 0.3766, action: 'stop', optimalWinProb: 0.3836 },
    { score: 9.0, stopWinProb: 0.4918, drawWinProb: 0.4260, action: 'stop', optimalWinProb: 0.4918 },
    { score: 9.5, stopWinProb: 0.6171, drawWinProb: 0.5249, action: 'stop', optimalWinProb: 0.6171 },
    { score: 10.0, stopWinProb: 0.7637, drawWinProb: 0.4650, action: 'stop', optimalWinProb: 0.7637 },
    { score: 10.5, stopWinProb: 0.9300, drawWinProb: 0.0000, action: 'stop', optimalWinProb: 0.9300 },
  ],
  5: [
    { score: 0.5, stopWinProb: 0.0004, drawWinProb: 0.2833, action: 'draw', optimalWinProb: 0.2833 },
    { score: 1.0, stopWinProb: 0.0004, drawWinProb: 0.2539, action: 'draw', optimalWinProb: 0.2539 },
    { score: 1.5, stopWinProb: 0.0004, drawWinProb: 0.2600, action: 'draw', optimalWinProb: 0.2600 },
    { score: 2.0, stopWinProb: 0.0004, drawWinProb: 0.2322, action: 'draw', optimalWinProb: 0.2322 },
    { score: 2.5, stopWinProb: 0.0004, drawWinProb: 0.2390, action: 'draw', optimalWinProb: 0.2390 },
    { score: 3.0, stopWinProb: 0.0004, drawWinProb: 0.2129, action: 'draw', optimalWinProb: 0.2129 },
    { score: 3.5, stopWinProb: 0.0004, drawWinProb: 0.2205, action: 'draw', optimalWinProb: 0.2205 },
    { score: 4.0, stopWinProb: 0.0004, drawWinProb: 0.1962, action: 'draw', optimalWinProb: 0.1962 },
    { score: 4.5, stopWinProb: 0.0004, drawWinProb: 0.2052, action: 'draw', optimalWinProb: 0.2052 },
    { score: 5.0, stopWinProb: 0.0097, drawWinProb: 0.1838, action: 'draw', optimalWinProb: 0.1838 },
    { score: 5.5, stopWinProb: 0.0200, drawWinProb: 0.1955, action: 'draw', optimalWinProb: 0.1955 },
    { score: 6.0, stopWinProb: 0.0300, drawWinProb: 0.1790, action: 'draw', optimalWinProb: 0.1790 },
    { score: 6.5, stopWinProb: 0.0519, drawWinProb: 0.1970, action: 'draw', optimalWinProb: 0.1970 },
    { score: 7.0, stopWinProb: 0.0854, drawWinProb: 0.1909, action: 'draw', optimalWinProb: 0.1909 },
    { score: 7.5, stopWinProb: 0.1314, drawWinProb: 0.2238, action: 'draw', optimalWinProb: 0.2238 },
    { score: 8.0, stopWinProb: 0.1956, drawWinProb: 0.2418, action: 'draw', optimalWinProb: 0.2418 },
    { score: 8.5, stopWinProb: 0.2790, drawWinProb: 0.3102, action: 'draw', optimalWinProb: 0.3102 },
    { score: 9.0, stopWinProb: 0.3889, drawWinProb: 0.3703, action: 'stop', optimalWinProb: 0.3889 },
    { score: 9.5, stopWinProb: 0.5256, drawWinProb: 0.4892, action: 'stop', optimalWinProb: 0.5256 },
    { score: 10.0, stopWinProb: 0.6989, drawWinProb: 0.4541, action: 'stop', optimalWinProb: 0.6989 },
    { score: 10.5, stopWinProb: 0.9082, drawWinProb: 0.0000, action: 'stop', optimalWinProb: 0.9082 },
  ],
  6: [
    { score: 0.5, stopWinProb: 0.0001, drawWinProb: 0.2565, action: 'draw', optimalWinProb: 0.2565 },
    { score: 1.0, stopWinProb: 0.0001, drawWinProb: 0.2280, action: 'draw', optimalWinProb: 0.2280 },
    { score: 1.5, stopWinProb: 0.0001, drawWinProb: 0.2354, action: 'draw', optimalWinProb: 0.2354 },
    { score: 2.0, stopWinProb: 0.0001, drawWinProb: 0.2084, action: 'draw', optimalWinProb: 0.2084 },
    { score: 2.5, stopWinProb: 0.0001, drawWinProb: 0.2164, action: 'draw', optimalWinProb: 0.2164 },
    { score: 3.0, stopWinProb: 0.0001, drawWinProb: 0.1909, action: 'draw', optimalWinProb: 0.1909 },
    { score: 3.5, stopWinProb: 0.0001, drawWinProb: 0.1996, action: 'draw', optimalWinProb: 0.1996 },
    { score: 4.0, stopWinProb: 0.0001, drawWinProb: 0.1758, action: 'draw', optimalWinProb: 0.1758 },
    { score: 4.5, stopWinProb: 0.0001, drawWinProb: 0.1856, action: 'draw', optimalWinProb: 0.1856 },
    { score: 5.0, stopWinProb: 0.0030, drawWinProb: 0.1643, action: 'draw', optimalWinProb: 0.1643 },
    { score: 5.5, stopWinProb: 0.0075, drawWinProb: 0.1762, action: 'draw', optimalWinProb: 0.1762 },
    { score: 6.0, stopWinProb: 0.0126, drawWinProb: 0.1592, action: 'draw', optimalWinProb: 0.1592 },
    { score: 6.5, stopWinProb: 0.0249, drawWinProb: 0.1762, action: 'draw', optimalWinProb: 0.1762 },
    { score: 7.0, stopWinProb: 0.0463, drawWinProb: 0.1679, action: 'draw', optimalWinProb: 0.1679 },
    { score: 7.5, stopWinProb: 0.0792, drawWinProb: 0.1972, action: 'draw', optimalWinProb: 0.1972 },
    { score: 8.0, stopWinProb: 0.1305, drawWinProb: 0.2087, action: 'draw', optimalWinProb: 0.2087 },
    { score: 8.5, stopWinProb: 0.2029, drawWinProb: 0.2677, action: 'draw', optimalWinProb: 0.2677 },
    { score: 9.0, stopWinProb: 0.3077, drawWinProb: 0.3267, action: 'draw', optimalWinProb: 0.3267 },
    { score: 9.5, stopWinProb: 0.4479, drawWinProb: 0.4564, action: 'draw', optimalWinProb: 0.4564 },
    { score: 10.0, stopWinProb: 0.6399, drawWinProb: 0.4435, action: 'stop', optimalWinProb: 0.6399 },
    { score: 10.5, stopWinProb: 0.8870, drawWinProb: 0.0000, action: 'stop', optimalWinProb: 0.8870 },
  ],
};

// 停牌阈值汇总
export const thresholdSummary = [
  { players: 1, threshold: 5.0, description: '单人（最大化期望）', color: '#60a5fa' },
  { players: 2, threshold: 6.0, description: '2人游戏（1个对手）', color: '#34d399' },
  { players: 3, threshold: 8.0, description: '3人游戏（2个对手）', color: '#fbbf24' },
  { players: 4, threshold: 8.5, description: '4人游戏（3个对手）', color: '#f97316' },
  { players: 5, threshold: 9.0, description: '5人游戏（4个对手）', color: '#f43f5e' },
  { players: 6, threshold: 10.0, description: '6人游戏（5个对手）', color: '#a855f7' },
];

// 关键摸牌分布（用于热力图/详细展示）
export const drawDistributions: Record<number, Array<{ newScore: number; prob: number; isBust: boolean; isPerfect: boolean }>> = {
  4.5: [
    { newScore: 5.0, prob: 0.5000, isBust: false, isPerfect: false },
    { newScore: 5.5, prob: 0.1538, isBust: false, isPerfect: false },
    { newScore: 6.5, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 7.5, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 8.5, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 9.5, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 10.5, prob: 0.0385, isBust: false, isPerfect: true },
    { newScore: 11.5, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 12.5, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 13.5, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 14.5, prob: 0.0385, isBust: true, isPerfect: false },
  ],
  5.0: [
    { newScore: 5.5, prob: 0.5000, isBust: false, isPerfect: false },
    { newScore: 6.0, prob: 0.1538, isBust: false, isPerfect: false },
    { newScore: 7.0, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 8.0, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 9.0, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 10.0, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 11.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 12.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 13.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 14.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 15.0, prob: 0.0385, isBust: true, isPerfect: false },
  ],
  8.0: [
    { newScore: 8.5, prob: 0.5000, isBust: false, isPerfect: false },
    { newScore: 9.0, prob: 0.1538, isBust: false, isPerfect: false },
    { newScore: 10.0, prob: 0.0385, isBust: false, isPerfect: false },
    { newScore: 11.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 12.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 13.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 14.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 15.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 16.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 17.0, prob: 0.0385, isBust: true, isPerfect: false },
    { newScore: 18.0, prob: 0.0385, isBust: true, isPerfect: false },
  ],
};

// 获取某点数的停牌阈值
export function getThresholdForPlayers(players: number): number {
  const entry = thresholdSummary.find(t => t.players === players);
  return entry ? entry.threshold : 5.0;
}

// 获取某点数在某玩家数下的建议
export function getActionForScore(score: number, players: number): string {
  const threshold = getThresholdForPlayers(players);
  return score >= threshold ? 'stop' : 'draw';
}
