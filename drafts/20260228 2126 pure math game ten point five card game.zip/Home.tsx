/**
 * 十点半游戏最优策略分析 - 主页面
 * Design: Dark slate + Poker red/black theme
 * Layout: Sticky nav + scrollable sections
 */

import { useState, useEffect, useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, Legend, ReferenceLine, Cell, ComposedChart, Area
} from 'recharts';
import { thresholdSummary, singlePlayerStrategy, finalDistribution, multiplayerStrategy, cardDistribution } from '@/lib/gameData';

// ─── Animated Counter ────────────────────────────────────────────────────────
function AnimatedNumber({ value, decimals = 1, suffix = '' }: { value: number; decimals?: number; suffix?: string }) {
  const [display, setDisplay] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const end = value;
    const duration = 1200;
    const step = 16;
    const increment = (end / duration) * step;
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setDisplay(end);
        clearInterval(timer);
      } else {
        setDisplay(start);
      }
    }, step);
    return () => clearInterval(timer);
  }, [inView, value]);

  return <span ref={ref}>{display.toFixed(decimals)}{suffix}</span>;
}

// ─── Section Header ───────────────────────────────────────────────────────────
function SectionHeader({ suit, title, subtitle }: { suit: string; title: string; subtitle: string }) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-2">
        <span className="text-3xl suit-red">{suit}</span>
        <h2 className="text-2xl font-bold tracking-tight" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
          {title}
        </h2>
      </div>
      <p className="text-muted-foreground ml-12">{subtitle}</p>
      <div className="section-divider mt-4" />
    </div>
  );
}

// ─── Custom Tooltip ───────────────────────────────────────────────────────────
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-lg p-3 shadow-xl text-sm">
      <p className="font-semibold text-foreground mb-2">{label} 点</p>
      {payload.map((entry: any, i: number) => (
        <p key={i} style={{ color: entry.color }} className="flex justify-between gap-4">
          <span>{entry.name}</span>
          <span className="font-mono font-bold">{(entry.value * 100).toFixed(2)}%</span>
        </p>
      ))}
    </div>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
const NAV_ITEMS = [
  { id: 'hero', label: '概览' },
  { id: 'deck', label: '牌组' },
  { id: 'single', label: '单人策略' },
  { id: 'distribution', label: '分布' },
  { id: 'multiplayer', label: '多人竞技' },
  { id: 'summary', label: '结论' },
];

export default function Home() {
  const [activeSection, setActiveSection] = useState('hero');
  const [selectedPlayers, setSelectedPlayers] = useState(2);
  const [hoveredScore, setHoveredScore] = useState<number | null>(null);

  // Scroll spy
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) setActiveSection(entry.target.id);
        });
      },
      { rootMargin: '-40% 0px -40% 0px' }
    );
    NAV_ITEMS.forEach(item => {
      const el = document.getElementById(item.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  const mpData = multiplayerStrategy[selectedPlayers] || multiplayerStrategy[2];
  const threshold = thresholdSummary.find(t => t.players === selectedPlayers)?.threshold ?? 6;

  // Prepare single player chart data
  const singleChartData = singlePlayerStrategy.map(d => ({
    score: d.score.toFixed(1),
    '停牌值': d.score,
    '摸牌期望': d.drawExpected,
    action: d.action,
  }));

  // Prepare multiplayer chart data
  const mpChartData = mpData.map(d => ({
    score: d.score.toFixed(1),
    '停牌胜率': d.stopWinProb,
    '摸牌期望胜率': d.drawWinProb,
    action: d.action,
  }));

  // Threshold chart data
  const thresholdChartData = thresholdSummary.map(t => ({
    players: `${t.players}人`,
    threshold: t.threshold,
    color: t.color,
  }));

  return (
    <div className="min-h-screen bg-background">
      {/* ── Sticky Nav ─────────────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-14">
          <div className="flex items-center gap-2">
            <span className="text-xl suit-red">♦</span>
            <span className="font-bold text-sm tracking-wide" style={{ fontFamily: 'Space Grotesk' }}>
              十点半策略分析
            </span>
          </div>
          <div className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map(item => (
              <button
                key={item.id}
                onClick={() => scrollTo(item.id)}
                className={`px-3 py-1.5 rounded text-sm transition-all ${
                  activeSection === item.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* ── Hero Section ───────────────────────────────────────────────────── */}
      <section id="hero" className="relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-10 left-10 text-8xl suit-red">♠</div>
          <div className="absolute top-20 right-20 text-8xl suit-red">♥</div>
          <div className="absolute bottom-10 left-1/3 text-8xl suit-red">♦</div>
          <div className="absolute bottom-20 right-1/4 text-8xl suit-red">♣</div>
        </div>

        <div className="container py-20 relative">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl"
          >
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-xs font-semibold tracking-widest uppercase">
                严谨数学分析
              </span>
              <span className="text-muted-foreground text-xs">52张牌 · 精确分数计算 · 动态规划</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6" style={{ fontFamily: 'Space Grotesk' }}>
              十点半
              <span className="text-primary"> 最优策略</span>
              <br />深度分析
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              基于动态规划与博弈论，对十点半扑克游戏进行全面的数学建模。
              涵盖单人最优停牌策略与多人竞技场景下的纳什均衡分析。
            </p>

            {/* Key Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: '单人停牌阈值', value: 5.0, suffix: '点', color: '#60a5fa' },
                { label: '2人游戏阈值', value: 6.0, suffix: '点', color: '#34d399' },
                { label: '6人游戏阈值', value: 10.0, suffix: '点', color: '#a855f7' },
                { label: '十点半概率', value: 4.82, suffix: '%', color: '#fbbf24' },
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                  className="stat-card"
                >
                  <div className="text-3xl font-bold font-mono mb-1" style={{ color: stat.color, fontFamily: 'Space Mono' }}>
                    <AnimatedNumber value={stat.value} decimals={stat.suffix === '%' ? 2 : 1} suffix={stat.suffix} />
                  </div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <div className="container pb-20 space-y-20">

        {/* ── Deck Analysis ──────────────────────────────────────────────────── */}
        <section id="deck">
          <SectionHeader
            suit="♠"
            title="牌组构成分析"
            subtitle="52张牌（无王）的点数分布。黑牌全部计0.5点，红牌按牌面计点（A/J/Q/K=1点）。"
          />

          <div className="grid md:grid-cols-2 gap-6">
            {/* Card distribution bar chart */}
            <div className="stat-card">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">各点数张数分布</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={cardDistribution} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 260)" />
                  <XAxis dataKey="value" tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 11 }} />
                  <YAxis tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: 'oklch(0.16 0.015 260)', border: '1px solid oklch(0.25 0.015 260)', borderRadius: '8px' }}
                    labelStyle={{ color: 'oklch(0.95 0.005 260)' }}
                    itemStyle={{ color: 'oklch(0.95 0.005 260)' }}
                    formatter={(v: any, n: any, p: any) => [`${v}张 (${(p.payload.prob * 100).toFixed(1)}%)`, '数量']}
                  />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {cardDistribution.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Key facts */}
            <div className="stat-card flex flex-col justify-between">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">牌组关键特征</h3>
              <div className="space-y-4 flex-1">
                {[
                  { label: '黑牌 (0.5点)', value: '26张', pct: '50%', color: '#94a3b8', icon: '♠♣' },
                  { label: '红牌 A/J/Q/K (1点)', value: '8张', pct: '15.4%', color: '#ef4444', icon: '♥♦' },
                  { label: '红牌 2-10', value: '18张', pct: '34.6%', color: '#f97316', icon: '♥♦' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <span className="text-lg" style={{ color: item.color }}>{item.icon}</span>
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-foreground">{item.label}</span>
                        <span className="font-mono font-bold" style={{ color: item.color }}>{item.value} ({item.pct})</span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: item.pct, background: item.color }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-primary/10 border border-primary/20 rounded-lg">
                <p className="text-xs text-primary font-semibold">关键洞察</p>
                <p className="text-xs text-muted-foreground mt-1">
                  50%的牌是0.5点黑牌，这使得摸牌后点数增加较小，
                  但也意味着每次摸牌有一半概率只加0.5点。
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ── Single Player Strategy ─────────────────────────────────────────── */}
        <section id="single">
          <SectionHeader
            suit="♥"
            title="单人最优停牌策略"
            subtitle="目标：最大化期望得分。使用动态规划（DP）求解最优策略 V(s) = max(s, E[V(s+C)])。"
          />

          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="stat-card md:col-span-2">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
                停牌值 vs 摸牌期望
              </h3>
              <ResponsiveContainer width="100%" height={280}>
                <ComposedChart data={singleChartData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 260)" />
                  <XAxis dataKey="score" tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 10 }} />
                  <YAxis tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 10 }} domain={[0, 11]} />
                  <Tooltip
                    contentStyle={{ background: 'oklch(0.16 0.015 260)', border: '1px solid oklch(0.25 0.015 260)', borderRadius: '8px' }}
                    labelStyle={{ color: 'oklch(0.95 0.005 260)', fontWeight: 'bold' }}
                    labelFormatter={(v) => `当前点数: ${v}`}
                    formatter={(v: any, n: string) => [Number(v).toFixed(4), n]}
                  />
                  <Legend wrapperStyle={{ color: 'oklch(0.60 0.015 260)', fontSize: 12 }} />
                  <ReferenceLine x="5.0" stroke="#ef4444" strokeDasharray="4 4" label={{ value: '停牌阈值 5.0', fill: '#ef4444', fontSize: 11 }} />
                  <Line type="monotone" dataKey="停牌值" stroke="#60a5fa" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="摸牌期望" stroke="#ef4444" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            <div className="stat-card flex flex-col">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">策略结论</h3>
              <div className="flex-1 flex flex-col justify-center">
                <div className="text-center mb-6">
                  <div className="text-6xl font-bold text-primary mb-2" style={{ fontFamily: 'Space Mono' }}>5.0</div>
                  <div className="text-sm text-muted-foreground">单人最优停牌阈值</div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 p-2 bg-green-500/10 border border-green-500/20 rounded">
                    <span className="text-green-400 text-lg">↑</span>
                    <div>
                      <div className="text-xs font-semibold text-green-400">摸牌</div>
                      <div className="text-xs text-muted-foreground">点数 &lt; 5.0 时</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded">
                    <span className="text-blue-400 text-lg">■</span>
                    <div>
                      <div className="text-xs font-semibold text-blue-400">停牌</div>
                      <div className="text-xs text-muted-foreground">点数 ≥ 5.0 时</div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-4 p-3 bg-muted/50 rounded text-xs text-muted-foreground">
                在5.0点时：摸牌期望=4.9808，停牌值=5.0，停牌略优。
              </div>
            </div>
          </div>

          {/* Strategy table */}
          <div className="stat-card overflow-x-auto">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">完整策略表</h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-2 px-3 text-muted-foreground font-medium">当前点数</th>
                  <th className="text-right py-2 px-3 text-muted-foreground font-medium">爆牌概率</th>
                  <th className="text-right py-2 px-3 text-muted-foreground font-medium">摸牌期望</th>
                  <th className="text-right py-2 px-3 text-muted-foreground font-medium">停牌值</th>
                  <th className="text-center py-2 px-3 text-muted-foreground font-medium">建议</th>
                </tr>
              </thead>
              <tbody>
                {singlePlayerStrategy.map((row, i) => (
                  <tr
                    key={i}
                    className={`border-b border-border/50 transition-colors ${
                      hoveredScore === row.score ? 'bg-accent/50' : 'hover:bg-accent/30'
                    }`}
                    onMouseEnter={() => setHoveredScore(row.score)}
                    onMouseLeave={() => setHoveredScore(null)}
                  >
                    <td className="py-2 px-3 font-mono font-bold text-foreground">{row.score.toFixed(1)}</td>
                    <td className="py-2 px-3 text-right font-mono text-muted-foreground">
                      {(row.bustProb * 100).toFixed(2)}%
                    </td>
                    <td className="py-2 px-3 text-right font-mono text-muted-foreground">
                      {row.drawExpected.toFixed(4)}
                    </td>
                    <td className="py-2 px-3 text-right font-mono text-foreground">
                      {row.score.toFixed(1)}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        row.action === 'draw'
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-blue-500/20 text-blue-400'
                      }`}>
                        {row.action === 'draw' ? '摸牌' : '停牌'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* ── Final Distribution ─────────────────────────────────────────────── */}
        <section id="distribution">
          <SectionHeader
            suit="♦"
            title="最优策略下的最终点数分布"
            subtitle="采用单人最优策略（≥5.0停牌）时，玩家最终停牌点数的概率分布。"
          />

          <div className="grid md:grid-cols-3 gap-6">
            <div className="stat-card md:col-span-2">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">最终点数概率分布</h3>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={finalDistribution} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 260)" />
                  <XAxis dataKey="label" tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 10 }} />
                  <YAxis tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 10 }} tickFormatter={v => `${(v*100).toFixed(0)}%`} />
                  <Tooltip
                    contentStyle={{ background: 'oklch(0.16 0.015 260)', border: '1px solid oklch(0.25 0.015 260)', borderRadius: '8px' }}
                    labelStyle={{ color: 'oklch(0.95 0.005 260)', fontWeight: 'bold' }}
                    formatter={(v: any) => [`${(Number(v)*100).toFixed(2)}%`, '概率']}
                  />
                  <Bar dataKey="prob" radius={[4, 4, 0, 0]}>
                    {finalDistribution.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-4">
              {[
                { label: '爆牌率', value: '14.44%', desc: '超过10.5点', color: '#ef4444', icon: '💥' },
                { label: '十点半率', value: '4.82%', desc: '恰好10.5点', color: '#fbbf24', icon: '⭐' },
                { label: '有效停牌率', value: '85.56%', desc: '5.0~10.5点', color: '#60a5fa', icon: '✓' },
                { label: '最常见停点', value: '5.0点', desc: '概率16.71%', color: '#34d399', icon: '📊' },
              ].map((item, i) => (
                <div key={i} className="stat-card flex items-center gap-4">
                  <span className="text-2xl">{item.icon}</span>
                  <div>
                    <div className="font-bold font-mono" style={{ color: item.color }}>{item.value}</div>
                    <div className="text-xs text-muted-foreground">{item.label} — {item.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Multiplayer Strategy ───────────────────────────────────────────── */}
        <section id="multiplayer">
          <SectionHeader
            suit="♣"
            title="多人竞技最优策略"
            subtitle="目标：最大化获胜概率。随玩家人数增加，最优停牌阈值显著提高。"
          />

          {/* Player count selector */}
          <div className="stat-card mb-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">选择玩家人数</h3>
              <span className="text-primary font-bold font-mono text-lg">{selectedPlayers}人游戏</span>
            </div>
            <div className="flex gap-2 flex-wrap">
              {[2, 3, 4, 5, 6].map(n => (
                <button
                  key={n}
                  onClick={() => setSelectedPlayers(n)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    selectedPlayers === n
                      ? 'bg-primary text-primary-foreground shadow-lg scale-105'
                      : 'bg-muted text-muted-foreground hover:bg-accent hover:text-foreground'
                  }`}
                >
                  {n}人
                </button>
              ))}
            </div>
            <div className="mt-4 p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <p className="text-sm">
                <span className="text-primary font-bold">{selectedPlayers}人游戏</span>
                <span className="text-muted-foreground ml-2">最优停牌阈值：</span>
                <span className="text-foreground font-bold font-mono ml-1">{threshold} 点</span>
                <span className="text-muted-foreground ml-2">（达到此点数即应停牌）</span>
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-6">
            <div className="stat-card md:col-span-2">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
                停牌胜率 vs 摸牌期望胜率
              </h3>
              <ResponsiveContainer width="100%" height={280}>
                <ComposedChart data={mpChartData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 260)" />
                  <XAxis dataKey="score" tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 10 }} />
                  <YAxis tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 10 }} tickFormatter={v => `${(v*100).toFixed(0)}%`} />
                  <Tooltip
                    contentStyle={{ background: 'oklch(0.16 0.015 260)', border: '1px solid oklch(0.25 0.015 260)', borderRadius: '8px' }}
                    labelStyle={{ color: 'oklch(0.95 0.005 260)', fontWeight: 'bold' }}
                    labelFormatter={(v) => `当前点数: ${v}`}
                    formatter={(v: any, n: string) => [`${(Number(v)*100).toFixed(2)}%`, n]}
                  />
                  <Legend wrapperStyle={{ color: 'oklch(0.60 0.015 260)', fontSize: 12 }} />
                  <ReferenceLine
                    x={threshold.toFixed(1)}
                    stroke="#ef4444"
                    strokeDasharray="4 4"
                    label={{ value: `阈值 ${threshold}`, fill: '#ef4444', fontSize: 11 }}
                  />
                  <Line type="monotone" dataKey="停牌胜率" stroke="#60a5fa" strokeWidth={2} dot={false} />
                  <Line type="monotone" dataKey="摸牌期望胜率" stroke="#ef4444" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            <div className="stat-card">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">阈值处胜率</h3>
              <div className="space-y-3">
                {mpData.filter(d => d.action === 'stop').slice(0, 6).map((d, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <span className="font-mono text-sm text-foreground">{d.score.toFixed(1)}点</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${d.stopWinProb * 100}%` }} />
                      </div>
                      <span className="font-mono text-xs text-primary">{(d.stopWinProb * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Threshold trend chart */}
          <div className="stat-card">
            <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">
              最优停牌阈值随玩家人数的变化趋势
            </h3>
            <ResponsiveContainer width="100%" height={220}>
              <ComposedChart data={thresholdChartData} margin={{ top: 10, right: 30, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.015 260)" />
                <XAxis dataKey="players" tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 12 }} />
                <YAxis domain={[4, 11]} tick={{ fill: 'oklch(0.60 0.015 260)', fontSize: 12 }} />
                <Tooltip
                  contentStyle={{ background: 'oklch(0.16 0.015 260)', border: '1px solid oklch(0.25 0.015 260)', borderRadius: '8px' }}
                  labelStyle={{ color: 'oklch(0.95 0.005 260)', fontWeight: 'bold' }}
                  formatter={(v: any) => [`${v} 点`, '停牌阈值']}
                />
                <Bar dataKey="threshold" radius={[6, 6, 0, 0]}>
                  {thresholdChartData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
                <Line type="monotone" dataKey="threshold" stroke="#ffffff" strokeWidth={2} dot={{ fill: '#ffffff', r: 5 }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* ── Summary ────────────────────────────────────────────────────────── */}
        <section id="summary">
          <SectionHeader
            suit="★"
            title="结论与策略速查"
            subtitle="基于严格数学计算的最优策略总结，适用于不同人数的游戏场景。"
          />

          <div className="grid md:grid-cols-2 gap-6">
            {/* Summary table */}
            <div className="stat-card">
              <h3 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">策略速查表</h3>
              <div className="space-y-3">
                {thresholdSummary.map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.08 }}
                    className="flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: item.color + '20', color: item.color }}>
                        {item.players}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-foreground">{item.description}</div>
                        <div className="text-xs text-muted-foreground">
                          {item.players === 1 ? '最大化期望得分' : `${item.players - 1}个对手，最大化胜率`}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold font-mono" style={{ color: item.color, fontFamily: 'Space Mono' }}>
                        {item.threshold}
                      </div>
                      <div className="text-xs text-muted-foreground">停牌阈值</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Key insights */}
            <div className="space-y-4">
              <div className="stat-card">
                <h3 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wider">核心洞察</h3>
                <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
                  <p>
                    <span className="text-primary font-semibold">单人游戏</span>：在5.0点时，摸牌期望（4.9808）略低于停牌值（5.0），因此5.0是精确的停牌临界点。这是一个相对保守的策略。
                  </p>
                  <p>
                    <span className="text-primary font-semibold">多人竞技</span>：随着对手增多，出现高分的概率上升，迫使玩家必须追求更高的点数。6人游戏中，甚至在9.5点时仍应继续摸牌！
                  </p>
                  <p>
                    <span className="text-primary font-semibold">爆牌风险</span>：在10.0点时，有50%的概率摸到爆牌（摸到任何≥1点的牌都会爆）。但在6人游戏中，10.0点仍是停牌阈值，说明风险有时是必要的。
                  </p>
                </div>
              </div>

              <div className="stat-card">
                <h3 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wider">数学方法</h3>
                <div className="space-y-2 text-xs text-muted-foreground">
                  <div className="flex gap-2">
                    <span className="text-primary font-mono">DP</span>
                    <span>动态规划求解最优期望值 V(s) = max(s, E[V(s+C)])</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-primary font-mono">精确</span>
                    <span>使用Python Fraction类进行精确分数运算，避免浮点误差</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-primary font-mono">博弈</span>
                    <span>多人竞技采用纳什均衡分析，假设所有玩家理性决策</span>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-primary font-mono">独立</span>
                    <span>假设各玩家独立从完整牌组摸牌（无记牌）</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

      </div>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-10">
        <div className="container text-center text-muted-foreground text-sm">
          <div className="flex justify-center gap-4 mb-2 text-xl">
            <span className="suit-red">♠</span>
            <span className="suit-red">♥</span>
            <span className="suit-red">♦</span>
            <span className="suit-red">♣</span>
          </div>
          <p>十点半游戏最优策略分析 · 基于严格数学计算 · Manus AI</p>
          <p className="text-xs mt-1 text-muted-foreground/60">
            52张牌 · 动态规划 · 精确分数运算 · 纳什均衡
          </p>
        </div>
      </footer>
    </div>
  );
}
