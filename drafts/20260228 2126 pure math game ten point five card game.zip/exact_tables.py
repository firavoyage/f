"""
精确计算并输出关键表格数据
"""
from fractions import Fraction
from collections import defaultdict
import json

# 重建牌组
def build_deck():
    deck = []
    for _ in range(26):
        deck.append(Fraction(1, 2))
    for _ in range(2):
        deck.append(Fraction(1))
        for rank in range(2, 11):
            deck.append(Fraction(rank))
        for _ in range(3):
            deck.append(Fraction(1))
    return deck

DECK = build_deck()
card_dist_full = defaultdict(int)
for card in DECK:
    card_dist_full[card] += 1

TOTAL = 52
MAX_SCORE = Fraction(21, 2)

print("="*80)
print("精确计算：各当前点数再摸一张的完整分布")
print("="*80)

# 所有可能的当前点数（0.5到10.0）
current_scores = []
s = Fraction(1, 2)
while s < MAX_SCORE:
    current_scores.append(s)
    s += Fraction(1, 2)

# 牌组中各点数
card_values = sorted(card_dist_full.keys())

print("\n当前点数 | 摸到0.5 | 摸到1.0 | 摸到2.0 | ... | 爆牌概率 | 期望(爆=0)")
print("(各概率 = 该点数牌数/52)")
print()
print(f"牌组构成：")
for v in card_values:
    print(f"  {float(v):.1f}点: {card_dist_full[v]}张, 概率={card_dist_full[v]}/52={float(Fraction(card_dist_full[v], 52)):.4f}")

print()
print("="*80)
print("关键结论表：各点数的爆牌概率和摸牌期望")
print("="*80)
print(f"{'当前点数':>8} | {'爆牌概率':>10} | {'摸牌期望(爆=0)':>14} | {'停牌值':>8} | {'建议':>6}")
print("-"*60)

# 计算最优策略（DP）
V = {}
for s in reversed(current_scores):
    draw_exp = Fraction(0)
    for card_val, count in card_dist_full.items():
        new_s = s + card_val
        prob = Fraction(count, TOTAL)
        if new_s > MAX_SCORE:
            draw_exp += Fraction(0)
        else:
            draw_exp += prob * V.get(new_s, new_s)
    V[s] = max(s, draw_exp)

for s in current_scores:
    # 爆牌概率
    bust_prob = sum(Fraction(count, TOTAL) for val, count in card_dist_full.items() if s + val > MAX_SCORE)
    # 摸牌期望（爆=0）
    draw_exp_simple = sum(
        Fraction(count, TOTAL) * (s + val) 
        for val, count in card_dist_full.items() 
        if s + val <= MAX_SCORE
    )
    # 最优摸牌期望（递归）
    draw_exp_optimal = Fraction(0)
    for card_val, count in card_dist_full.items():
        new_s = s + card_val
        prob = Fraction(count, TOTAL)
        if new_s > MAX_SCORE:
            draw_exp_optimal += Fraction(0)
        else:
            draw_exp_optimal += prob * V.get(new_s, new_s)
    
    action = "停牌" if s >= draw_exp_optimal else "摸牌"
    
    print(f"{float(s):8.1f} | {float(bust_prob):10.4f} | {float(draw_exp_simple):14.4f} | {float(s):8.3f} | {action:>6}")

print()
print("="*80)
print("精确分数计算：关键点数的摸牌分布")
print("="*80)

# 详细展示几个关键点数
key_scores = [Fraction(9, 2), Fraction(5), Fraction(11, 2), Fraction(6), Fraction(7), Fraction(8)]
for s in key_scores:
    print(f"\n当前点数 = {float(s):.1f}：")
    total_prob = Fraction(0)
    for card_val in sorted(card_dist_full.keys()):
        count = card_dist_full[card_val]
        new_s = s + card_val
        prob = Fraction(count, TOTAL)
        total_prob += prob
        status = "爆牌!" if new_s > MAX_SCORE else ("十点半!" if new_s == MAX_SCORE else "")
        print(f"  摸到{float(card_val):.1f}点({count}张): 新点数={float(new_s):.1f}, 概率={count}/52≈{float(prob):.4f} {status}")
    
    bust_p = sum(Fraction(count, TOTAL) for val, count in card_dist_full.items() if s + val > MAX_SCORE)
    exp_p = sum(Fraction(count, TOTAL) * (s + val) for val, count in card_dist_full.items() if s + val <= MAX_SCORE)
    print(f"  → 爆牌概率: {bust_p} = {float(bust_p):.4f}")
    print(f"  → 摸牌期望(爆=0): {float(exp_p):.4f}")
    print(f"  → 停牌值: {float(s):.1f}")
    print(f"  → 建议: {'停牌' if s >= exp_p else '摸牌'}")

print()
print("="*80)
print("多人竞技：对手最终点数分布（使用最优单人策略）")
print("="*80)

# 加载之前计算的结果
with open('/home/ubuntu/shidianban/results.json') as f:
    results = json.load(f)

final_dist = results['final_distribution_optimal']
print("\n最终点数分布（使用最优策略）：")
for s_str in sorted(final_dist.keys(), key=float):
    s = float(s_str)
    p = final_dist[s_str]
    marker = " ← 爆牌" if s == 0.0 else (" ← 十点半!" if s == 10.5 else "")
    print(f"  {s:.1f}: {p:.4f} ({p:.6f}){marker}")

print()
print("="*80)
print("多人竞技：各场景最优策略汇总")
print("="*80)

multiplayer = results['multiplayer_strategy']
print(f"\n{'玩家数':>6} | {'停牌阈值':>8} | {'最优胜率(阈值处)':>16} | {'说明'}")
print("-"*60)

for n_str in sorted(multiplayer.keys(), key=int):
    n = int(n_str)
    mp_data = multiplayer[n_str]
    mp_scores = sorted([float(k) for k in mp_data.keys()])
    
    threshold = None
    threshold_win_prob = None
    for s in mp_scores:
        if mp_data[str(s)]['action'] == '停牌':
            if threshold is None:
                threshold = s
                threshold_win_prob = mp_data[str(s)]['stop_win_prob']
    
    print(f"{n:6}人 | {threshold:8.1f} | {threshold_win_prob:16.4f} | 达到{threshold:.1f}点即停牌")

# 额外：单人
single = results['single_player_strategy']
single_scores = sorted([float(k) for k in single.keys()])
single_threshold = None
for s in single_scores:
    if single[str(s)]['action'] == '停牌':
        if single_threshold is None:
            single_threshold = s
print(f"\n单人(最大化期望): 停牌阈值 = {single_threshold:.1f}点")
print(f"  在{single_threshold:.1f}点时：停牌值={single_threshold:.1f}, 摸牌期望={single[str(single_threshold)]['draw_expected']:.4f}")
