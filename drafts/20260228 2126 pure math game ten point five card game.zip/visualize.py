"""
十点半游戏分析可视化
"""

import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib import rcParams
import matplotlib.font_manager as fm

# 设置中文字体
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'WenQuanYi Micro Hei', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 150

# 加载结果
with open('/home/ubuntu/shidianban/results.json', 'r') as f:
    data = json.load(f)

# ============================================================
# 图1：牌组点数分布
# ============================================================

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('十点半游戏 - 牌组分析', fontsize=16, fontweight='bold')

# 左图：牌组点数分布
card_dist = data['card_distribution']
values = sorted([float(k) for k in card_dist.keys()])
counts = [card_dist[str(v)] for v in values]
colors = ['#2196F3' if v == 0.5 else '#F44336' for v in values]
labels = [f'{v:.1f}' for v in values]

bars = axes[0].bar(labels, counts, color=colors, edgecolor='white', linewidth=0.5)
axes[0].set_title('牌组点数分布', fontsize=13)
axes[0].set_xlabel('点数', fontsize=11)
axes[0].set_ylabel('张数', fontsize=11)
axes[0].set_xticklabels(labels, rotation=45, ha='right')

# 添加数值标签
for bar, count in zip(bars, counts):
    axes[0].text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.1,
                str(count), ha='center', va='bottom', fontsize=9)

blue_patch = mpatches.Patch(color='#2196F3', label='黑牌 (0.5点, 26张)')
red_patch = mpatches.Patch(color='#F44336', label='红牌 (1-10点, 26张)')
axes[0].legend(handles=[blue_patch, red_patch], fontsize=10)
axes[0].grid(axis='y', alpha=0.3)

# 右图：摸牌后爆牌概率 vs 当前点数
draw_analysis = data['draw_analysis']
scores = sorted([float(k) for k in draw_analysis.keys()])
bust_probs = [draw_analysis[str(s)]['bust_prob'] for s in scores]
perfect_probs = [draw_analysis[str(s)]['perfect_prob'] for s in scores]
expected_vals = [draw_analysis[str(s)]['expected_after_draw'] for s in scores]

x = np.arange(len(scores))
width = 0.35

bars1 = axes[1].bar(x - width/2, bust_probs, width, label='爆牌概率', color='#FF5722', alpha=0.8)
bars2 = axes[1].bar(x + width/2, perfect_probs, width, label='摸到10.5概率', color='#4CAF50', alpha=0.8)

axes[1].set_title('再摸一张的关键概率', fontsize=13)
axes[1].set_xlabel('当前点数', fontsize=11)
axes[1].set_ylabel('概率', fontsize=11)
axes[1].set_xticks(x)
axes[1].set_xticklabels([f'{s:.1f}' for s in scores], rotation=45, ha='right')
axes[1].legend(fontsize=10)
axes[1].grid(axis='y', alpha=0.3)
axes[1].set_ylim(0, 1.05)

plt.tight_layout()
plt.savefig('/home/ubuntu/shidianban/fig1_deck_analysis.png', bbox_inches='tight', dpi=150)
plt.close()
print("图1保存完成")

# ============================================================
# 图2：单人最优策略分析
# ============================================================

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
fig.suptitle('十点半游戏 - 单人最优策略', fontsize=16, fontweight='bold')

single = data['single_player_strategy']
scores = sorted([float(k) for k in single.keys()])
stop_vals = [single[str(s)]['stop_value'] for s in scores]
draw_exps = [single[str(s)]['draw_expected'] for s in scores]
actions = [single[str(s)]['action'] for s in scores]
optimal_vals = [single[str(s)]['optimal_value'] for s in scores]

# 左图：停牌值 vs 摸牌期望
axes[0].plot(scores, stop_vals, 'b-o', label='停牌值（当前点数）', linewidth=2, markersize=6)
axes[0].plot(scores, draw_exps, 'r-s', label='摸牌期望（爆=0）', linewidth=2, markersize=6)
axes[0].plot(scores, optimal_vals, 'g-^', label='最优期望值', linewidth=2, markersize=6, linestyle='--')

# 标注策略切换点
for i, (s, action) in enumerate(zip(scores, actions)):
    if action == '停牌':
        axes[0].axvspan(s - 0.25, s + 0.25, alpha=0.1, color='blue')

axes[0].axvline(x=5.0, color='purple', linestyle='--', alpha=0.7, label='停牌阈值 (5.0)')
axes[0].set_title('停牌值 vs 摸牌期望', fontsize=13)
axes[0].set_xlabel('当前点数', fontsize=11)
axes[0].set_ylabel('期望值', fontsize=11)
axes[0].legend(fontsize=9)
axes[0].grid(alpha=0.3)
axes[0].set_xticks(scores)
axes[0].set_xticklabels([f'{s:.1f}' for s in scores], rotation=45, ha='right')

# 右图：摸牌后期望值（爆=0）
colors_action = ['#4CAF50' if a == '摸牌' else '#2196F3' for a in actions]
bars = axes[1].bar([f'{s:.1f}' for s in scores], draw_exps, color=colors_action, edgecolor='white')

# 添加停牌值线
axes[1].plot([f'{s:.1f}' for s in scores], stop_vals, 'r-o', label='当前点数（停牌值）', linewidth=2, markersize=5)

axes[1].set_title('各点数摸牌期望 vs 停牌值', fontsize=13)
axes[1].set_xlabel('当前点数', fontsize=11)
axes[1].set_ylabel('值', fontsize=11)
axes[1].set_xticklabels([f'{s:.1f}' for s in scores], rotation=45, ha='right')

green_patch = mpatches.Patch(color='#4CAF50', label='应摸牌')
blue_patch = mpatches.Patch(color='#2196F3', label='应停牌')
axes[1].legend(handles=[green_patch, blue_patch, 
               plt.Line2D([0], [0], color='r', marker='o', label='当前点数')], fontsize=9)
axes[1].grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('/home/ubuntu/shidianban/fig2_single_strategy.png', bbox_inches='tight', dpi=150)
plt.close()
print("图2保存完成")

# ============================================================
# 图3：最优策略下的最终点数分布
# ============================================================

fig, ax = plt.subplots(figsize=(12, 5))
fig.suptitle('使用最优策略时的最终点数分布', fontsize=16, fontweight='bold')

final_dist = data['final_distribution_optimal']
final_scores = sorted([float(k) for k in final_dist.keys()])
final_probs = [final_dist[str(s)] for s in final_scores]

colors_final = []
for s in final_scores:
    if s == 0.0:
        colors_final.append('#FF5722')  # 爆牌
    elif s == 10.5:
        colors_final.append('#FFD700')  # 十点半
    else:
        colors_final.append('#2196F3')  # 正常

bars = ax.bar([f'{s:.1f}' for s in final_scores], final_probs, 
              color=colors_final, edgecolor='white', linewidth=0.5)

for bar, prob in zip(bars, final_probs):
    ax.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.002,
            f'{prob:.3f}', ha='center', va='bottom', fontsize=8)

ax.set_xlabel('最终点数', fontsize=12)
ax.set_ylabel('概率', fontsize=12)
ax.set_xticklabels([f'{s:.1f}' for s in final_scores], rotation=45, ha='right')

bust_patch = mpatches.Patch(color='#FF5722', label=f'爆牌(0): {final_dist.get("0.0", 0):.3f}')
perfect_patch = mpatches.Patch(color='#FFD700', label=f'十点半: {final_dist.get("10.5", 0):.3f}')
normal_patch = mpatches.Patch(color='#2196F3', label='正常停牌')
ax.legend(handles=[bust_patch, perfect_patch, normal_patch], fontsize=10)
ax.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig('/home/ubuntu/shidianban/fig3_final_distribution.png', bbox_inches='tight', dpi=150)
plt.close()
print("图3保存完成")

# ============================================================
# 图4：多人竞技策略对比
# ============================================================

fig, axes = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle('多人竞技最优策略分析', fontsize=16, fontweight='bold')

multiplayer = data['multiplayer_strategy']
player_counts = [2, 3, 4, 5, 6]
n_opp_list = [1, 2, 3, 4, 5]

for idx, (n_players, n_opp) in enumerate(zip(player_counts, n_opp_list)):
    row = idx // 3
    col = idx % 3
    ax = axes[row][col]
    
    mp_data = multiplayer[str(n_players)]
    mp_scores = sorted([float(k) for k in mp_data.keys()])
    stop_probs = [mp_data[str(s)]['stop_win_prob'] for s in mp_scores]
    draw_probs = [mp_data[str(s)]['draw_win_prob'] for s in mp_scores]
    mp_actions = [mp_data[str(s)]['action'] for s in mp_scores]
    
    ax.plot(mp_scores, stop_probs, 'b-o', label='停牌胜率', linewidth=2, markersize=5)
    ax.plot(mp_scores, draw_probs, 'r-s', label='摸牌期望胜率', linewidth=2, markersize=5)
    
    # 找到停牌阈值
    threshold = None
    for s, action in zip(mp_scores, mp_actions):
        if action == '停牌' and threshold is None:
            threshold = s
    
    if threshold:
        ax.axvline(x=threshold, color='green', linestyle='--', alpha=0.8, 
                   label=f'停牌阈值: {threshold:.1f}')
    
    ax.set_title(f'{n_players}人游戏 ({n_opp}个对手)', fontsize=12)
    ax.set_xlabel('当前点数', fontsize=10)
    ax.set_ylabel('胜率', fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    ax.set_ylim(0, 1.05)
    ax.set_xticks(mp_scores[::2])
    ax.set_xticklabels([f'{s:.1f}' for s in mp_scores[::2]], rotation=45, ha='right')

# 最后一个子图：停牌阈值汇总
ax = axes[1][2]
thresholds = []
for n_players in player_counts:
    mp_data = multiplayer[str(n_players)]
    mp_scores = sorted([float(k) for k in mp_data.keys()])
    mp_actions = [mp_data[str(s)]['action'] for s in mp_scores]
    threshold = None
    for s, action in zip(mp_scores, mp_actions):
        if action == '停牌' and threshold is None:
            threshold = s
    thresholds.append(threshold)

# 加入单人情况
all_players = [1] + player_counts
all_thresholds = [5.0] + thresholds

ax.plot(all_players, all_thresholds, 'g-D', linewidth=2.5, markersize=10, color='#9C27B0')
for x, y in zip(all_players, all_thresholds):
    ax.annotate(f'{y:.1f}', (x, y), textcoords="offset points", 
                xytext=(0, 10), ha='center', fontsize=11, fontweight='bold')

ax.set_title('最优停牌阈值 vs 玩家人数', fontsize=12)
ax.set_xlabel('总玩家人数', fontsize=10)
ax.set_ylabel('最优停牌阈值（点数）', fontsize=10)
ax.set_xticks(all_players)
ax.set_xticklabels([f'{n}人' for n in all_players])
ax.grid(alpha=0.3)
ax.set_ylim(4, 11)

plt.tight_layout()
plt.savefig('/home/ubuntu/shidianban/fig4_multiplayer_strategy.png', bbox_inches='tight', dpi=150)
plt.close()
print("图4保存完成")

# ============================================================
# 图5：摸牌后点数分布热力图
# ============================================================

fig, ax = plt.subplots(figsize=(14, 8))
fig.suptitle('再摸一张后的点数分布热力图', fontsize=16, fontweight='bold')

draw_analysis = data['draw_analysis']
current_scores = sorted([float(k) for k in draw_analysis.keys()])

# 所有可能的新点数
all_new_scores = set()
for s in current_scores:
    dist = draw_analysis[str(s)]['distribution']
    for ns in dist.keys():
        all_new_scores.add(float(ns))
all_new_scores = sorted(all_new_scores)

# 构建矩阵
matrix = np.zeros((len(current_scores), len(all_new_scores)))
for i, s in enumerate(current_scores):
    dist = draw_analysis[str(s)]['distribution']
    for ns_str, prob in dist.items():
        ns = float(ns_str)
        j = all_new_scores.index(ns)
        matrix[i][j] = prob

# 绘制热力图
im = ax.imshow(matrix, aspect='auto', cmap='YlOrRd', vmin=0, vmax=matrix.max())
plt.colorbar(im, ax=ax, label='概率')

ax.set_xticks(range(len(all_new_scores)))
ax.set_xticklabels([f'{s:.1f}' for s in all_new_scores], rotation=45, ha='right', fontsize=8)
ax.set_yticks(range(len(current_scores)))
ax.set_yticklabels([f'{s:.1f}' for s in current_scores], fontsize=9)
ax.set_xlabel('摸牌后点数', fontsize=12)
ax.set_ylabel('当前点数', fontsize=12)

# 标注爆牌区域
bust_threshold_idx = None
for j, ns in enumerate(all_new_scores):
    if ns > 10.5:
        if bust_threshold_idx is None:
            bust_threshold_idx = j
        
if bust_threshold_idx is not None:
    ax.axvline(x=bust_threshold_idx - 0.5, color='blue', linewidth=2, linestyle='--', 
               label='爆牌分界线 (>10.5)')
    ax.legend(fontsize=10)

plt.tight_layout()
plt.savefig('/home/ubuntu/shidianban/fig5_heatmap.png', bbox_inches='tight', dpi=150)
plt.close()
print("图5保存完成")

print("\n所有图表生成完成！")
