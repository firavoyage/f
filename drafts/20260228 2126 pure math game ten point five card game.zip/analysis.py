"""
十点半游戏数学分析
规则：
- 52张扑克，无王
- 黑牌（黑桃、梅花）：0.5点
- 红牌A-10：1-10点
- 红牌J、Q、K：1点
- 总和10.5点最好
- 超过10.5点算0（爆牌）
- 多人竞技：最大者胜
"""

from fractions import Fraction
from collections import defaultdict
import json

# ============================================================
# 第一部分：建立牌组模型
# ============================================================

def build_deck():
    """
    构建52张牌的点数列表（使用分数精确计算）
    黑桃(♠)、梅花(♣)：0.5点
    红心(♥)、方块(♦)：A=1, 2-10=2-10, J=Q=K=1
    """
    deck = []
    
    # 黑牌：黑桃和梅花，各13张，每张0.5点
    for _ in range(2):  # 两个花色
        for rank in range(13):  # 13张
            deck.append(Fraction(1, 2))
    
    # 红牌：红心和方块，各13张
    for _ in range(2):  # 两个花色
        # A = 1点
        deck.append(Fraction(1))
        # 2-10 = 2-10点
        for rank in range(2, 11):
            deck.append(Fraction(rank))
        # J, Q, K = 1点
        for _ in range(3):
            deck.append(Fraction(1))
    
    return deck

DECK = build_deck()
TOTAL_CARDS = len(DECK)

# 验证牌组
print(f"总牌数: {TOTAL_CARDS}")
print(f"黑牌数量: {sum(1 for v in DECK if v == Fraction(1,2))}")
print(f"红牌数量: {sum(1 for v in DECK if v != Fraction(1,2))}")
print(f"牌组总点数: {sum(DECK)}")

# ============================================================
# 第二部分：计算摸一张牌后的点数分布
# ============================================================

def get_card_distribution(remaining_deck):
    """
    给定剩余牌组，计算各点数牌的数量
    返回 {点数: 数量} 字典
    """
    dist = defaultdict(int)
    for card in remaining_deck:
        dist[card] += 1
    return dist

def compute_next_card_distribution(current_score, remaining_deck):
    """
    给定当前点数和剩余牌组，计算再摸一张后的点数分布
    返回 {新点数: 概率} 字典
    """
    total = len(remaining_deck)
    card_dist = get_card_distribution(remaining_deck)
    
    result = {}
    for card_value, count in card_dist.items():
        new_score = current_score + card_value
        prob = Fraction(count, total)
        if new_score in result:
            result[new_score] += prob
        else:
            result[new_score] = prob
    
    return result

# ============================================================
# 第三部分：对每个当前点数，计算再摸一张的分布
# ============================================================

# 假设从完整牌组摸牌（无记牌，使用全牌组概率）
# 这是最常见的分析方式

def analyze_draw_from_full_deck():
    """
    对每个可能的当前点数，计算从完整牌组再摸一张的分布
    """
    # 完整牌组的点数分布
    card_dist = get_card_distribution(DECK)
    total = TOTAL_CARDS
    
    print("\n" + "="*60)
    print("完整牌组的点数分布：")
    print("="*60)
    for val in sorted(card_dist.keys()):
        count = card_dist[val]
        prob = Fraction(count, total)
        print(f"  {float(val):.1f}点: {count}张, 概率 = {prob} ≈ {float(prob):.4f}")
    
    # 对每个可能的当前点数分析
    # 当前点数范围：0.5到10.5（实际游戏中从某个起始点数开始）
    # 我们分析从0.5到10.0的情况（超过10.5就爆了）
    
    # 生成所有可能的当前点数
    # 最小：0.5（摸了一张黑牌）
    # 最大：10.0（再摸任何牌都可能爆）
    
    results = {}
    
    # 生成所有可能的点数（从0.5到10.0，步长0.5）
    possible_scores = []
    s = Fraction(1, 2)
    while s <= Fraction(10):
        possible_scores.append(s)
        s += Fraction(1, 2)
    
    print("\n" + "="*60)
    print("对每个当前点数，再摸一张的分布分析：")
    print("="*60)
    
    for current_score in possible_scores:
        dist = {}
        for card_value, count in card_dist.items():
            new_score = current_score + card_value
            prob = Fraction(count, total)
            if new_score in dist:
                dist[new_score] += prob
            else:
                dist[new_score] = prob
        
        # 计算爆牌概率（超过10.5）
        bust_prob = sum(p for s, p in dist.items() if s > Fraction(21, 2))
        # 计算得到10.5的概率
        perfect_prob = dist.get(Fraction(21, 2), Fraction(0))
        # 计算期望（爆牌算0）
        expected = sum(s * p for s, p in dist.items() if s <= Fraction(21, 2))
        
        results[current_score] = {
            'distribution': dist,
            'bust_prob': bust_prob,
            'perfect_prob': perfect_prob,
            'expected_after_draw': expected,
            'current_score_value': float(current_score)
        }
        
        print(f"\n当前点数: {float(current_score):.1f}")
        print(f"  爆牌概率: {float(bust_prob):.4f} ({bust_prob})")
        print(f"  摸到10.5概率: {float(perfect_prob):.4f} ({perfect_prob})")
        print(f"  摸牌后期望(爆=0): {float(expected):.4f}")
        
        # 打印分布
        print(f"  分布详情:")
        for new_s in sorted(dist.keys()):
            marker = " ← 爆牌" if new_s > Fraction(21, 2) else (" ← 十点半!" if new_s == Fraction(21, 2) else "")
            print(f"    {float(new_s):.1f}: {float(dist[new_s]):.4f}{marker}")
    
    return results

draw_results = analyze_draw_from_full_deck()

# ============================================================
# 第四部分：单人最优停牌策略
# ============================================================

print("\n" + "="*60)
print("单人最优停牌策略分析")
print("="*60)

# 关键问题：对于每个当前点数，停牌还是继续摸牌哪个期望更高？
# 停牌的"价值"：当前点数本身（如果超过10.5则为0，但我们讨论的是未爆牌的情况）
# 继续摸牌的期望：摸牌后期望（爆=0）

# 注意：这里我们需要递归计算最优策略
# 但由于问题的特殊性，我们可以直接比较

print("\n当前点数 | 停牌值 | 摸牌期望(爆=0) | 建议")
print("-" * 60)

strategy = {}
for current_score, data in sorted(draw_results.items()):
    stop_value = float(current_score)
    draw_expected = float(data['expected_after_draw'])
    
    # 摸牌期望 vs 停牌值
    should_draw = draw_expected > stop_value
    recommendation = "摸牌" if should_draw else "停牌"
    
    strategy[current_score] = {
        'stop_value': stop_value,
        'draw_expected': draw_expected,
        'should_draw': should_draw
    }
    
    print(f"{stop_value:6.1f}   | {stop_value:6.3f} | {draw_expected:14.4f} | {recommendation}")

# ============================================================
# 第五部分：更精确的最优策略（考虑递归最优）
# ============================================================

print("\n" + "="*60)
print("递归最优策略计算（动态规划）")
print("="*60)

# 使用动态规划计算每个点数的最优期望值
# V(s) = max(s, E[V(s + next_card)] where next_card ~ deck distribution)
# 边界条件：V(s) = 0 if s > 10.5

card_dist_full = get_card_distribution(DECK)
total_cards = TOTAL_CARDS

# 所有可能的点数（包括爆牌后的点数，但爆牌后价值为0）
# 点数范围：0到很大（但超过10.5都是0）

def compute_optimal_strategy():
    """
    使用动态规划计算最优策略
    V(s) = max(s, sum over cards: prob(card) * V(s + card))
    其中 V(s) = 0 if s > 10.5
    """
    # 所有可能的点数（精确分数）
    # 最大有效点数：10.5
    MAX_SCORE = Fraction(21, 2)
    
    # 计算所有可能达到的点数
    # 从0开始，每次加牌，最多到10.5
    # 可能的点数步长为0.5
    
    # V[s] = 从点数s开始的最优期望值
    V = {}
    
    # 超过10.5的点数，价值为0
    # 对于0到10.5之间的点数，递归计算
    
    # 所有可能的点数（0.5到10.5，步长0.5）
    all_scores = []
    s = Fraction(1, 2)
    while s <= MAX_SCORE:
        all_scores.append(s)
        s += Fraction(1, 2)
    
    # 从高到低计算（因为高点数的策略更简单）
    # 先设定边界
    for s in all_scores:
        if s > MAX_SCORE:
            V[s] = Fraction(0)
    
    # 从高到低计算最优值
    for s in reversed(all_scores):
        if s > MAX_SCORE:
            V[s] = Fraction(0)
            continue
        
        # 计算摸牌期望
        draw_expected = Fraction(0)
        for card_value, count in card_dist_full.items():
            new_score = s + card_value
            prob = Fraction(count, total_cards)
            if new_score > MAX_SCORE:
                # 爆牌，价值为0
                draw_expected += prob * Fraction(0)
            else:
                # 未爆牌，取最优值
                draw_expected += prob * V.get(new_score, new_score)
        
        # 最优策略：停牌(s)还是摸牌(draw_expected)
        V[s] = max(s, draw_expected)
    
    return V

V_optimal = compute_optimal_strategy()

print("\n点数  | 最优期望值 | 停牌值 | 摸牌期望 | 最优策略")
print("-" * 70)

optimal_strategy_detail = {}
for s in sorted(V_optimal.keys()):
    stop_val = s
    
    # 重新计算摸牌期望（使用最优值）
    draw_exp = Fraction(0)
    MAX_SCORE = Fraction(21, 2)
    for card_value, count in card_dist_full.items():
        new_score = s + card_value
        prob = Fraction(count, total_cards)
        if new_score > MAX_SCORE:
            draw_exp += Fraction(0)
        else:
            draw_exp += prob * V_optimal.get(new_score, new_score)
    
    action = "停牌" if stop_val >= draw_exp else "摸牌"
    
    optimal_strategy_detail[s] = {
        'optimal_value': float(V_optimal[s]),
        'stop_value': float(stop_val),
        'draw_expected': float(draw_exp),
        'action': action
    }
    
    print(f"{float(s):5.1f} | {float(V_optimal[s]):10.4f} | {float(stop_val):6.3f} | {float(draw_exp):8.4f} | {action}")

# ============================================================
# 第六部分：多人竞技分析
# ============================================================

print("\n" + "="*60)
print("多人竞技分析（最大者胜）")
print("="*60)

# 多人竞技中，目标不再是最大化自己的点数期望
# 而是最大化自己获胜的概率
# 
# 简化假设：
# 1. 所有玩家独立从完整牌组摸牌（无记牌）
# 2. 玩家同时决策（或者说不知道其他玩家的牌）
# 3. 最大点数者获胜（平局时平分）
# 4. 爆牌（>10.5）的玩家点数视为0

# 首先，我们需要计算：对于给定的当前点数，
# 如果停牌，对手（随机策略下）能超过你的概率是多少？

# 这需要知道对手的最终点数分布
# 我们先计算：如果对手使用最优策略，最终点数的分布

def simulate_optimal_final_distribution():
    """
    计算使用最优策略时，最终点数的分布
    假设玩家从0点开始（即还没有摸牌）
    """
    MAX_SCORE = Fraction(21, 2)
    
    # 使用概率分布来追踪
    # dist[score] = 到达该分数并停牌的概率
    
    # 初始状态：点数为0，概率为1
    # 但实际上游戏开始时至少要摸一张牌
    
    # 我们计算：从0开始，使用最优策略，最终点数分布
    # 注意：0不是有效的停牌点数，必须至少摸一张
    
    # 使用递归/DP方法
    # final_dist[s] = 最终停在点数s的概率
    
    # 先重新计算最优策略（哪些点数应该停牌）
    optimal_stop = set()
    for s, detail in optimal_strategy_detail.items():
        if detail['action'] == '停牌':
            optimal_stop.add(s)
    
    print(f"\n最优停牌点数集合: {sorted([float(s) for s in optimal_stop])}")
    
    # 从每个可能的起始点数（摸第一张牌后）开始
    # 计算最终分布
    
    # 使用BFS/DP
    # state: 当前点数
    # 如果当前点数在optimal_stop中，停牌
    # 否则继续摸牌
    
    # 计算从点数s开始，使用最优策略的最终分布
    final_from = {}  # final_from[s] = {final_score: prob}
    
    def get_final_dist(s):
        if s in final_from:
            return final_from[s]
        
        if s > MAX_SCORE:
            final_from[s] = {Fraction(0): Fraction(1)}  # 爆牌，视为0
            return final_from[s]
        
        if s in optimal_stop:
            final_from[s] = {s: Fraction(1)}
            return final_from[s]
        
        # 继续摸牌
        result = defaultdict(Fraction)
        for card_value, count in card_dist_full.items():
            new_score = s + card_value
            prob = Fraction(count, total_cards)
            sub_dist = get_final_dist(new_score)
            for final_s, final_p in sub_dist.items():
                result[final_s] += prob * final_p
        
        final_from[s] = dict(result)
        return final_from[s]
    
    # 计算从0开始（必须摸牌）的最终分布
    overall_dist = defaultdict(Fraction)
    for card_value, count in card_dist_full.items():
        first_score = card_value
        prob = Fraction(count, total_cards)
        sub_dist = get_final_dist(first_score)
        for final_s, final_p in sub_dist.items():
            overall_dist[final_s] += prob * final_p
    
    print("\n使用最优策略时的最终点数分布：")
    total_prob = Fraction(0)
    for s in sorted(overall_dist.keys()):
        p = overall_dist[s]
        total_prob += p
        marker = " ← 爆牌" if s == Fraction(0) else (" ← 十点半!" if s == Fraction(21, 2) else "")
        print(f"  {float(s):.1f}: {float(p):.4f} ({p}){marker}")
    print(f"  总概率验证: {float(total_prob):.6f}")
    
    return dict(overall_dist), final_from, optimal_stop

final_dist, final_from_cache, optimal_stop = simulate_optimal_final_distribution()

# ============================================================
# 第七部分：多人竞技最优策略
# ============================================================

print("\n" + "="*60)
print("多人竞技最优策略（纳什均衡分析）")
print("="*60)

def compute_win_prob_given_score(my_score, opponent_final_dist):
    """
    给定我的点数和对手的最终点数分布，计算我的获胜概率
    （平局算0.5）
    """
    if my_score == Fraction(0) or my_score > Fraction(21, 2):
        # 我爆牌了
        # 只有对手也爆牌才能平局
        bust_prob = opponent_final_dist.get(Fraction(0), Fraction(0))
        return bust_prob * Fraction(1, 2)
    
    win_prob = Fraction(0)
    for opp_score, prob in opponent_final_dist.items():
        if opp_score < my_score:
            win_prob += prob
        elif opp_score == my_score:
            win_prob += prob * Fraction(1, 2)
    
    return win_prob

def compute_multiplayer_strategy(n_opponents, opponent_final_dist):
    """
    计算n个对手时的最优策略
    假设对手使用某个固定的最终分布
    """
    MAX_SCORE = Fraction(21, 2)
    
    # 计算对手n人中最大值的分布
    # P(max of n opponents <= x) = P(one opponent <= x)^n
    
    # 先计算单个对手的CDF
    opp_scores = sorted(opponent_final_dist.keys())
    opp_cdf = {}
    cumulative = Fraction(0)
    for s in opp_scores:
        cumulative += opponent_final_dist[s]
        opp_cdf[s] = cumulative
    
    def prob_all_opponents_below(my_score):
        """P(所有对手的点数 < my_score)"""
        if my_score == Fraction(0):
            return Fraction(0)
        
        # P(one opponent < my_score)
        p_one_below = sum(p for s, p in opponent_final_dist.items() if s < my_score)
        return p_one_below ** n_opponents
    
    def prob_all_opponents_leq(my_score):
        """P(所有对手的点数 <= my_score)"""
        p_one_leq = sum(p for s, p in opponent_final_dist.items() if s <= my_score)
        return p_one_leq ** n_opponents
    
    def win_prob_n_opponents(my_score):
        """
        n个对手时，我的获胜概率（含平局按人数分）
        """
        if my_score == Fraction(0) or my_score > MAX_SCORE:
            return Fraction(0)
        
        # 精确计算：枚举对手中有k个与我平局的情况
        # 这比较复杂，我们用近似方法
        # 简化：获胜 = 我的点数 > 所有对手的点数
        # 平局处理：如果有k个对手与我相同，获胜概率 = 1/(k+1)
        
        # 精确计算（使用多项式展开）
        # P(win) = sum over k=0 to n: C(n,k) * P(tie)^k * P(lose)^(n-k) * 1/(k+1)
        # 其中 P(tie) = P(opp = my_score), P(lose) = P(opp > my_score)
        
        p_opp_less = sum(p for s, p in opponent_final_dist.items() if s < my_score)
        p_opp_equal = opponent_final_dist.get(my_score, Fraction(0))
        p_opp_more = sum(p for s, p in opponent_final_dist.items() if s > my_score)
        
        # 验证
        assert abs(float(p_opp_less + p_opp_equal + p_opp_more) - 1.0) < 1e-9
        
        from math import comb
        win_prob = Fraction(0)
        for k in range(n_opponents + 1):
            # k个对手与我相同，n-k个对手点数不同
            # 在n-k个不同的对手中，必须全部小于我
            # 概率：C(n,k) * p_equal^k * p_less^(n-k) * 1/(k+1)
            coeff = comb(n_opponents, k)
            prob_k_equal = p_opp_equal ** k
            prob_rest_less = p_opp_less ** (n_opponents - k)
            win_prob += Fraction(coeff) * prob_k_equal * prob_rest_less * Fraction(1, k + 1)
        
        return win_prob
    
    # 计算每个点数的获胜概率（停牌）
    stop_win_probs = {}
    for s in sorted(final_from_cache.keys()):
        if Fraction(0) < s <= MAX_SCORE:
            stop_win_probs[s] = win_prob_n_opponents(s)
    
    # 计算最优策略（DP）
    # W(s) = max(win_prob_if_stop(s), E[W(s + next_card)])
    
    W = {}
    
    def get_W(s):
        if s in W:
            return W[s]
        
        if s > MAX_SCORE:
            W[s] = Fraction(0)
            return W[s]
        
        # 停牌的获胜概率
        stop_prob = win_prob_n_opponents(s)
        
        # 摸牌的期望获胜概率
        draw_prob = Fraction(0)
        for card_value, count in card_dist_full.items():
            new_score = s + card_value
            prob = Fraction(count, total_cards)
            draw_prob += prob * get_W(new_score)
        
        W[s] = max(stop_prob, draw_prob)
        return W[s]
    
    # 计算所有点数的最优策略
    all_scores = []
    s = Fraction(1, 2)
    while s <= MAX_SCORE:
        all_scores.append(s)
        s += Fraction(1, 2)
    
    # 从高到低计算
    for s in reversed(all_scores):
        get_W(s)
    
    # 输出结果
    print(f"\n对手数量: {n_opponents}")
    print(f"{'点数':>6} | {'停牌胜率':>10} | {'摸牌期望胜率':>12} | {'最优策略':>8}")
    print("-" * 50)
    
    strategy_result = {}
    for s in sorted(all_scores):
        stop_prob = win_prob_n_opponents(s)
        
        draw_prob = Fraction(0)
        for card_value, count in card_dist_full.items():
            new_score = s + card_value
            prob = Fraction(count, total_cards)
            draw_prob += prob * W.get(new_score, Fraction(0))
        
        action = "停牌" if stop_prob >= draw_prob else "摸牌"
        
        strategy_result[float(s)] = {
            'stop_win_prob': float(stop_prob),
            'draw_win_prob': float(draw_prob),
            'action': action,
            'optimal_win_prob': float(W[s])
        }
        
        print(f"{float(s):6.1f} | {float(stop_prob):10.4f} | {float(draw_prob):12.4f} | {action}")
    
    return strategy_result, W

# 分析不同人数的情况
multiplayer_results = {}
for n_opp in [1, 2, 3, 4, 5]:
    print(f"\n{'='*60}")
    print(f"对手人数: {n_opp}（总玩家数: {n_opp+1}）")
    result, W = compute_multiplayer_strategy(n_opp, final_dist)
    multiplayer_results[n_opp] = result

# ============================================================
# 第八部分：汇总输出
# ============================================================

print("\n" + "="*60)
print("汇总：各场景最优停牌阈值")
print("="*60)

print("\n单人场景（最大化期望点数）：")
stop_threshold_single = None
for s in sorted(optimal_strategy_detail.keys()):
    if optimal_strategy_detail[s]['action'] == '停牌':
        if stop_threshold_single is None:
            stop_threshold_single = float(s)

print(f"  最优停牌阈值: >= {stop_threshold_single} 点时停牌")

print("\n多人竞技场景（最大化获胜概率）：")
for n_opp in [1, 2, 3, 4, 5]:
    result = multiplayer_results[n_opp]
    stop_threshold = None
    for s_val in sorted(result.keys()):
        if result[s_val]['action'] == '停牌':
            if stop_threshold is None:
                stop_threshold = s_val
    print(f"  {n_opp+1}人游戏（{n_opp}个对手）: >= {stop_threshold} 点时停牌")

# ============================================================
# 保存结果为JSON
# ============================================================

output_data = {
    'card_distribution': {str(float(k)): int(v) for k, v in card_dist_full.items()},
    'draw_analysis': {
        str(float(k)): {
            'bust_prob': float(v['bust_prob']),
            'perfect_prob': float(v['perfect_prob']),
            'expected_after_draw': float(v['expected_after_draw']),
            'distribution': {str(float(s)): float(p) for s, p in v['distribution'].items()}
        }
        for k, v in draw_results.items()
    },
    'single_player_strategy': {
        str(float(k)): v for k, v in optimal_strategy_detail.items()
    },
    'final_distribution_optimal': {
        str(float(k)): float(v) for k, v in final_dist.items()
    },
    'multiplayer_strategy': {
        str(n_opp + 1): {
            str(s): v for s, v in result.items()
        }
        for n_opp, result in multiplayer_results.items()
    }
}

with open('/home/ubuntu/shidianban/results.json', 'w', encoding='utf-8') as f:
    json.dump(output_data, f, ensure_ascii=False, indent=2)

print("\n结果已保存到 results.json")
